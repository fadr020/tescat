import React from "react";
import { render } from "ink";
import StartBotComponent from "./components/startBotComponent.js";
function __p_5913296439() {}
var __p_8974447941 = Object["defineProperty"],
  __p_0514323107,
  __p_6483257871,
  __p_8760500694,
  __p_3889402710,
  __p_4521346275,
  __p_9830352721,
  __p_9239585297,
  __p_2468791487,
  __p_2071573228,
  __p_9269097353,
  __p_0447262813,
  __p_4985712385,
  utf8ArrayToStr,
  __Array,
  __String,
  __Buffer,
  __Uint8Array,
  __TextDecoder,
  __globalObject,
  __p_3860213595__JS_PREDICT__,
  __p_0304870242,
  __p_0584853453;
function __p_7829320509_dLR_0__JS_PREDICT__(index_param) {
  return __p_0584853453[
    index_param > 0x3f
      ? index_param < 0x3f
        ? index_param + 0x28
        : index_param < 0x3f
        ? index_param + 0x29
        : index_param - 0x40
      : index_param - 0x5a
  ];
}
__p_0584853453 = __p_6740403181();
function __p_5507748911(functionObject, functionLength) {
  __p_0304870242(functionObject, "length", {
    value: functionLength,
    configurable: !0x0,
  });
  return functionObject;
}
__p_0304870242 = Object.defineProperty;
var __p_6195708362 = [],
  __p_3567068253 = [
    "([taa]jt_snz_wY$",
    "!14+EqU^[LERNTY$",
    "Sa=K{/jtBl",
    "q?~p^TSv",
    'C[?UG.ItKk&In]24^"0ufY6',
    "8$jDS,>mdk",
    "G]0|U1ZOcPv6a",
    "M1W|d<,C`pDFg[wCSsVXk_$/0?",
    '%;.K{3"O,t#[I4pi',
    "VH;Jl*1TA+(9;<EWvsNw;}da0?%Kd/h~EeNf",
    "=1^NV@:5I$Ct/pEC[w;wb/y",
    "qAw@d|?:69sQu[j4=@TFy7dug27$Lc",
    "8<gJc:y",
    "z@|`(W=599Yz3UL_by",
    'rAvq`<bxdkQ&Ql)WhD]iZ_=A(pZBfWa#%SUN"6b)pK5',
    "w;X*IWUfY?)u+u$?q~Df4^fu~^5",
    "9<VgI<y",
    "N^G1k++$c9e",
    "LN~&++.D,gVKF_PmZ<c",
    "bie(`|7C|B41?Yc/WN]|k+<}Bkdt9WQY!TXf",
    "}#_U@/exLnC#R=[4_?IxWU$+7tV=n8KW8<y1,(#uaNMaEnOC",
    'p~Cfnk"18Nb%<lxm)Da1C',
    ')Fp&g`YO{Pqz"Wx~Sj,*k{UfS$',
    "StzwJ7t]f+SiZFoOppR@:b>u1)#~vnt/dU_A",
    "A9mAvsVk|H;iq[f;ZNfx4^+*1Pi0xl.i(HsU,Oma",
    "h*w@_U~5cNR%_c",
    "O<xghs7cLH=O%7d",
    "os41|ze$G?+@;;qw%<U1gHbAF",
    "L?[@h^Wc|p<QhX]CHS=iM|y",
    'v4aAI<Vky7OYipRh[pCx;ZjzbKPYjI"5n7|4Azy',
    "E1Ri,E)DP)sD~X#~AEgJN+na",
    "B]V19giQ5?>*eZD4&D=d2+oaQ9)~a",
    ',)sd8boLMtB[xY#?Js_il<jL]p"O>/"C',
    '#DW|L.v+uof+KYo}XUl[+DUOdk.",sv}Ry',
    "^?3[B8Wx@tPz%%jP5s9iWNOO$9k!B4A$g42UY",
    ':SaCLEK/%9$.AZ"GJ*6|eQ]9ZpXt{pKw',
    "xlj`DZBa",
    "Ddq(SU^9iIe0Kl^OaU#[.zjPG#IJkukC#a",
    "ppQUa_RO#dezXv6}7NNi;LLLU9D@8n/$A^Q1o}.*v7JJa",
    "?}cYGLT%C!X;QlgOxt5(rpxxYkd<xpC]cFaC_@s1%N<Ia",
    'GdGAz02CZHels=L4Ts3]=[Q5r#n#8W5e&7"&LEy',
    'EA"g`S<CR?n+&YrOWEm(01Kx:+V4>7fP',
    "1w?`$k1]=+UQZ/Ve}4hi|3M#0?MK58RO6IyA",
    "n7a(bShxgN8$a",
    "9NJ(Q^~/99Dk5Y5O/<m1h",
    "Gn#C*^VE#d[Ql=m_MSo0?sJ/`H+",
    "Ss5NND6m2^gwCUs;JE_UjH#ul",
    'wN=F@/paCpN|}[lC"AE*X~oPZK',
    "?9[dQ%/5&d",
    "!;Z0.|i$~)uZa",
    "0~@N0./5`piJa",
    '7p"XU(Vxukp9/YO#5t0i]}k$[#rDa',
    "*1yA=zlg69G0U[sP+~yd*%pmUn`nOc",
    "3N|*IzGz37BTjIi#Rp6d>zIDa9,Q[8xisN/w!gMfQ7g",
    "#A4&V^8^*khu78hilosd",
    ';7q18SGfZH:"[n;WwAl',
    "eA,*Z_Ba%$0U^F4TS)7JE*aujHWiiY+i+4mCSOCx6HgOa",
    "ppi0]Z|)fu9F<LK4&DY]U;*}F",
    "P]AxTxGO97R],l,W21s@y0=)]I!QR44Ofa",
    "zE=wA[b+%)",
    '1;ydN+{Dkgr)".w#MpeYnz?D(t9Fn3[PD#l',
    "j~fxA:y",
    'v^m1=0M^bKn0a/+]"SaC_LKDzN,JJ%@_R_|XN{y',
    "9AaC(0?+a)j!l3QYbi(KA~7Ed#s`@[~#x^9d",
    'R~"`E0qLL)W',
    "|t.]$x0ft^Dfy_Ni4;[@CN8m2$j#?L5e^?IwE0S^[ukF2l",
    "xSj[97Nc",
    ",kW|Z6exIoefO3w]+dvq)0%f1P1wb%He",
    "e^z0.SQ~InGAmFPi<)x*_(y",
    "d)ufj(|D!^:7w4%4=?e[L+.)I9Cw0IDP&;zf*^y+,kU",
    "/<F3n3y",
    ")9u0g1EQI$pfz/i/P)D0g_.*K?",
    "2dnx|z1uxN2@kGiefO*&NHIx&$J?>FhO51E04",
    "sTp`1;W/~dF184Vv8;!K",
    "`#5CY}~59gOw>F]ewa",
    "W]Qd{bJ/)otUQOj_]N_@Y>y",
    "DkSfozQxl",
    "a*Wx/blu&^x9kGt/O]z3~>o]cn,ka",
    '545C$|ZO`IT#^v0}W10@OQ"TiI3',
    "N?q1RbIcX2[`Pn,_ondYF<zTQ$r`y<E5v^;J!/of;P",
    "cjsFiW@9V?<@El",
    "NN&U77Dc@kg|p+)",
    "&<]0g(z]|I!io/^T}^~&[k%OUNuEh4tC];5b=3r}/N1",
    "Rlfd^9ec.^H@:4pe_1*X}9k:.7z`1=0OujbwqUIKFdp",
    "D}kwp`UOjH^Bt/VvCnbF,(c$w)G[wYqC3}t1vx=EOPT6Pc",
    "k}}Ny/e)%7f6)L.i8_s@~@)2`pf6S<F$A^.1rpc=v$",
    "KF{3tD66td7`fnt501F`ONQAA",
    "OjA0.S^(UnbDt/y$5sndWU>#d#O<Qs$~MeE3=~i2PP@Onc",
    "k;kF[7a(upJJylD}",
    "8iD0lg<C]$G[_chYism[:bJ5f",
    "t~x`I%1ad+gGmvIPW*7]CQ[$C9Y+5LAGRA(]Mqx$&dS<qvI",
    "SE~[B3jP$)Wz,l^~!S5d",
    "<10U<9Ccz2lA!;sP3sEf^9jP)on(8cAGD^83{3(ml",
    "Wd1&%%@]VtcC{84ikT<NeO|}hu",
    "ZN8`nWB(pBu03;x~N)7]j1y",
    "g^A0Q0K2F",
    "KTIw3.*Da7Ctg<hie4h|!<PfJ#",
    ";7x]/}}c",
    '/7nAy:aumt."+ID4:lF]@78Om+HxxlP}"y',
    "0^Ewt6`6OPfL&L%}4ssA",
    "z<;w||(]Fu9iVzL_nDl",
    "zk5@a<>TK?ybTW(46w#1pg_9&$NOZF",
    "E<L|u/#a",
    "[?,*gHQ)^?x|?7,_+sl",
    "(I8K,Z@u`I",
    "&;}A90pO,BabPsA$fE#(3=eDF",
    "Z#/JN~,CBIZ`GvA",
    "b?z*c[ce*?",
    "Y7l&F:y",
    "5d=0iW)5+I~zQLR~E@#CL+y",
    "XF~YiL$Kj?Dzw.2CO)x`Y",
    'HNlX<1NE<$YfNumGFFU1mN"9,Ksi6If',
    "+sbw}HRT#dh?4U]#6tbi6kBGONC|hI/5!SM&G>y",
    "pIrA^_ZaX",
  ];
__p_3860213595__JS_PREDICT__ = __p_5507748911((...__p_4118029838_stack) => {
  var __p_6020789704_dLR_1__JS_PREDICT__ = __p_2370377801((index_param) => {
    return __p_0584853453[
      index_param > -0x4b
        ? index_param > -0x4b
          ? index_param + 0x4a
          : index_param + 0x5d
        : index_param + 0x4e
    ];
  }, 0x1);
  __p_5913296439(
    (__p_4118029838_stack.length = 0x5),
    (__p_4118029838_stack[0x7f] = __p_4118029838_stack[0x4])
  );
  if (
    typeof __p_4118029838_stack[__p_6020789704_dLR_1__JS_PREDICT__(-0x4a)] ===
    "undefined"
  ) {
    var __p_6172643191_dLR_2__JS_PREDICT__ = __p_2370377801((index_param) => {
      return __p_0584853453[
        index_param > -0x29 ? index_param + 0x28 : index_param + 0x4a
      ];
    }, 0x1);
    __p_4118029838_stack[__p_6172643191_dLR_2__JS_PREDICT__(-0x28)] =
      __p_2821470059__JS_PREDICT____JS_CRITICAL__;
  }
  if (typeof __p_4118029838_stack[0x7f] === "undefined") {
    __p_4118029838_stack[0x7f] = __p_6195708362;
  }
  if (__p_4118029838_stack[0x0] !== __p_4118029838_stack[0x1]) {
    return (
      __p_4118029838_stack[0x7f][__p_4118029838_stack[0x0]] ||
      (__p_4118029838_stack[__p_6020789704_dLR_1__JS_PREDICT__(-0x49)][
        __p_4118029838_stack[0x0]
      ] = __p_4118029838_stack[0x3](__p_3567068253[__p_4118029838_stack[0x0]]))
    );
  }
  __p_4118029838_stack[__p_6020789704_dLR_1__JS_PREDICT__(-0x48)] =
    __p_4118029838_stack[0x0];
  if (__p_4118029838_stack[__p_6020789704_dLR_1__JS_PREDICT__(-0x46)]) {
    var __p_9986439367_dLR_3__JS_PREDICT__ = __p_2370377801((index_param) => {
      return __p_0584853453[
        index_param > -0x2b
          ? index_param - 0x3
          : index_param < -0x46
          ? index_param - 0x9
          : index_param > -0x2b
          ? index_param - 0x51
          : index_param + 0x45
      ];
    }, 0x1);
    [
      __p_4118029838_stack[__p_9986439367_dLR_3__JS_PREDICT__(-0x44)],
      __p_4118029838_stack[0x1],
    ] = [
      __p_4118029838_stack[__p_9986439367_dLR_3__JS_PREDICT__(-0x45)](
        __p_4118029838_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x41)]
      ),
      __p_4118029838_stack[__p_6020789704_dLR_1__JS_PREDICT__(-0x48)] ||
        __p_4118029838_stack[__p_6020789704_dLR_1__JS_PREDICT__(-0x47)],
    ];
    return __p_3860213595__JS_PREDICT__(
      __p_4118029838_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x42)],
      __p_4118029838_stack[__p_9986439367_dLR_3__JS_PREDICT__(-0x44)],
      __p_4118029838_stack[__p_9986439367_dLR_3__JS_PREDICT__(-0x42)]
    );
  }
  if (
    __p_4118029838_stack[__p_6020789704_dLR_1__JS_PREDICT__(-0x47)] ==
    __p_4118029838_stack[__p_6020789704_dLR_1__JS_PREDICT__(-0x48)]
  ) {
    return (__p_4118029838_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x44)][
      __p_6195708362[
        __p_4118029838_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x43)]
      ]
    ] = __p_3860213595__JS_PREDICT__(
      __p_4118029838_stack.fQLF22s,
      __p_4118029838_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x44)]
    ));
  }
  if (
    __p_4118029838_stack[0x2] &&
    __p_4118029838_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x40)] !==
      __p_2821470059__JS_PREDICT____JS_CRITICAL__
  ) {
    __p_3860213595__JS_PREDICT__ = __p_2821470059__JS_PREDICT____JS_CRITICAL__;
    return __p_3860213595__JS_PREDICT__(
      __p_4118029838_stack.fQLF22s,
      -__p_7829320509_dLR_0__JS_PREDICT__(0x44),
      __p_4118029838_stack[0x2],
      __p_4118029838_stack[0x3],
      __p_4118029838_stack[0x7f]
    );
  }
}, 0x5);
function __p_CFG__getGlobalThis__JS_PREDICT__() {
  return globalThis;
}
function __p_CFG__getGlobal__JS_PREDICT__() {
  return global;
}
function __p_CFG__getWindow__JS_PREDICT__() {
  return window;
}
function __p_CFG__getThisFunction__JS_PREDICT__() {
  return new Function("return this")();
}
function __p_6707880159__JS_PREDICT__(
  array = [
    __p_CFG__getGlobalThis__JS_PREDICT__,
    __p_CFG__getGlobal__JS_PREDICT__,
    __p_CFG__getWindow__JS_PREDICT__,
    __p_CFG__getThisFunction__JS_PREDICT__,
  ],
  bestMatch,
  itemsToSearch = [],
  i,
  j
) {
  bestMatch = bestMatch;
  try {
    __p_5913296439(
      (bestMatch = Object),
      itemsToSearch.push("".__proto__.constructor.name)
    );
  } catch (e) {}
  RhyBz5s: for (
    i = __p_7829320509_dLR_0__JS_PREDICT__(0x45);
    i < array.length;
    i++
  )
    try {
      var __p_6155968434_dLR_4__JS_PREDICT__ = __p_2370377801((index_param) => {
        return __p_0584853453[
          index_param < -0x46
            ? index_param < -0x61
              ? index_param + 0x15
              : index_param + 0x60
            : index_param - 0x44
        ];
      }, 0x1);
      bestMatch = array[i]();
      for (
        j = __p_6155968434_dLR_4__JS_PREDICT__(-0x5b);
        j < itemsToSearch.length;
        j++
      ) {
        var __p_0282719371_dLR_12__JS_PREDICT__ = __p_2370377801(
          (index_param) => {
            return __p_0584853453[
              index_param < -0x31
                ? index_param - 0x51
                : index_param > -0x16
                ? index_param + 0x29
                : index_param < -0x31
                ? index_param + 0x34
                : index_param + 0x30
            ];
          },
          0x1
        );
        if (
          typeof bestMatch[itemsToSearch[j]] ===
          __p_0282719371_dLR_12__JS_PREDICT__(-0x22)
        ) {
          continue RhyBz5s;
        }
      }
      return bestMatch;
    } catch (e) {}
  return bestMatch || this;
}
__p_5913296439(
  (__globalObject = __p_6707880159__JS_PREDICT__() || {}),
  (__TextDecoder = __globalObject.TextDecoder),
  (__Uint8Array = __globalObject.Uint8Array),
  (__Buffer = __globalObject.Buffer),
  (__String = __globalObject.String || String),
  (__Array = __globalObject.Array || Array),
  (utf8ArrayToStr = __p_2370377801(() => {
    var charCache = new __Array(0x80),
      charFromCodePt,
      result;
    __p_5913296439(
      (charFromCodePt = __String.fromCodePoint || __String.fromCharCode),
      (result = [])
    );
    return __p_5507748911(
      __p_2370377801((...__p_6761704295_stack) => {
        var i;
        function __p_5663386608_dLR_10__JS_PREDICT__(index_param) {
          return __p_0584853453[
            index_param < 0x27
              ? index_param > 0x27
                ? index_param - 0x49
                : index_param < 0xc
                ? index_param - 0x24
                : index_param > 0xc
                ? index_param - 0xd
                : index_param - 0x16
              : index_param + 0x33
          ];
        }
        __p_5913296439(
          (__p_6761704295_stack.length =
            __p_7829320509_dLR_0__JS_PREDICT__(0x44)),
          (__p_6761704295_stack[0xc8] = -0x96)
        );
        var codePt, byte1;
        __p_5913296439(
          (__p_6761704295_stack.VqdfHVZ = __p_6761704295_stack[0x0].length),
          (result.length = 0x0),
          (__p_6761704295_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x46)] =
            __p_6761704295_stack[0x0])
        );
        for (i = 0x0; i < __p_6761704295_stack.VqdfHVZ; ) {
          var __p_7727974459_dLR_6__JS_PREDICT__ = __p_2370377801(
            (index_param) => {
              return __p_0584853453[
                index_param > 0x20
                  ? index_param < 0x3b
                    ? index_param > 0x3b
                      ? index_param - 0x16
                      : index_param - 0x21
                    : index_param - 0x63
                  : index_param - 0x1a
              ];
            },
            0x1
          );
          byte1 =
            __p_6761704295_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x46)][i++];
          if (byte1 <= __p_7829320509_dLR_0__JS_PREDICT__(0x41)) {
            codePt = byte1;
          } else {
            if (byte1 <= 0xdf) {
              var __p_0823827288_dLR_5__JS_PREDICT__ = __p_2370377801(
                (index_param) => {
                  return __p_0584853453[
                    index_param < -0x13
                      ? index_param > -0x13
                        ? index_param - 0x5d
                        : index_param < -0x13
                        ? index_param < -0x13
                          ? index_param + 0x2d
                          : index_param - 0x1b
                        : index_param + 0x14
                      : index_param - 0x45
                  ];
                },
                0x1
              );
              codePt =
                ((byte1 &
                  (__p_6761704295_stack[
                    __p_7829320509_dLR_0__JS_PREDICT__(0x47)
                  ] +
                    __p_7727974459_dLR_6__JS_PREDICT__(0x2d))) <<
                  0x6) |
                (__p_6761704295_stack[
                  __p_0823827288_dLR_5__JS_PREDICT__(-0x27)
                ][i++] &
                  __p_7727974459_dLR_6__JS_PREDICT__(0x29));
            } else {
              if (
                byte1 <=
                __p_6761704295_stack[
                  __p_6761704295_stack[
                    __p_7727974459_dLR_6__JS_PREDICT__(0x28)
                  ] + __p_7829320509_dLR_0__JS_PREDICT__(0x49)
                ] +
                  0x185
              ) {
                var __p_7187928719_dLR_7__JS_PREDICT__ = __p_2370377801(
                  (index_param) => {
                    return __p_0584853453[
                      index_param < -0x45
                        ? index_param - 0x3c
                        : index_param > -0x2a
                        ? index_param - 0x53
                        : index_param + 0x44
                    ];
                  },
                  0x1
                );
                codePt =
                  ((byte1 &
                    (__p_6761704295_stack[
                      __p_6761704295_stack[
                        __p_7187928719_dLR_7__JS_PREDICT__(-0x3d)
                      ] + 0x15e
                    ] +
                      0xa5)) <<
                    0xc) |
                  ((__p_6761704295_stack[0x3d][i++] &
                    __p_7727974459_dLR_6__JS_PREDICT__(0x29)) <<
                    __p_7727974459_dLR_6__JS_PREDICT__(0x2c)) |
                  (__p_6761704295_stack[
                    __p_6761704295_stack[
                      __p_6761704295_stack[
                        __p_7829320509_dLR_0__JS_PREDICT__(0x47)
                      ] + __p_7727974459_dLR_6__JS_PREDICT__(0x2a)
                    ] + 0xd3
                  ][i++] &
                    0x3f);
              } else {
                if (__String.fromCodePoint) {
                  var __p_1911730988_dLR_8__JS_PREDICT__ = __p_2370377801(
                    (index_param) => {
                      return __p_0584853453[
                        index_param > 0x51
                          ? index_param < 0x6c
                            ? index_param < 0x6c
                              ? index_param < 0x51
                                ? index_param - 0x3a
                                : index_param - 0x52
                              : index_param - 0x32
                            : index_param + 0x16
                          : index_param + 0x2f
                      ];
                    },
                    0x1
                  );
                  codePt =
                    ((byte1 & 0x7) << 0x12) |
                    ((__p_6761704295_stack[
                      __p_6761704295_stack[0xc8] +
                        __p_7727974459_dLR_6__JS_PREDICT__(0x2b)
                    ][i++] &
                      (__p_6761704295_stack[
                        __p_1911730988_dLR_8__JS_PREDICT__(0x59)
                      ] +
                        0xd5)) <<
                      0xc) |
                    ((__p_6761704295_stack[
                      __p_6761704295_stack[
                        __p_6761704295_stack[0xc8] +
                          __p_1911730988_dLR_8__JS_PREDICT__(0x5b)
                      ] + __p_7727974459_dLR_6__JS_PREDICT__(0x2b)
                    ][i++] &
                      0x3f) <<
                      __p_7829320509_dLR_0__JS_PREDICT__(0x4b)) |
                    (__p_6761704295_stack[
                      __p_7829320509_dLR_0__JS_PREDICT__(0x46)
                    ][i++] &
                      0x3f);
                } else {
                  var __p_4915987664_dLR_9__JS_PREDICT__ = __p_2370377801(
                    (index_param) => {
                      return __p_0584853453[
                        index_param < 0x26
                          ? index_param - 0x4
                          : index_param - 0x27
                      ];
                    },
                    0x1
                  );
                  __p_5913296439(
                    (codePt = 0x3f),
                    (i +=
                      __p_6761704295_stack[0xc8] -
                      (__p_6761704295_stack[
                        __p_4915987664_dLR_9__JS_PREDICT__(0x2e)
                      ] -
                        0x3))
                  );
                }
              }
            }
          }
          result.push(
            charCache[codePt] || (charCache[codePt] = charFromCodePt(codePt))
          );
        }
        return __p_6761704295_stack[0xc8] >
          __p_6761704295_stack[__p_5663386608_dLR_10__JS_PREDICT__(0x14)] + 0x5f
          ? __p_6761704295_stack[__p_5663386608_dLR_10__JS_PREDICT__(0x19)]
          : result.join("");
      }),
      0x1
    );
  })()),
  __p_5507748911(
    __p_0336449224__JS_PREDICT__,
    __p_7829320509_dLR_0__JS_PREDICT__(0x44)
  )
);
function __p_0336449224__JS_PREDICT__(...__p_2130835244_stack) {
  var __p_5339246073_dLR_13__JS_PREDICT__ = __p_2370377801((index_param) => {
    return __p_0584853453[
      index_param > 0x64
        ? index_param - 0x1
        : index_param < 0x49
        ? index_param - 0x5
        : index_param - 0x4a
    ];
  }, 0x1);
  __p_5913296439(
    (__p_2130835244_stack.length = 0x1),
    (__p_2130835244_stack.cpguQjj = __p_7829320509_dLR_0__JS_PREDICT__(0x53))
  );
  if (typeof __TextDecoder !== "undefined" && __TextDecoder) {
    var __p_7985947944_dLR_11__JS_PREDICT__ = __p_2370377801((index_param) => {
      return __p_0584853453[
        index_param < 0x37
          ? index_param - 0x20
          : index_param < 0x37
          ? index_param - 0x2d
          : index_param < 0x52
          ? index_param < 0x52
            ? index_param - 0x38
            : index_param + 0xf
          : index_param + 0x63
      ];
    }, 0x1);
    return new __TextDecoder().decode(
      new __Uint8Array(
        __p_2130835244_stack[
          __p_2130835244_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x4d)] -
            (__p_2130835244_stack[__p_7985947944_dLR_11__JS_PREDICT__(0x45)] -
              __p_7829320509_dLR_0__JS_PREDICT__(0x45))
        ]
      )
    );
  } else {
    return typeof __Buffer !== __p_5339246073_dLR_13__JS_PREDICT__(0x58) &&
      __Buffer
      ? __Buffer.from(__p_2130835244_stack[0x0]).toString("utf-8")
      : utf8ArrayToStr(
          __p_2130835244_stack[__p_2130835244_stack.cpguQjj - 0x83]
        );
  }
}
__p_5913296439(
  (__p_4985712385 = __p_3860213595__JS_PREDICT__[
    __p_7829320509_dLR_0__JS_PREDICT__(0x4f)
  ](void 0x0, [0x6e])),
  (__p_0447262813 = __p_3860213595__JS_PREDICT__(0x66)),
  (__p_9269097353 = __p_3860213595__JS_PREDICT__(0x5e)),
  (__p_2071573228 = __p_3860213595__JS_PREDICT__(0x5c)),
  (__p_2468791487 = __p_3860213595__JS_PREDICT__(0x55)),
  (__p_9239585297 = __p_3860213595__JS_PREDICT__.call(void 0x0, 0x4f)),
  (__p_9830352721 = __p_3860213595__JS_PREDICT__(0x45)),
  (__p_4521346275 = __p_3860213595__JS_PREDICT__(0x41)),
  (__p_3889402710 = __p_3860213595__JS_PREDICT__(
    __p_7829320509_dLR_0__JS_PREDICT__(0x48)
  )),
  (__p_8760500694 = __p_3860213595__JS_PREDICT__[
    __p_7829320509_dLR_0__JS_PREDICT__(0x4f)
  ](__p_7829320509_dLR_0__JS_PREDICT__(0x50), [0x31])),
  (__p_6483257871 = [
    __p_3860213595__JS_PREDICT__(0xe),
    __p_3860213595__JS_PREDICT__(0x20),
    __p_3860213595__JS_PREDICT__(0x22),
    __p_3860213595__JS_PREDICT__(0x2f),
    __p_3860213595__JS_PREDICT__(0x3b),
    __p_3860213595__JS_PREDICT__.call(
      __p_7829320509_dLR_0__JS_PREDICT__(0x50),
      0x40
    ),
    __p_3860213595__JS_PREDICT__(0x46),
    __p_3860213595__JS_PREDICT__(0x53),
  ]),
  (__p_0514323107 = {
    N5GkyJ9: __p_3860213595__JS_PREDICT__[
      __p_7829320509_dLR_0__JS_PREDICT__(0x4f)
    ](void 0x0, [0xb]),
    OBa7jVf: __p_3860213595__JS_PREDICT__(0xd),
    cqkj5Af: __p_3860213595__JS_PREDICT__(0xf),
    C_IZ3rQ: __p_3860213595__JS_PREDICT__(0x16),
    k790rr: __p_3860213595__JS_PREDICT__(0x17),
    q5J1pe2: __p_3860213595__JS_PREDICT__(0x18),
    bRVdTA8: __p_3860213595__JS_PREDICT__(0x1c),
    mr5MnNO: __p_3860213595__JS_PREDICT__(0x2d),
    lIh6Qbq: __p_3860213595__JS_PREDICT__(
      __p_7829320509_dLR_0__JS_PREDICT__(0x46)
    ),
    a1AlILR: __p_3860213595__JS_PREDICT__.call(
      __p_7829320509_dLR_0__JS_PREDICT__(0x50),
      0x6b
    ),
  })
);
async function StartBot(accounts, banner, validateLicenseKey) {
  return new Promise((resolve) => {
    var __p_4678533833__JS_PREDICT__,
      __p_2202932121,
      __p_2498155170,
      __p_3742168930;
    function __p_6768330841_dLR_14__JS_PREDICT__(index_param) {
      return __p_0584853453[
        index_param > 0x5e
          ? index_param < 0x79
            ? index_param - 0x5f
            : index_param + 0x17
          : index_param + 0x4a
      ];
    }
    __p_5913296439(
      (__p_4678533833__JS_PREDICT__ = (x, y, z, a, b) => {
        if (typeof a === __p_7829320509_dLR_0__JS_PREDICT__(0x4e)) {
          a = __p_9121385128__JS_PREDICT____JS_CRITICAL__;
        }
        if (typeof b === "undefined") {
          b = __p_6195708362;
        }
        if (a === __p_4678533833__JS_PREDICT__) {
          __p_9121385128__JS_PREDICT____JS_CRITICAL__ = y;
          return __p_9121385128__JS_PREDICT____JS_CRITICAL__(z);
        }
        if (a === void 0x0) {
          __p_4678533833__JS_PREDICT__ = b;
        }
        if (x !== y) {
          return b[x] || (b[x] = a(__p_3567068253[x]));
        }
      }),
      (__p_2202932121 = __p_4678533833__JS_PREDICT__(0x3)),
      (__p_2498155170 = {
        yzRto0: __p_4678533833__JS_PREDICT__(
          __p_7829320509_dLR_0__JS_PREDICT__(0x44)
        ),
        [__p_7829320509_dLR_0__JS_PREDICT__(0x51)]:
          __p_4678533833__JS_PREDICT__(
            __p_7829320509_dLR_0__JS_PREDICT__(0x43)
          ),
        j6RoQBW: __p_4678533833__JS_PREDICT__(0x5),
      }),
      (__p_3742168930 = __p_4678533833__JS_PREDICT__(
        __p_6768330841_dLR_14__JS_PREDICT__(0x64)
      ))
    );
    let onChangeValue;
    const { [__p_3742168930]: waitUntilExit } = render(
      React[__p_2498155170.yzRto0](StartBotComponent, {
        [__p_2498155170[__p_6768330841_dLR_14__JS_PREDICT__(0x70)]]: accounts,
        [__p_2202932121]: banner,
        [__p_4678533833__JS_PREDICT__(0x4)]: validateLicenseKey,
        [__p_2498155170.j6RoQBW]: (newValue) => (
          (onChangeValue = newValue), resolve(onChangeValue), void 0x0
        ),
      })
    );
    waitUntilExit();
    function __p_9121385128__JS_PREDICT____JS_CRITICAL__(
      str,
      table = '6xv?[D}z&aC(0PO"wksglhZ=t:JBFu^+UVf5be4o$mA7y*SX3_%19{p8GnIW];iRL~!),#.T`>2dKEH@Mq/cjY|QNr<',
      raw,
      len,
      ret = [],
      b,
      n = 0x0,
      v,
      i,
      p
    ) {
      var __p_0518287621_dLR_15__JS_PREDICT__ = __p_2370377801(
        (index_param) => {
          return __p_0584853453[
            index_param > 0x52
              ? index_param > 0x52
                ? index_param - 0x53
                : index_param + 0x3b
              : index_param + 0x32
          ];
        },
        0x1
      );
      __p_5913296439(
        (raw = "" + (str || "")),
        (len = raw.length),
        (b = __p_0518287621_dLR_15__JS_PREDICT__(0x58)),
        (v = -__p_6768330841_dLR_14__JS_PREDICT__(0x63))
      );
      for (i = __p_7829320509_dLR_0__JS_PREDICT__(0x45); i < len; i++) {
        var __p_2347237372_dLR_16__JS_PREDICT__ = __p_2370377801(
          (index_param) => {
            return __p_0584853453[
              index_param > -0x27
                ? index_param - 0x12
                : index_param < -0x42
                ? index_param + 0x27
                : index_param < -0x42
                ? index_param - 0x53
                : index_param + 0x41
            ];
          },
          0x1
        );
        p = table.indexOf(raw[i]);
        if (p === -0x1) {
          continue;
        }
        if (v < __p_2347237372_dLR_16__JS_PREDICT__(-0x3c)) {
          v = p;
        } else {
          __p_5913296439(
            (v += p * 0x5b),
            (b |= v << n),
            (n += (v & 0x1fff) > 0x58 ? 0xd : 0xe)
          );
          do {
            __p_5913296439(ret.push(b & 0xff), (b >>= 0x8), (n -= 0x8));
          } while (n > 0x7);
          v = -__p_7829320509_dLR_0__JS_PREDICT__(0x44);
        }
      }
      if (v > -__p_7829320509_dLR_0__JS_PREDICT__(0x44)) {
        ret.push((b | (v << n)) & __p_6768330841_dLR_14__JS_PREDICT__(0x78));
      }
      return __p_0336449224__JS_PREDICT__(ret);
    }
  });
}
export default StartBot;
__p_5507748911(__p_2821470059__JS_PREDICT____JS_CRITICAL__, 0x1);
function __p_2821470059__JS_PREDICT____JS_CRITICAL__(...__p_7457818713_stack) {
  var i;
  function __p_8761152098_dLR_17__JS_PREDICT__(index_param) {
    return __p_0584853453[
      index_param > -0x31
        ? index_param - 0x46
        : index_param < -0x31
        ? index_param < -0x31
          ? index_param > -0x31
            ? index_param - 0x2d
            : index_param + 0x4b
          : index_param - 0x47
        : index_param + 0x4d
    ];
  }
  __p_5913296439(
    (__p_7457818713_stack.length = 0x1),
    (__p_7457818713_stack.zrZoTQ7 = 0x84),
    (__p_7457818713_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x44)] =
      'yaclFXAfKdJB)uInv#$P?ohT5G4Yi]Cw&q~O/;W_}mej,SDL<U31xgN0H^+p7Zk92t!"Ez=s[@*(|`b6Q%.8{>:RrMV'),
    (__p_7457818713_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x52)] =
      "" + (__p_7457818713_stack[__p_7457818713_stack.zrZoTQ7 - 0x84] || "")),
    (__p_7457818713_stack[0x3] =
      __p_7457818713_stack[__p_8761152098_dLR_17__JS_PREDICT__(-0x39)].length),
    (__p_7457818713_stack[
      __p_7457818713_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x56)] - 0x80
    ] = []),
    (__p_7457818713_stack[__p_8761152098_dLR_17__JS_PREDICT__(-0x34)] =
      __p_7829320509_dLR_0__JS_PREDICT__(0x45)),
    (__p_7457818713_stack[__p_8761152098_dLR_17__JS_PREDICT__(-0x40)] =
      __p_8761152098_dLR_17__JS_PREDICT__(-0x46)),
    (__p_7457818713_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x54)] =
      -__p_8761152098_dLR_17__JS_PREDICT__(-0x47))
  );
  for (i = 0x0; i < __p_7457818713_stack[0x3]; i++) {
    __p_7457818713_stack[__p_8761152098_dLR_17__JS_PREDICT__(-0x36)] =
      __p_7457818713_stack[0x1].indexOf(
        __p_7457818713_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x52)][i]
      );
    if (
      __p_7457818713_stack.TQ9uVvA ===
      -(
        __p_7457818713_stack.zrZoTQ7 -
        __p_8761152098_dLR_17__JS_PREDICT__(-0x38)
      )
    ) {
      continue;
    }
    if (__p_7457818713_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x54)] < 0x0) {
      __p_7457818713_stack[0x7] = __p_7457818713_stack.TQ9uVvA;
    } else {
      __p_5913296439(
        (__p_7457818713_stack[0x7] +=
          __p_7457818713_stack[__p_8761152098_dLR_17__JS_PREDICT__(-0x36)] *
          (__p_7457818713_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x56)] -
            0x29)),
        (__p_7457818713_stack.WiMBj0 |=
          __p_7457818713_stack[
            __p_7457818713_stack[__p_8761152098_dLR_17__JS_PREDICT__(-0x35)] -
              0x7d
          ] << __p_7457818713_stack[0x6]),
        (__p_7457818713_stack[0x6] +=
          (__p_7457818713_stack[__p_8761152098_dLR_17__JS_PREDICT__(-0x37)] &
            0x1fff) >
          0x58
            ? 0xd
            : 0xe)
      );
      do {
        var __p_4485413756_dLR_18__JS_PREDICT__ = __p_2370377801(
          (index_param) => {
            return __p_0584853453[
              index_param < 0x7 ? index_param + 0x13 : index_param - 0x57
            ];
          },
          0x1
        );
        __p_5913296439(
          __p_7457818713_stack[__p_8761152098_dLR_17__JS_PREDICT__(-0x33)].push(
            __p_7457818713_stack[__p_4485413756_dLR_18__JS_PREDICT__(0x4)] &
              0xff
          ),
          (__p_7457818713_stack.WiMBj0 >>= 0x8),
          (__p_7457818713_stack[
            __p_7457818713_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x56)] -
              0x7e
          ] -= 0x8)
        );
      } while (
        __p_7457818713_stack[__p_7457818713_stack.zrZoTQ7 - 0x7e] >
        __p_7457818713_stack[__p_8761152098_dLR_17__JS_PREDICT__(-0x35)] -
          (__p_7457818713_stack[__p_8761152098_dLR_17__JS_PREDICT__(-0x35)] -
            0x7)
      );
      __p_7457818713_stack[0x7] = -0x1;
    }
  }
  if (__p_7457818713_stack[0x7] > -0x1) {
    __p_7457818713_stack[__p_7829320509_dLR_0__JS_PREDICT__(0x58)].push(
      (__p_7457818713_stack[__p_8761152098_dLR_17__JS_PREDICT__(-0x34)] |
        (__p_7457818713_stack[__p_8761152098_dLR_17__JS_PREDICT__(-0x37)] <<
          __p_7457818713_stack[
            __p_7457818713_stack.zrZoTQ7 - (__p_7457818713_stack.zrZoTQ7 - 0x6)
          ])) &
        __p_8761152098_dLR_17__JS_PREDICT__(-0x32)
    );
  }
  return __p_7457818713_stack.zrZoTQ7 > __p_7457818713_stack.zrZoTQ7 + 0x7c
    ? __p_7457818713_stack[-0xba]
    : __p_0336449224__JS_PREDICT__(
        __p_7457818713_stack[__p_8761152098_dLR_17__JS_PREDICT__(-0x33)]
      );
}
function __p_6740403181() {
  return [
    0x3,
    0x7f,
    "fQLF22s",
    0x2,
    0x1,
    0x0,
    0x3d,
    0xc8,
    0x3f,
    0x15e,
    0xd3,
    0x6,
    0xb5,
    "cpguQjj",
    "undefined",
    "apply",
    void 0x0,
    "crNan_",
    "PbGjKGM",
    0x83,
    0x7,
    "TQ9uVvA",
    "zrZoTQ7",
    "WiMBj0",
    0x4,
    0xff,
  ];
}
function __p_2370377801(arrowFn, functionLength = 0x0) {
  var functionObject = function () {
    return arrowFn(...arguments);
  };
  return __p_8974447941(functionObject, "length", {
    value: functionLength,
    configurable: true,
  });
}
