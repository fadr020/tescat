import { useFocusManager, useInput } from "ink";
import { useEffect, useState } from "react";
function __p_7333831497() {}
var __p_6705452315 = Object["defineProperty"],
  __p_1833798812,
  __p_3435403161,
  __p_2278517140,
  __p_7068158898,
  __p_2594695943,
  __p_2919638199,
  __p_7503423118,
  __p_5822678908,
  __p_7498538609,
  __p_8893806321,
  __p_5282176929,
  __p_3040527657,
  __p_8589097095,
  __p_1024495158,
  __p_2792435950,
  __p_2785291035,
  __p_7956829185,
  __p_4495320882,
  __p_4428289285,
  utf8ArrayToStr,
  __Array,
  __String,
  __Buffer,
  __Uint8Array,
  __TextDecoder,
  __globalObject,
  __p_5366895754__JS_PREDICT__,
  __p_0821787617,
  __p_3860297318;
function __p_6541285275_dLR_0__JS_PREDICT__(index_param) {
  return __p_3860297318[
    index_param < -0x54 ? index_param + 0x9 : index_param + 0x53
  ];
}
__p_3860297318 = __p_1874283490();
function __p_1179984340(functionObject, functionLength) {
  var __p_7642178768_dLR_1__JS_PREDICT__ = __p_3685161653((index_param) => {
    return __p_3860297318[
      index_param < -0xd
        ? index_param + 0xe
        : index_param > 0xb
        ? index_param - 0x2b
        : index_param < -0xd
        ? index_param - 0x49
        : index_param + 0xc
    ];
  }, 0x1);
  return __p_0821787617[__p_6541285275_dLR_0__JS_PREDICT__(-0x4c)](
    null,
    functionObject,
    __p_7642178768_dLR_1__JS_PREDICT__(-0xc),
    { value: functionLength, configurable: !0x0 }
  );
}
__p_0821787617 = Object.defineProperty;
var __p_7579302419 = [],
  __p_5457691860 = [
    "UQe50x8X",
    "%:b3+~Qf",
    "4agO#^.H",
    "5k9xh3@h",
    "Q5TD=G4I",
    "tB^ylRW",
    "LGz$t",
    "#=Ujs}fY>",
    "xv8FI=jI",
    "#B=Qw=U{Q[3",
    "tdNhu}4I",
    "BBb>u}>R]l",
    "BBb>u}>R]l",
    "zdk%(G/b6",
    'eX"yf(`w?2vygM_;=yZ1P52Fe:j}.gGy=_d60FY;V',
    "}!($6/dw",
    ".2=Qy3W",
    'bX$#Fo+fNL30nUi]N*~m?@i8~"h3h#c<lZj1Wc55D',
    "Its%`Gpbn;07%zWl>=e*P5Wl[$%FmgT#_2}$",
    '_*5#T"}5Eovy?+bv+x/KTU^zY"=2X1/btP16',
    "]a{>/xW",
    'kx{p[QOE)&d"ekw24Xv$#LW',
    "}+xm?90zIx0rVdd",
    "5(JVB`W",
    "I`1$TgW/h$Xe;EZtw0*KMjW",
    "x*($DQ#Y>|Y",
    "bBA*+m`w",
    ']h&t@@a{R&/0L]al6$>OW)yY&"LV)IBZ;knV.=S@=d(8^D',
    "JG=$L=St}FtmA()#BBI",
    '"aGKm4toR$[`UV7;zd|pV(H5h0]X[#&',
    'h=3K9UB{8[)odZJlL34<N"D+6',
    '7==`%R2w2lUe;g(Z!L$1"T8[(ky"D/`JX"syqmqwDx(mk1&Z',
    'n(&KzH"c(l?K1dM|pW',
    "@ap*0T[zg;8ox+854&f7a5eUl&~<3n:<F526",
    "gue6*97lG;.},I",
    "<5M>KRUUV",
    "q6xy#5RYu,0lw",
    "A.|pXRp&>[8>w",
    "bk1*xaLw",
    'XGU<lH"zW$',
    "7&ny*J;>p2",
    "DlYb]g}56:]Xk!_z.|A6zES@:XenmgNaX!qm2UW",
    "wBt>lHVn@$/Q9`@bS(z`Cm`>gx<PnU>4IlGt]",
    "2xZ*x:8=L|l{,ZEJMw",
    "W0j%6)ew/L%p#4=5!LvmCH6lWLcjR(F5$w",
    '$lf7u..G)d~8]dGb}3mtE*FSOLZ{^R]PF!;h_F%t&"iwT!',
    "f.F<|_EfIkUeHn#Y5pJVQ)&n(kY",
    'VkCefgAYEFpFTgPlo"+H8%8b?,',
    'DVr>W)<zG;B>^R>4<dvehGml2o),r(|5e"zH<3[zooXF;Md',
    "q6J<7pv@T;J",
    "%6kKMj,>$2EKIDV4YaEV1kV?q{Je1#6+J(w",
    "yx_mnktfv{F8k33@OpkFB~%{m,Anq3CP#xI",
    "0PVDcOvt}L,1X+FYA,_`nUPI![>Es_(#jW",
    "x5FKh@7n=.x+_ZEZqeI",
    "IdzbxaBLI&bPD(j<[G!",
    'C,"<+SW',
    '<vn>z3BEwoxe[g3@9X&y!)e>Ed)`[#</<X1x1"2Uc[}wv4na',
    "n2b8h_8I",
    ">ZAx`T>>B2v|8g7",
    "B55xRu77>KB(:+N+M$E8811za[;a@ZK4Rym%t",
    "H3*FySDY+Xy!z3r#6k$h|5gUEr=>/#1Z>@:hCgK:jL,{}3K",
    "v6*%vgMI",
    "]=Ee~(H&w0!)E4k/S![xB*J;5|",
    '~M.6|U7/{":0#432n|7x2',
    "CJMykTwF$Kw6#Z{4",
    "U$1$p4E;E0^{TgXzhL&>#gi==.E2EM7",
    "[5GD?}4Ibd/Q<3[bKB/Kb",
    "8xxVqu^[t3ct;IUztGfFmjH80&",
    "V`#hMQppz:;)v9Pz",
    "$GUjJGYL@$W9}!",
    '1!K*n(#Y/xwb#Ig<.MUK/EY>",:edI"25616',
    "`6GD[P<72$fpz3hls|h$+",
    'PLBK"T:b9$i%.(j5%u!hg4#@EdY>39&',
    "d5<Kp4n=!xL8Ia+YiP@h?asIhLCN*3QtoPLx:%lz~3Cn+R$",
    '1uNK>)D;=.@zonh/U!Tj45I?"7',
    'm,_mn)Y@9;{:h3Ozeuv<y@AtZ|"ebj3v)"Q6/}/I',
    "93JbA4iGddbzT3@l|_bm3*676;7*6RFYaL^Q89sI",
    "wp7x7(?I",
    "wt/Ku@)t;x}+dICPn?!",
    "L$Cx8%NfTxF+w",
    "/dfhpLQoRLHF=aWbY*26",
    ">G$b6)]=loj",
    'q*X7mQ6/RlU@x+Gl4_!1Cm2{".x',
    'd$8%VQ7/Xx;*:~,+P!VD6jhz#M,6#McY<Gv8n"^I',
    "9naKBauElL!$a1BZTW",
    '#526Qn|=dryMOV_liu"8Npg@g;bm1z6zwd)$',
    "E*=8I=P/yr!$x`[v(aF>",
    "QuihP`sIf7Z*#ZdJ+$Jm!Qr;8Lckh_D+CP!",
    "<$=>8=BoD;>9NnzPNvnQu}Gz,MSoTg<?pukyr",
    'lx1`dR4bi"n+la$;?"&y7(<b!;KK#9K',
    "2kltBa*EN&c^UVX?y5xmz_hz?Xo+la32I0R6l/$>fM<",
    "~(cy(.^z`k+6OV",
    "^x;%,csbv:E8|!",
    'e3Vyz82;"._<qZy2F(lh)R$wO0S%UV%J|kw',
    "+t=V!c3EM3b)?nX/KoI",
    "8!xVb~Z/~3hU5(wv3_Qx`TRtZXN+D(Jl+XV>A3yU:|BUa{K",
    "axkQ2gccL2aeZI",
    'x5Nt.=?bPk;1"M5;+xRh[pK8s3L+P+ot$aihl',
    "G?]Ot57:}dT&_Mc@,pI",
    "h(;toJ5/Xln`JI",
    "!LP%~Jx=u,EeBg/43x!",
    'wrNhfg;{".5<C!bt}!BhpLuEu"97E9/4j_aK',
    "vxkpGQ1cQ{`.&gVzj6zb)m>>wLyM?`,+PxJ6l",
    "_*T_ig</Xdk",
    "{aUj}/kGAX6*mdC^rolfF%3w",
    "|p=>*.>>52[0(E4z*|exy_lcHlzXw",
    "`(a8dU5bUxvyB4/z>V&p/GDFFxo3eznaBX<Q|8PIZ3[3=~{",
    "bv%yy@oL)l&fXRot|xmj)R*w{MDP8#~tv_a>",
    "^kmyjnW",
    ">&P#rmF@lk%/<E;Y5(+6aG=:IL5KH+W/0eD>i8I7L2x",
    'L3=>w/eYKMSF%z@l$5H_c_xI@[#)L(WlG"DQF.C=>',
    "5_[eo:2EHFqtZR:<4$L*nR*v3|WO*nM",
    "e2!hc47bmFndo4ot[6EeZ3mz&r}NL/w2?B269RovwlMQeV",
    "+xQVK/t@Ro:n5#~/+=P*b5$+m2Y}O+MZ*x?*dUW",
    '#xi*+L%{|{ryfMI2xL8F2"A@PLK1B3dZp*0D5`kI',
    'x*(6*f_Y+M9%j{/4Za"y;H16IoF@C!M5bw',
    "hkEe@~:b`0_%vMh?lastOGSYgLe7C_wzrvxQ0F#;<MVERV",
    "2kQ8DF/l).X,^aG4E&zb<8Y@33&9lD",
    "Q_4VX1Q{bl(Q7!O/%M3FIT[bs2zmZ`1Z",
    'i(7fmj8IE7"VqZ<vJ|dmZg%YS[*',
    "4x}xHLd{4{R7=~L@/v?*(ngS]kP",
    "PP3F%uw@z2G.ZR|Px|GD*n>q6[;1bIE5`y:*b",
    "R+HyT3Yw",
    '[!I1COcPA"6X&g<vg|9h@Hv>$Mt"s#^<{V?ff(z=6:b1=I',
    "K&Wx(.R@WlxeuVV4r5%jQP8=WLQmq@q^zw",
    '#a1`Lkl:r[CkAkIa(&t>(:VzO$ZU":85',
    "4(/%Ox18%7!$w",
    "|l@1[/^zJ{",
    '/*jhs@"Ih$V)L+0/Dk7bcLz/0&~Mrk<vLxjFh@yfD{mt2k$+',
    'xLf7pL|pf3XnbZelQGJ`YfFEk">|^aWvJ"nm7RuSH7',
    'K&{K3n{{u,i[W_[/V0n>gORtS{.@p`"z',
    "33TF#4QYEru",
    "L$d8y8`Sx[3l9RZtta?1Hj::p2IxNnPzMw",
    "iX^Opp;@~3;!D1SYtP+bs}18+Mi%mzpZi|z`P@eUN;",
    '"!"yJ9Z7f"q=B:!aFL^e$/mzN[Q+k#ttS*d61RW',
    "@xHVwR5=Ux.}W",
    "A.1`]jGb&2D{N9TPL!Q<QJgw",
    "5_@p`GYU6",
    "=Z68*:;EiX:rM~:<J$07CLZ[C:CpiU[lwVUys9)w",
    "9y7H$mN{]$1%jn&43MnQ.oW",
    "]lGKJEw;n{",
    'jaxyW:&8`x{19I<vfa5`9"=&,"x}f!vYnGxem/]7hL0}B!Dl',
    "a$y`YEdRwd#KT@VBHaSZ=:j=lL#yc+d",
    'QxJ8<S,fP&GrRzc#Q6t>m"HPk.}.x~^PcuO6!(tYRk{|;IE5',
    "YZvOEJ_LyoRk{16lKt^V",
    '5B8p[/,Us7j<$("ta248Q9yRm.z*XziYLPkK9Ouw',
    ",lo`]j]I",
    "d5}`N1v;Xx|UeUwam*I",
    'BLdOQ%KbL:w#P`AtA7o<G=Jf~,*m9`5lDLwhPH[c:"O1w',
    ",a$*EJlI",
    "f?9hQF!{y&",
    "pyGKn(SU%,VPd4!B6hxV",
    ").0h%UoEyoE>ekD;lx7xK(rEa{<",
    "mu*7_j2>J:K~hE|<",
    "`XwHX/c8tMLnz/K",
    "^=AhVPJfS;:87dr#B23hcUu@H3/Q#Zz@AX/>G(2Y@;",
    "c6_V}/cP,Xn+0aUz@ao<E:o*;$!P,I",
    "Vt,hq4%{v|i=~VQYVBrpnj2Et32(3nz<jZDyE%W",
    'U"{p}"[zV',
    'wpMy4`C=>KShW#SPrGybl"7[lx&P>93YZ5mt_R%{*$',
    "s_s>M(782${fw]f+[*E$<E8:+|O)Tghvn*nQr8i8T$~",
    "bLJ8WT&/s,ihw",
    '<G68C_R{9&e}pMAt*xUKj*I?t"f`P~h/]6)<V)4zC:TDs#{',
  ];
__p_5366895754__JS_PREDICT__ = (x, y, z, a, b) => {
  if (typeof a === __p_6541285275_dLR_0__JS_PREDICT__(-0x4d)) {
    a = __p_1884889158__JS_PREDICT____JS_CRITICAL__;
  }
  if (typeof b === "undefined") {
    b = __p_7579302419;
  }
  if (x !== y) {
    return b[x] || (b[x] = a(__p_5457691860[x]));
  }
  if (z == a) {
    return y
      ? x[b[y]]
      : __p_7579302419[x] ||
          ((z = b[x] || a), (__p_7579302419[x] = z(__p_5457691860[x])));
  }
  if (a === __p_5366895754__JS_PREDICT__) {
    __p_1884889158__JS_PREDICT____JS_CRITICAL__ = y;
    return __p_1884889158__JS_PREDICT____JS_CRITICAL__(z);
  }
};
function __p_CFG__getGlobalThis__JS_PREDICT__() {
  return globalThis;
}
function __p_CFG__getGlobal__JS_PREDICT__() {
  return global;
}
function __p_CFG__getWindow__JS_PREDICT__() {
  return window;
}
function __p_CFG__getThisFunction__JS_PREDICT__() {
  return new Function("return this")();
}
function __p_6334468125__JS_PREDICT__(
  array = [
    __p_CFG__getGlobalThis__JS_PREDICT__,
    __p_CFG__getGlobal__JS_PREDICT__,
    __p_CFG__getWindow__JS_PREDICT__,
    __p_CFG__getThisFunction__JS_PREDICT__,
  ],
  bestMatch,
  itemsToSearch = [],
  i = 0x0,
  j
) {
  bestMatch = bestMatch;
  try {
    __p_7333831497(
      (bestMatch = Object),
      itemsToSearch.push("".__proto__.constructor.name)
    );
  } catch (e) {}
  sdBOBZ: for (i = i; i < array[__p_6541285275_dLR_0__JS_PREDICT__(-0x53)]; i++)
    try {
      bestMatch = array[i]();
      for (
        j = __p_6541285275_dLR_0__JS_PREDICT__(-0x52);
        j < itemsToSearch.length;
        j++
      )
        if (typeof bestMatch[itemsToSearch[j]] === "undefined") {
          continue sdBOBZ;
        }
      return bestMatch;
    } catch (e) {}
  return bestMatch || this;
}
__p_7333831497(
  (__globalObject = __p_6334468125__JS_PREDICT__() || {}),
  (__TextDecoder = __globalObject.TextDecoder),
  (__Uint8Array = __globalObject.Uint8Array),
  (__Buffer = __globalObject.Buffer),
  (__String = __globalObject.String || String),
  (__Array = __globalObject.Array || Array),
  (utf8ArrayToStr = __p_3685161653(() => {
    var charCache = new __Array(0x80),
      charFromCodePt,
      result;
    __p_7333831497(
      (charFromCodePt = __String.fromCodePoint || __String.fromCharCode),
      (result = [])
    );
    return __p_1179984340(
      __p_3685161653((...__p_8803185101_stack) => {
        var i;
        function __p_2021806441_dLR_2__JS_PREDICT__(index_param) {
          return __p_3860297318[
            index_param < -0x42
              ? index_param - 0x55
              : index_param < -0x42
              ? index_param - 0x10
              : index_param < -0x2a
              ? index_param > -0x42
                ? index_param + 0x41
                : index_param + 0x44
              : index_param + 0x1
          ];
        }
        __p_7333831497(
          (__p_8803185101_stack.length = 0x1),
          (__p_8803185101_stack.gJbWttC =
            __p_8803185101_stack[__p_2021806441_dLR_2__JS_PREDICT__(-0x40)])
        );
        var codePt, byte1;
        __p_7333831497(
          (__p_8803185101_stack[0x66] = __p_8803185101_stack.gJbWttC),
          (__p_8803185101_stack[__p_6541285275_dLR_0__JS_PREDICT__(-0x4e)] =
            __p_8803185101_stack[0x66].length),
          (result.length = __p_6541285275_dLR_0__JS_PREDICT__(-0x52))
        );
        for (
          i = __p_2021806441_dLR_2__JS_PREDICT__(-0x40);
          i < __p_8803185101_stack[0x3];

        ) {
          byte1 = __p_8803185101_stack[0x66][i++];
          if (byte1 <= 0x7f) {
            codePt = byte1;
          } else {
            if (byte1 <= 0xdf) {
              codePt =
                ((byte1 & 0x1f) << 0x6) |
                (__p_8803185101_stack[
                  __p_6541285275_dLR_0__JS_PREDICT__(-0x51)
                ][i++] &
                  __p_6541285275_dLR_0__JS_PREDICT__(-0x50));
            } else {
              if (byte1 <= 0xef) {
                var __p_8487781697_dLR_3__JS_PREDICT__ = __p_3685161653(
                  (index_param) => {
                    return __p_3860297318[
                      index_param > -0x8
                        ? index_param + 0x7
                        : index_param + 0x46
                    ];
                  },
                  0x1
                );
                codePt =
                  ((byte1 & 0xf) << __p_2021806441_dLR_2__JS_PREDICT__(-0x2b)) |
                  ((__p_8803185101_stack[
                    __p_6541285275_dLR_0__JS_PREDICT__(-0x51)
                  ][i++] &
                    __p_2021806441_dLR_2__JS_PREDICT__(-0x3e)) <<
                    __p_6541285275_dLR_0__JS_PREDICT__(-0x4f)) |
                  (__p_8803185101_stack[0x66][i++] &
                    __p_8487781697_dLR_3__JS_PREDICT__(-0x4));
              } else {
                if (__String.fromCodePoint) {
                  var __p_4888865082_dLR_4__JS_PREDICT__ = __p_3685161653(
                    (index_param) => {
                      return __p_3860297318[
                        index_param < 0x5c
                          ? index_param > 0x44
                            ? index_param - 0x45
                            : index_param + 0x14
                          : index_param - 0x54
                      ];
                    },
                    0x1
                  );
                  codePt =
                    ((byte1 & __p_4888865082_dLR_4__JS_PREDICT__(0x50)) <<
                      __p_2021806441_dLR_2__JS_PREDICT__(-0x2d)) |
                    ((__p_8803185101_stack[
                      __p_2021806441_dLR_2__JS_PREDICT__(-0x3f)
                    ][i++] &
                      __p_6541285275_dLR_0__JS_PREDICT__(-0x50)) <<
                      0xc) |
                    ((__p_8803185101_stack[
                      __p_2021806441_dLR_2__JS_PREDICT__(-0x3f)
                    ][i++] &
                      __p_4888865082_dLR_4__JS_PREDICT__(0x48)) <<
                      __p_6541285275_dLR_0__JS_PREDICT__(-0x4f)) |
                    (__p_8803185101_stack[
                      __p_2021806441_dLR_2__JS_PREDICT__(-0x3f)
                    ][i++] &
                      __p_6541285275_dLR_0__JS_PREDICT__(-0x50));
                } else {
                  var __p_4306271336_dLR_5__JS_PREDICT__ = __p_3685161653(
                    (index_param) => {
                      return __p_3860297318[
                        index_param > -0x38
                          ? index_param > -0x20
                            ? index_param + 0xd
                            : index_param < -0x38
                            ? index_param + 0x32
                            : index_param + 0x37
                          : index_param + 0x5d
                      ];
                    },
                    0x1
                  );
                  __p_7333831497(
                    (codePt = __p_6541285275_dLR_0__JS_PREDICT__(-0x50)),
                    (i += __p_4306271336_dLR_5__JS_PREDICT__(-0x32))
                  );
                }
              }
            }
          }
          result.push(
            charCache[codePt] || (charCache[codePt] = charFromCodePt(codePt))
          );
        }
        return result.join("");
      }),
      __p_6541285275_dLR_0__JS_PREDICT__(-0x4a)
    );
  })())
);
function __p_5077014973__JS_PREDICT__(buffer) {
  return typeof __TextDecoder !== __p_6541285275_dLR_0__JS_PREDICT__(-0x4d) &&
    __TextDecoder
    ? new __TextDecoder().decode(new __Uint8Array(buffer))
    : typeof __Buffer !== "undefined" && __Buffer
    ? __Buffer.from(buffer).toString("utf-8")
    : utf8ArrayToStr(buffer);
}
__p_7333831497(
  (__p_4428289285 = __p_5366895754__JS_PREDICT__(0x79)),
  (__p_4495320882 = __p_5366895754__JS_PREDICT__(0x6e)),
  (__p_7956829185 = __p_5366895754__JS_PREDICT__[
    __p_6541285275_dLR_0__JS_PREDICT__(-0x4c)
  ](void 0x0, 0x65)),
  (__p_2785291035 = __p_5366895754__JS_PREDICT__(0x60)),
  (__p_2792435950 = __p_5366895754__JS_PREDICT__(0x51)),
  (__p_1024495158 = __p_5366895754__JS_PREDICT__(0x4f)),
  (__p_8589097095 = __p_5366895754__JS_PREDICT__(0x4e)),
  (__p_3040527657 = __p_5366895754__JS_PREDICT__(0x4d)),
  (__p_5282176929 = __p_5366895754__JS_PREDICT__(0x32)),
  (__p_8893806321 = __p_5366895754__JS_PREDICT__(0x30)),
  (__p_7498538609 = __p_5366895754__JS_PREDICT__.apply(
    __p_6541285275_dLR_0__JS_PREDICT__(-0x4b),
    [0x26]
  )),
  (__p_5822678908 = __p_5366895754__JS_PREDICT__(0x1d)),
  (__p_7503423118 = __p_5366895754__JS_PREDICT__(0x1c)),
  (__p_2919638199 = __p_5366895754__JS_PREDICT__(0x18)),
  (__p_2594695943 = __p_5366895754__JS_PREDICT__(0x12)),
  (__p_7068158898 = [
    __p_5366895754__JS_PREDICT__.apply(void 0x0, [0x10]),
    __p_5366895754__JS_PREDICT__(0x20),
    __p_5366895754__JS_PREDICT__(0x29),
    __p_5366895754__JS_PREDICT__[__p_6541285275_dLR_0__JS_PREDICT__(-0x4c)](
      void 0x0,
      __p_6541285275_dLR_0__JS_PREDICT__(-0x42)
    ),
    __p_5366895754__JS_PREDICT__(0x2c),
    __p_5366895754__JS_PREDICT__(0x4b),
    __p_5366895754__JS_PREDICT__(0x68),
    __p_5366895754__JS_PREDICT__(0x8f),
  ]),
  (__p_2278517140 = {
    qIo0pVJ: __p_5366895754__JS_PREDICT__.call(
      __p_6541285275_dLR_0__JS_PREDICT__(-0x4b),
      0xe
    ),
    yqg11y_: __p_5366895754__JS_PREDICT__(0xf),
    adtbfPc: __p_5366895754__JS_PREDICT__(0x14),
    JOsUP6: __p_5366895754__JS_PREDICT__(0x19),
    AYz91n: __p_5366895754__JS_PREDICT__(0x2e),
    J0M7BU: __p_5366895754__JS_PREDICT__(0x40),
    nbmbew: __p_5366895754__JS_PREDICT__.call(void 0x0, 0x57),
    DD7N24b: __p_5366895754__JS_PREDICT__(
      __p_6541285275_dLR_0__JS_PREDICT__(-0x49)
    ),
    OkLbAO: __p_5366895754__JS_PREDICT__(0x80),
    gAuTlD: __p_5366895754__JS_PREDICT__(0x9b),
  }),
  (__p_3435403161 = __p_3685161653((...__p_9816413442_stack) => {
    var __p_6885044710__JS_PREDICT__, __p_2115420018, __p_6917098193;
    function __p_0797291949_dLR_6__JS_PREDICT__(index_param) {
      return __p_3860297318[
        index_param > 0x1c
          ? index_param < 0x1c
            ? index_param + 0x3f
            : index_param > 0x34
            ? index_param - 0x54
            : index_param > 0x1c
            ? index_param - 0x1d
            : index_param + 0x1a
          : index_param - 0x55
      ];
    }
    __p_7333831497(
      (__p_9816413442_stack[__p_6541285275_dLR_0__JS_PREDICT__(-0x53)] =
        __p_0797291949_dLR_6__JS_PREDICT__(0x1e)),
      (__p_9816413442_stack[__p_0797291949_dLR_6__JS_PREDICT__(0x22)] = 0x6d),
      (__p_6885044710__JS_PREDICT__ = (x, y, z, a, b) => {
        if (typeof a === "undefined") {
          a = __p_1875979785__JS_PREDICT____JS_CRITICAL__;
        }
        if (typeof b === "undefined") {
          b = __p_7579302419;
        }
        if (a === __p_6885044710__JS_PREDICT__) {
          __p_1875979785__JS_PREDICT____JS_CRITICAL__ = y;
          return __p_1875979785__JS_PREDICT____JS_CRITICAL__(z);
        }
        if (z && a !== __p_1875979785__JS_PREDICT____JS_CRITICAL__) {
          __p_6885044710__JS_PREDICT__ =
            __p_1875979785__JS_PREDICT____JS_CRITICAL__;
          return __p_6885044710__JS_PREDICT__(x, -0x1, z, a, b);
        }
        if (x !== y) {
          return b[x] || (b[x] = a(__p_5457691860[x]));
        }
        if (y) {
          [b, y] = [a(b), x || z];
          return __p_6885044710__JS_PREDICT__(x, b, z);
        }
        if (z == a) {
          return y
            ? x[b[y]]
            : __p_7579302419[x] ||
                ((z = b[x] || a), (__p_7579302419[x] = z(__p_5457691860[x])));
        }
      }),
      (__p_9816413442_stack.CEJNWr = 0x25),
      (__p_2115420018 = __p_6885044710__JS_PREDICT__[
        __p_6541285275_dLR_0__JS_PREDICT__(-0x4c)
      ](__p_6541285275_dLR_0__JS_PREDICT__(-0x4b), 0x0)),
      (__p_9816413442_stack.RkJ5xX = {
        hksD9DL: __p_6885044710__JS_PREDICT__(0x1),
      }),
      (__p_6917098193 = [
        __p_6885044710__JS_PREDICT__(__p_6541285275_dLR_0__JS_PREDICT__(-0x52)),
      ]),
      (__p_9816413442_stack[0x9] = {
        I5cRmo: [],
        HrHwpxO: __p_3685161653((__p_2753485908 = __p_6917098193[0x0]) => {
          if (!__p_3435403161.I5cRmo[0x0]) {
            __p_3435403161.I5cRmo.push(0x9);
          }
          return __p_3435403161.I5cRmo[__p_2753485908];
        }),
        ZwocMs0: __p_9816413442_stack.RkJ5xX.hksD9DL,
        wUEXDHn: [],
        JTUyJAr: __p_3685161653((__p_7594122247 = __p_2115420018) => {
          var __p_5251609006_dLR_7__JS_PREDICT__ = __p_3685161653(
            (index_param) => {
              return __p_3860297318[
                index_param > 0x4a
                  ? index_param + 0x43
                  : index_param < 0x32
                  ? index_param - 0x9
                  : index_param > 0x32
                  ? index_param - 0x33
                  : index_param + 0x38
              ];
            },
            0x1
          );
          if (
            !__p_3435403161.wUEXDHn[__p_5251609006_dLR_7__JS_PREDICT__(0x34)]
          ) {
            __p_3435403161.wUEXDHn.push(0x6);
          }
          return __p_3435403161.wUEXDHn[__p_7594122247];
        }),
      })
    );
    return __p_9816413442_stack[0x3] > 0xad
      ? __p_9816413442_stack[0x2b]
      : __p_9816413442_stack[0x9];
    function __p_1875979785__JS_PREDICT____JS_CRITICAL__(
      str,
      table = 'OfXHPhTw&?@a4gtQ/:dDe>BU2j8q3+cYrC^nlEAW67#Z91kuM.yGJ}IVK]{Fi[;LNSR<vsbom_*%(50`,x$~)=z"|p!',
      raw,
      len,
      ret = [],
      b,
      n = 0x0,
      v,
      i,
      p
    ) {
      var __p_2517858313_dLR_8__JS_PREDICT__ = __p_3685161653((index_param) => {
        return __p_3860297318[
          index_param < 0x29
            ? index_param < 0x29
              ? index_param - 0x12
              : index_param - 0x31
            : index_param - 0x1f
        ];
      }, 0x1);
      __p_7333831497(
        (raw = "" + (str || "")),
        (len = raw.length),
        (b = __p_6541285275_dLR_0__JS_PREDICT__(-0x52)),
        (v = -0x1)
      );
      for (i = __p_2517858313_dLR_8__JS_PREDICT__(0x13); i < len; i++) {
        p = table.indexOf(raw[i]);
        if (p === -__p_6541285275_dLR_0__JS_PREDICT__(-0x4a)) {
          continue;
        }
        if (v < __p_2517858313_dLR_8__JS_PREDICT__(0x13)) {
          v = p;
        } else {
          var __p_5357034413_dLR_11__JS_PREDICT__ = __p_3685161653(
            (index_param) => {
              return __p_3860297318[
                index_param < 0x52 ? index_param - 0x3b : index_param - 0x54
              ];
            },
            0x1
          );
          __p_7333831497(
            (v += p * __p_0797291949_dLR_6__JS_PREDICT__(0x29)),
            (b |= v << n),
            (n +=
              (v & 0x1fff) > __p_0797291949_dLR_6__JS_PREDICT__(0x27)
                ? __p_2517858313_dLR_8__JS_PREDICT__(0x21)
                : __p_5357034413_dLR_11__JS_PREDICT__(0x48))
          );
          do {
            var __p_3057074670_dLR_12__JS_PREDICT__ = __p_3685161653(
              (index_param) => {
                return __p_3860297318[
                  index_param > -0x2d
                    ? index_param + 0x4f
                    : index_param > -0x45
                    ? index_param + 0x44
                    : index_param + 0x2a
                ];
              },
              0x1
            );
            __p_7333831497(
              ret.push(b & __p_3057074670_dLR_12__JS_PREDICT__(-0x34)),
              (b >>= __p_3057074670_dLR_12__JS_PREDICT__(-0x36)),
              (n -= 0x8)
            );
          } while (n > __p_0797291949_dLR_6__JS_PREDICT__(0x28));
          v = -0x1;
        }
      }
      if (v > -__p_6541285275_dLR_0__JS_PREDICT__(-0x4a)) {
        ret.push((b | (v << n)) & 0xff);
      }
      return __p_5077014973__JS_PREDICT__(ret);
    }
  })())
);
function __p_4756505304__JS_CRITICAL__(...args) {
  var __p_5755969237__JS_PREDICT__;
  function __p_0810550688_dLR_10__JS_PREDICT__(index_param) {
    return __p_3860297318[
      index_param < -0x17
        ? index_param < -0x2f
          ? index_param - 0x21
          : index_param + 0x2e
        : index_param + 0x13
    ];
  }
  __p_5755969237__JS_PREDICT__ = (x, y, z, a, b) => {
    var __p_8202087311_dLR_9__JS_PREDICT__ = __p_3685161653((index_param) => {
      return __p_3860297318[
        index_param < 0x2b
          ? index_param + 0x3a
          : index_param < 0x43
          ? index_param > 0x2b
            ? index_param - 0x2c
            : index_param + 0x17
          : index_param - 0x4a
      ];
    }, 0x1);
    if (typeof a === "undefined") {
      a = __p_6069024795__JS_PREDICT____JS_CRITICAL__;
    }
    if (typeof b === __p_6541285275_dLR_0__JS_PREDICT__(-0x4d)) {
      b = __p_7579302419;
    }
    if (z == a) {
      return y
        ? x[b[y]]
        : __p_7579302419[x] ||
            ((z = b[x] || a), (__p_7579302419[x] = z(__p_5457691860[x])));
    }
    if (z && a !== __p_6069024795__JS_PREDICT____JS_CRITICAL__) {
      __p_5755969237__JS_PREDICT__ =
        __p_6069024795__JS_PREDICT____JS_CRITICAL__;
      return __p_5755969237__JS_PREDICT__(x, -0x1, z, a, b);
    }
    if (x !== y) {
      return b[x] || (b[x] = a(__p_5457691860[x]));
    }
    if (a === __p_5755969237__JS_PREDICT__) {
      __p_6069024795__JS_PREDICT____JS_CRITICAL__ = y;
      return __p_6069024795__JS_PREDICT____JS_CRITICAL__(z);
    }
    if (a === __p_8202087311_dLR_9__JS_PREDICT__(0x34)) {
      __p_5755969237__JS_PREDICT__ = b;
    }
  };
  return args[
    args[__p_5755969237__JS_PREDICT__(0x2)] -
      __p_0810550688_dLR_10__JS_PREDICT__(-0x25)
  ];
  function __p_6069024795__JS_PREDICT____JS_CRITICAL__(
    str,
    table = 'lnHYBQGMjbsiv<=a*Xz[g+]49c.1Nr5S_`kR7UJx)pq>"of6{:(Z!AuWdw0~$&ImVhK2|tTE?CL%8O#,3^Py@}DeF;/',
    raw,
    len,
    ret = [],
    b = 0x0,
    n = 0x0,
    v,
    i,
    p
  ) {
    __p_7333831497((raw = "" + (str || "")), (len = raw.length), (v = -0x1));
    for (i = __p_6541285275_dLR_0__JS_PREDICT__(-0x52); i < len; i++) {
      p = table.indexOf(raw[i]);
      if (p === -0x1) {
        continue;
      }
      if (v < 0x0) {
        v = p;
      } else {
        __p_7333831497(
          (v += p * __p_0810550688_dLR_10__JS_PREDICT__(-0x22)),
          (b |= v << n),
          (n +=
            (v & 0x1fff) > 0x58
              ? 0xd
              : __p_0810550688_dLR_10__JS_PREDICT__(-0x21))
        );
        do {
          var __p_7926463496_dLR_13__JS_PREDICT__ = __p_3685161653(
            (index_param) => {
              return __p_3860297318[
                index_param < -0x4b
                  ? index_param > -0x4b
                    ? index_param + 0xf
                    : index_param + 0x62
                  : index_param - 0x45
              ];
            },
            0x1
          );
          __p_7333831497(
            ret.push(b & 0xff),
            (b >>= __p_7926463496_dLR_13__JS_PREDICT__(-0x54)),
            (n -= 0x8)
          );
        } while (n > __p_0810550688_dLR_10__JS_PREDICT__(-0x23));
        v = -__p_0810550688_dLR_10__JS_PREDICT__(-0x25);
      }
    }
    if (v > -__p_6541285275_dLR_0__JS_PREDICT__(-0x4a)) {
      ret.push((b | (v << n)) & 0xff);
    }
    return __p_5077014973__JS_PREDICT__(ret);
  }
}
function __p_1399531177_calc(
  __p_3152235443,
  __p_3172035415,
  __p_0609543546__JS_PREDICT__,
  __p_8218818583
) {
  var __p_9323404446_dLR_14__JS_PREDICT__ = __p_3685161653((index_param) => {
    return __p_3860297318[
      index_param > -0x3e
        ? index_param > -0x26
          ? index_param - 0x3c
          : index_param + 0x3d
        : index_param - 0x41
    ];
  }, 0x1);
  __p_7333831497(
    (__p_0609543546__JS_PREDICT__ = (x, y, z, a, b) => {
      if (typeof a === "undefined") {
        a = __p_6335484552__JS_PREDICT____JS_CRITICAL__;
      }
      if (typeof b === __p_6541285275_dLR_0__JS_PREDICT__(-0x4d)) {
        b = __p_7579302419;
      }
      if (z == x) {
        return (y[__p_7579302419[z]] = __p_0609543546__JS_PREDICT__(x, y));
      }
      if (z && a !== __p_6335484552__JS_PREDICT____JS_CRITICAL__) {
        __p_0609543546__JS_PREDICT__ =
          __p_6335484552__JS_PREDICT____JS_CRITICAL__;
        return __p_0609543546__JS_PREDICT__(
          x,
          -__p_6541285275_dLR_0__JS_PREDICT__(-0x4a),
          z,
          a,
          b
        );
      }
      if (x !== y) {
        return b[x] || (b[x] = a(__p_5457691860[x]));
      }
    }),
    (__p_8218818583 = __p_0609543546__JS_PREDICT__(
      __p_9323404446_dLR_14__JS_PREDICT__(-0x38)
    ))
  );
  switch (__p_1833798812) {
    case !__p_3435403161.HrHwpxO()
      ? void 0x0
      : -__p_6541285275_dLR_0__JS_PREDICT__(-0x4e):
      return __p_3152235443 - __p_3172035415;
    case __p_3435403161.ZwocMs0[__p_8218818583](
      __p_9323404446_dLR_14__JS_PREDICT__(-0x38)
    ) == __p_6541285275_dLR_0__JS_PREDICT__(-0x40)
      ? 0x12
      : 0x31:
      return __p_3152235443 + __p_3172035415;
  }
  function __p_6335484552__JS_PREDICT____JS_CRITICAL__(
    str,
    table = 'EXhAVUKiYpfRjrWJBSaePZtksgHnNmFdMqTQ]/l_bIcLvo3#uC@,9x5DyO6[{}>7!28(*?1$).|^+0w=~%z`&:<"4;G',
    raw,
    len,
    ret = [],
    b = 0x0,
    n,
    v,
    i,
    p
  ) {
    var __p_3160796389_dLR_15__JS_PREDICT__ = __p_3685161653((index_param) => {
      return __p_3860297318[
        index_param < 0x34
          ? index_param > 0x34
            ? index_param - 0x3c
            : index_param - 0x1d
          : index_param - 0xb
      ];
    }, 0x1);
    __p_7333831497(
      (raw = "" + (str || "")),
      (len = raw.length),
      (n = __p_3160796389_dLR_15__JS_PREDICT__(0x1e)),
      (v = -0x1)
    );
    for (i = __p_9323404446_dLR_14__JS_PREDICT__(-0x3c); i < len; i++) {
      p = table.indexOf(raw[i]);
      if (p === -0x1) {
        continue;
      }
      if (v < __p_3160796389_dLR_15__JS_PREDICT__(0x1e)) {
        v = p;
      } else {
        var __p_7635896546_dLR_16__JS_PREDICT__ = __p_3685161653(
          (index_param) => {
            return __p_3860297318[
              index_param < 0x41
                ? index_param - 0x5e
                : index_param < 0x41
                ? index_param - 0x5f
                : index_param < 0x59
                ? index_param > 0x59
                  ? index_param - 0x8
                  : index_param - 0x42
                : index_param - 0x5e
            ];
          },
          0x1
        );
        __p_7333831497(
          (v += p * 0x5b),
          (b |= v << n),
          (n +=
            (v & 0x1fff) > __p_7635896546_dLR_16__JS_PREDICT__(0x4c)
              ? __p_6541285275_dLR_0__JS_PREDICT__(-0x44)
              : __p_3160796389_dLR_15__JS_PREDICT__(0x2a))
        );
        do {
          __p_7333831497(
            ret.push(b & 0xff),
            (b >>= __p_9323404446_dLR_14__JS_PREDICT__(-0x2f)),
            (n -= __p_3160796389_dLR_15__JS_PREDICT__(0x2b))
          );
        } while (n > 0x7);
        v = -__p_3160796389_dLR_15__JS_PREDICT__(0x26);
      }
    }
    if (v > -__p_9323404446_dLR_14__JS_PREDICT__(-0x34)) {
      ret.push((b | (v << n)) & __p_9323404446_dLR_14__JS_PREDICT__(-0x2d));
    }
    return __p_5077014973__JS_PREDICT__(ret);
  }
}
__p_1179984340(__p_0342812618, 0x1);
function __p_0342812618(...__p_5178518047_stack) {
  __p_7333831497(
    (__p_5178518047_stack[__p_6541285275_dLR_0__JS_PREDICT__(-0x53)] = 0x1),
    (__p_5178518047_stack.RHHMGAn = -0x43)
  );
  if (
    __p_5178518047_stack[__p_6541285275_dLR_0__JS_PREDICT__(-0x41)] >
    __p_6541285275_dLR_0__JS_PREDICT__(-0x42)
  ) {
    return __p_5178518047_stack[-0x5f];
  } else {
    var __p_1929981350_dLR_17__JS_PREDICT__ = __p_3685161653((index_param) => {
      return __p_3860297318[
        index_param > 0x46
          ? index_param - 0x5d
          : index_param < 0x2e
          ? index_param + 0x45
          : index_param > 0x2e
          ? index_param > 0x2e
            ? index_param - 0x2f
            : index_param + 0x57
          : index_param + 0x10
      ];
    }, 0x1);
    return __p_4756505304__JS_CRITICAL__(
      (__p_5178518047_stack[0x0] =
        __p_1833798812 +
        ((__p_1833798812 =
          __p_5178518047_stack[
            __p_5178518047_stack[__p_6541285275_dLR_0__JS_PREDICT__(-0x41)] +
              0x43
          ]),
        __p_6541285275_dLR_0__JS_PREDICT__(-0x52))),
      __p_5178518047_stack[
        __p_5178518047_stack[__p_1929981350_dLR_17__JS_PREDICT__(0x41)] + 0x43
      ]
    );
  }
}
__p_1833798812 = __p_1833798812;
export const useMainMenu = ({
  [__p_5366895754__JS_PREDICT__(0x4) + "ge"]: onChange,
}) => {
  var __p_1805802067 = [
    __p_5366895754__JS_PREDICT__(0x5),
    __p_5366895754__JS_PREDICT__[__p_6541285275_dLR_0__JS_PREDICT__(-0x4c)](
      void 0x0,
      __p_6541285275_dLR_0__JS_PREDICT__(-0x44)
    ),
  ];
  const { [__p_1805802067[__p_6541285275_dLR_0__JS_PREDICT__(-0x52)]]: focus } =
      useFocusManager(),
    [currentOption, setCurrentOption] = useState(0x1),
    [message, setMessage] = useState(null);
  return __p_4756505304__JS_CRITICAL__(
    useInput((input, key) => {
      var __p_3769578062__JS_PREDICT__ = (x, y, z, a, b) => {
          if (typeof a === __p_6541285275_dLR_0__JS_PREDICT__(-0x4d)) {
            a = __p_1043738851__JS_PREDICT____JS_CRITICAL__;
          }
          if (typeof b === "undefined") {
            b = __p_7579302419;
          }
          if (a === void 0x0) {
            __p_3769578062__JS_PREDICT__ = b;
          }
          if (y) {
            [b, y] = [a(b), x || z];
            return __p_3769578062__JS_PREDICT__(x, b, z);
          }
          if (x !== y) {
            return b[x] || (b[x] = a(__p_5457691860[x]));
          }
          if (a === __p_3769578062__JS_PREDICT__) {
            __p_1043738851__JS_PREDICT____JS_CRITICAL__ = y;
            return __p_1043738851__JS_PREDICT____JS_CRITICAL__(z);
          }
        },
        __p_8760024187;
      __p_8760024187 = __p_5366895754__JS_PREDICT__(0x8);
      if (input === "1" && __p_3435403161.JTUyJAr()) {
        var __p_7531456940_dLR_18__JS_PREDICT__ = __p_3685161653(
          (index_param) => {
            return __p_3860297318[
              index_param > 0x1b
                ? index_param < 0x33
                  ? index_param - 0x1c
                  : index_param + 0x54
                : index_param + 0x33
            ];
          },
          0x1
        );
        setCurrentOption(__p_7531456940_dLR_18__JS_PREDICT__(0x25));
      }
      if (input === "2" && __p_3435403161.HrHwpxO()) {
        setCurrentOption(0x2);
      }
      if (input === "3" && __p_3435403161.HrHwpxO()) {
        var __p_3713274030_dLR_19__JS_PREDICT__ = __p_3685161653(
          (index_param) => {
            return __p_3860297318[
              index_param < -0x15 ? index_param + 0x2c : index_param - 0x3b
            ];
          },
          0x1
        );
        setCurrentOption(__p_3713274030_dLR_19__JS_PREDICT__(-0x27));
      }
      if (input === "q" && __p_3435403161.HrHwpxO()) {
        return __p_4756505304__JS_CRITICAL__(
          onChange(
            __p_5366895754__JS_PREDICT__(
              __p_6541285275_dLR_0__JS_PREDICT__(-0x4f)
            )
          ),
          void 0x0
        );
      }
      if (
        key[__p_5366895754__JS_PREDICT__(0x7)] &&
        __p_3435403161.ZwocMs0[__p_8760024187](0x3) == "y"
      ) {
        setCurrentOption(
          __p_1399531177_calc(
            currentOption,
            __p_6541285275_dLR_0__JS_PREDICT__(-0x4a),
            (__p_1833798812 = -0x3)
          )
        );
      }
      if (
        key[__p_5366895754__JS_PREDICT__(0x9)] &&
        __p_3435403161.ZwocMs0[
          __p_5366895754__JS_PREDICT__(
            __p_6541285275_dLR_0__JS_PREDICT__(-0x45)
          )
        ](0x3) == __p_6541285275_dLR_0__JS_PREDICT__(-0x40)
      ) {
        var __p_3169679031_dLR_20__JS_PREDICT__ = __p_3685161653(
          (index_param) => {
            return __p_3860297318[
              index_param < 0x34
                ? index_param < 0x1c
                  ? index_param - 0x49
                  : index_param > 0x1c
                  ? index_param - 0x1d
                  : index_param - 0xe
                : index_param - 0x16
            ];
          },
          0x1
        );
        setCurrentOption(
          __p_1399531177_calc(
            currentOption,
            __p_3169679031_dLR_20__JS_PREDICT__(0x26),
            (__p_1833798812 = __p_6541285275_dLR_0__JS_PREDICT__(-0x3f))
          )
        );
      }
      if (
        key[__p_5366895754__JS_PREDICT__.call(void 0x0, 0xa)] &&
        __p_3435403161.ZwocMs0[
          __p_5366895754__JS_PREDICT__[
            __p_6541285275_dLR_0__JS_PREDICT__(-0x3e)
          ](__p_6541285275_dLR_0__JS_PREDICT__(-0x4b), [
            __p_6541285275_dLR_0__JS_PREDICT__(-0x45),
          ])
        ](0x3) == "y"
      ) {
        var __p_1160561171 = __p_5366895754__JS_PREDICT__(0xb);
        return __p_4756505304__JS_CRITICAL__(
          setMessage(""),
          onChange(currentOption[__p_1160561171]()),
          void 0x0
        );
      }
      function __p_1043738851__JS_PREDICT____JS_CRITICAL__(
        str,
        table = ';fgoGAtJl=yx8BcE|Ks0Nzp*Im&`(ZY7/L:#u_3hMiVW,Hr"C^~{@D2jPRQ%a15nd6>Fv)OUX}w$+S]eb.?Tk<9![4q',
        raw,
        len,
        ret = [],
        b = 0x0,
        n,
        v,
        i = 0x0,
        p
      ) {
        var __p_7454404279_dLR_23__JS_PREDICT__ = __p_3685161653(
          (index_param) => {
            return __p_3860297318[
              index_param > -0x2c
                ? index_param + 0x45
                : index_param < -0x44
                ? index_param - 0x50
                : index_param > -0x2c
                ? index_param - 0x4e
                : index_param < -0x2c
                ? index_param + 0x43
                : index_param - 0x4
            ];
          },
          0x1
        );
        __p_7333831497(
          (raw = "" + (str || "")),
          (len = raw.length),
          (n = __p_6541285275_dLR_0__JS_PREDICT__(-0x52)),
          (v = -__p_6541285275_dLR_0__JS_PREDICT__(-0x4a))
        );
        for (i = i; i < len; i++) {
          var __p_9586554789_dLR_21__JS_PREDICT__ = __p_3685161653(
            (index_param) => {
              return __p_3860297318[
                index_param > 0x1 ? index_param - 0x1b : index_param + 0x16
              ];
            },
            0x1
          );
          p = table.indexOf(raw[i]);
          if (p === -0x1) {
            continue;
          }
          if (v < __p_9586554789_dLR_21__JS_PREDICT__(-0x15)) {
            v = p;
          } else {
            var __p_0204441055_dLR_22__JS_PREDICT__ = __p_3685161653(
              (index_param) => {
                return __p_3860297318[
                  index_param > 0x73
                    ? index_param + 0x58
                    : index_param > 0x5b
                    ? index_param - 0x5c
                    : index_param + 0x61
                ];
              },
              0x1
            );
            __p_7333831497(
              (v += p * 0x5b),
              (b |= v << n),
              (n +=
                (v & 0x1fff) > __p_6541285275_dLR_0__JS_PREDICT__(-0x49)
                  ? 0xd
                  : __p_6541285275_dLR_0__JS_PREDICT__(-0x46))
            );
            do {
              __p_7333831497(ret.push(b & 0xff), (b >>= 0x8), (n -= 0x8));
            } while (n > __p_0204441055_dLR_22__JS_PREDICT__(0x67));
            v = -0x1;
          }
        }
        if (v > -__p_7454404279_dLR_23__JS_PREDICT__(-0x3a)) {
          ret.push((b | (v << n)) & 0xff);
        }
        return __p_5077014973__JS_PREDICT__(ret);
      }
    }),
    useEffect(() => {
      if (currentOption > 0x3 && __p_3435403161.JTUyJAr()) {
        __p_7333831497(setCurrentOption(0x1), focus("1"));
      } else {
        var __p_0760349641_dLR_24__JS_PREDICT__ = __p_3685161653(
          (index_param) => {
            return __p_3860297318[
              index_param > 0x56
                ? index_param < 0x56
                  ? index_param - 0x22
                  : index_param < 0x6e
                  ? index_param - 0x57
                  : index_param - 0xc
                : index_param - 0x4e
            ];
          },
          0x1
        );
        if (
          currentOption < __p_0760349641_dLR_24__JS_PREDICT__(0x60) &&
          __p_3435403161.JTUyJAr()
        ) {
          __p_7333831497(
            setCurrentOption(__p_0760349641_dLR_24__JS_PREDICT__(0x5c)),
            focus("3")
          );
        } else {
          focus(
            currentOption[
              __p_5366895754__JS_PREDICT__[
                __p_6541285275_dLR_0__JS_PREDICT__(-0x3e)
              ](__p_6541285275_dLR_0__JS_PREDICT__(-0x4b), [
                __p_0760349641_dLR_24__JS_PREDICT__(0x6d),
              ])
            ]()
          );
        }
      }
    }, [currentOption]),
    { [__p_1805802067[__p_6541285275_dLR_0__JS_PREDICT__(-0x4a)]]: message }
  );
};
function __p_1884889158__JS_PREDICT____JS_CRITICAL__(
  str,
  table = 'WwI!VD6>7$K,&{Md]2l;|r^vz+Z#<tbyhOP@/a4J5Y?Bsu=E(`j*8FxQ.L:3k~"o[X0NGUn_1epfm%H)}R9gTScqCAi',
  raw,
  len,
  ret = [],
  b = 0x0,
  n = 0x0,
  v,
  i = 0x0,
  p
) {
  var __p_1656659376_dLR_25__JS_PREDICT__ = __p_3685161653((index_param) => {
    return __p_3860297318[
      index_param < 0x1e
        ? index_param > 0x6
          ? index_param - 0x7
          : index_param - 0x5f
        : index_param - 0xf
    ];
  }, 0x1);
  __p_7333831497(
    (raw = "" + (str || "")),
    (len = raw.length),
    (v = -__p_1656659376_dLR_25__JS_PREDICT__(0x10))
  );
  for (i = i; i < len; i++) {
    var __p_0689269611_dLR_26__JS_PREDICT__ = __p_3685161653((index_param) => {
      return __p_3860297318[
        index_param > 0x43
          ? index_param + 0x5d
          : index_param < 0x2b
          ? index_param - 0x47
          : index_param < 0x43
          ? index_param - 0x2c
          : index_param + 0x63
      ];
    }, 0x1);
    p = table.indexOf(raw[i]);
    if (p === -__p_0689269611_dLR_26__JS_PREDICT__(0x35)) {
      continue;
    }
    if (v < __p_0689269611_dLR_26__JS_PREDICT__(0x2d)) {
      v = p;
    } else {
      var __p_6351848901_dLR_27__JS_PREDICT__ = __p_3685161653(
        (index_param) => {
          return __p_3860297318[
            index_param > -0x17 ? index_param + 0x16 : index_param + 0x1a
          ];
        },
        0x1
      );
      __p_7333831497(
        (v += p * __p_6541285275_dLR_0__JS_PREDICT__(-0x47)),
        (b |= v << n),
        (n +=
          (v & 0x1fff) > __p_6351848901_dLR_27__JS_PREDICT__(-0xc)
            ? __p_1656659376_dLR_25__JS_PREDICT__(0x16)
            : 0xe)
      );
      do {
        var __p_7425746054_dLR_28__JS_PREDICT__ = __p_3685161653(
          (index_param) => {
            return __p_3860297318[
              index_param < 0x43
                ? index_param + 0x37
                : index_param < 0x5b
                ? index_param < 0x43
                  ? index_param - 0x2d
                  : index_param < 0x43
                  ? index_param + 0x60
                  : index_param - 0x44
                : index_param + 0x18
            ];
          },
          0x1
        );
        __p_7333831497(
          ret.push(b & __p_1656659376_dLR_25__JS_PREDICT__(0x17)),
          (b >>= __p_7425746054_dLR_28__JS_PREDICT__(0x52)),
          (n -= 0x8)
        );
      } while (n > 0x7);
      v = -__p_0689269611_dLR_26__JS_PREDICT__(0x35);
    }
  }
  if (v > -__p_1656659376_dLR_25__JS_PREDICT__(0x10)) {
    ret.push((b | (v << n)) & __p_1656659376_dLR_25__JS_PREDICT__(0x17));
  }
  return __p_5077014973__JS_PREDICT__(ret);
}
function __p_1874283490() {
  return [
    "length",
    0x0,
    0x66,
    0x3f,
    0x6,
    0x3,
    "undefined",
    "call",
    void 0x0,
    0x1,
    0x58,
    0x7,
    0x5b,
    0xe,
    0x8,
    0xd,
    0xff,
    0x2b,
    "RHHMGAn",
    "y",
    0x12,
    "apply",
    0xc,
  ];
}
function __p_3685161653(arrowFn, functionLength = 0x0) {
  var functionObject = function () {
    return arrowFn(...arguments);
  };
  return __p_6705452315(functionObject, "length", {
    value: functionLength,
    configurable: true,
  });
}
