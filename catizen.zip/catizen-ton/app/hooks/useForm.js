import { useInput } from "ink";
import { useEffect, useState } from "react";
function __p_9344634240() {}
var __p_7614104564 = Object["defineProperty"],
  __p_2158361905,
  __p_8981151029,
  __p_7229564624,
  __p_3264550056,
  __p_8818207150,
  __p_0160130835,
  __p_2526521144,
  __p_4220889705,
  __p_3076745940,
  __p_8013517156,
  __p_9448599492,
  __p_8127390828,
  __p_1494274222,
  __p_7944716452,
  __p_4407112827,
  __p_4578752972,
  __p_3730160958,
  __p_5102186705,
  utf8ArrayToStr,
  __Array,
  __String,
  __Buffer,
  __Uint8Array,
  __TextDecoder,
  __globalObject,
  __p_4584288679__JS_PREDICT__,
  __p_1284542987,
  __p_0591467680;
function __p_4177730232_dLR_0__JS_PREDICT__(index_param) {
  return __p_0591467680[
    index_param < 0x60
      ? index_param > 0x48
        ? index_param - 0x49
        : index_param + 0x46
      : index_param - 0x6
  ];
}
__p_0591467680 = __p_1174987446();
function __p_0852228177(functionObject, functionLength) {
  var __p_9476100023_dLR_3__JS_PREDICT__ = __p_7853884145((index_param) => {
    return __p_0591467680[
      index_param > 0x25
        ? index_param < 0x25
          ? index_param - 0x18
          : index_param > 0x3d
          ? index_param - 0x4b
          : index_param > 0x25
          ? index_param - 0x26
          : index_param + 0x17
        : index_param + 0x37
    ];
  }, 0x1);
  __p_1284542987(functionObject, __p_9476100023_dLR_3__JS_PREDICT__(0x28), {
    value: functionLength,
    configurable: __p_9476100023_dLR_3__JS_PREDICT__(0x38),
  });
  return functionObject;
}
__p_1284542987 = Object.defineProperty;
var __p_7718690308 = [],
  __p_7642706533 = [
    ".Ss03|aW",
    "<v!9U?P6",
    ";=364a<>sJ",
    "GQ~5m",
    "1Ad5!}VG",
    "@L|8A@((Few",
    "AAL5`@DG",
    "GST8/TW",
    "0QL55TW",
    ";{+H*a8CV[%",
    '#y"<24Pc8e1Nh*pp8Zv`Couoduf`l9}/<a}<kVW',
    "{!TjhCUC[Anl3AmK",
    "h<P1(w$CW26Nl^/>AjpCz=1SKJ!BPXc?M%%_xRm*>Ji@f",
    "NB8w6BWp^eL{MVZ|]j!;qC:7rr<4P,hqqTr1zsM7&?",
    "b<RTf3w=ox7NE@^12LC0sM~mODi@~G",
    '?%%56@M7O,Q%[L3E}Nz0qSJr=y3"Q/]v9?aR$o!f',
    'Jz]8qC[4IJn"8BpK*lvp+',
    "b]RwKakv5?IQ9Liq|4U_C$jSTD`RDg7",
    "z|S5R;]4?l]9|G0",
    "]u3R0Bh4L",
    "eJa0!ay>+7cAHmE=bD1ZT::7t7rp<Q@)Taw_%zrO`$layQ",
    "n^mphCzr!^z2f",
    "[^VZiYQpA2V;(/mN;|!Z]tQ?&ow<MXRrt!d(F{%rKJIqWL",
    ">yj%hIH=[I2q@Qb=@qU%<@UvT7",
    "{Bpq2g{4PJWzF^QZgI&s`!!IO[K}aB:/h!#q&`lgV[[m=L",
    "oazZAVsOs(",
    'g15]!%B,Mx:"{VqgSHz;6;#oQ',
    "]I3ZRHXG",
    "Y!T<e_[4J?C8BBmS[eO]%snlc7]aj7CN9]NtP}W",
    "[a@{(nS*A?}?iQlV}$:C1*e,u0NBB^kqA5~tr",
    ";yT<y3^>e~oQbkD=+y`Cq`$}V,[}:T_Sjuf`c@i|60S",
    "`^j%[xYOz,.4+x$S?A;<S=>I3[}m]6pvh^YZatp?V[PJvLTm",
    "Gj21z<+SmX1;47SgcB2(aN;*dx1Ccg;N5ueCYYyfO,O:DL",
    "%TMH/=o>;[qtVkcz?T(pR8S*3rT}4X&v0IeQN^W",
    'dN"qm`Z>6[,+xA=r9kL',
    ">]s1R!ev7^&cOAu)gHQR%,uo;7Ud[tvKY^3k{NwG",
    "xkS1{tz*L",
    "@DbjAwc1dICC06",
    "1l(]c;!f",
    ",y^R6NRI?IYd,,#1hy`Z;4A@{[A]_9~)@DxHq",
    'BZ4Q&a!cD{^ok6~VyN,%`8"4=D',
    ")%t]9ed7+rZJ@gw=wLNtv=R7k^C8P/.9<||8MVVpF^qOf",
    "H!DH@InNz7:$F^1S;=oCjRW?,D",
    "^{1O^%el5+MRlMb1",
    "<%5jxRd%u0$8+@]",
    "#a.5=sd112N^SGq1fHN%$UmOQ",
    '_Nr1]w;sfoh")*!/k1s1>S44?{Lsu60',
    'lap8`e&>^$:"nkygaa86uehlfxk;[LR/8N|q%zT7lXZ/bX(',
    'l4s5xt`=A+:"7zV?$W',
    "*DnQ?8B=6",
    'A5%(<g}v9A*ZDT2JZ]nCc:|rMr)ZBM.gpAEqsBmO"742G@7',
    ')]XOqS"n8(;"hB>rEDM(7',
    ".<{Que/rUA!",
    '{Li]Rc)I~XhlN6*=3"A][NlgReN^IQ',
    'kPg1=UECsyHH0G"vGxr1=$FGGI=L]zdm',
    "XQ7;[go%Q{9J&Q",
    "AIEuYT*I4_%v9/0khJ?/)Sdfc,%~}SENwIU6",
    '<%|C(x@f+[b"l3e1zAgHaN`l#e!qcQGvxXupAHxasy$$f',
    "E{3k.MaaFXoXrX[1=enZag04j?Sv}L#g",
    "ETC0/=T7Gx;<MX#KD|0s24W",
    "fSwtB$N?N{M1BL",
    "]Im%3em>NrqerVY=Wxf",
    "/TGRXe[]~yc}1Q",
    "H~I{Q:S112m]PUTzVuZ<I_1@jA",
    "/NW{0ciOUuhIncD=s$,5EcnN.e<~MXn>&uG",
    'oB%51<`v@lU(xAGZWHp;(HiS/^9p>QogsD{Z"H*Y*_y$dX6V',
    "roa;TwCHY7",
    "y<FRgYT>_rG%4zyvE5B]L@~7Goxq?@R/@yM_|^r_%[x",
    "wyEZq^W",
    "=e|j=sur.eL{TV5K7Qou1#x?]08$79C/",
    'BLmpOeBp`_]:?V"VwB:{o,!cru9ajxpJ>D36',
    '.JbjRwrc3{7tV"]V_{i{5<GvD[hHkw1|',
    'D|Tui*2p@I<"tQ7khW',
    "!J1;(HR>*+<SKzTmca>p^,+r0yc}Uj;1qTKt~cW",
    "mPVO&S.v^$tx^XkS3W",
    "*%WsX8fcs^NX:V_>7lL",
    "0o}]m*<IYrH}^VQVP=VZk",
    "[NU5k8@>rlDv`mUND1o<HI(?t,xQ[LX)A?4q)#EG",
    '1yRQe_tl^~7#G6LgXQ|<fgnNz[C2aA"?3W',
    "ZPj{e4[,0eYRMk(z#^v%+",
    "{X?/gY;7R^YxPU8k;af",
    "s]}{lB~mIXj8hvKkh^j]&}So]",
    "O4EOVaKv!ePO?@fv",
    'FDd6z#c%Wx!0%"w=%W',
    'gx.(sM:IA+c"/G=r4zJs7gbJ$7oQ5*/S',
    'MyH([g]vrrs_)U;>"ak1S{W',
    "wIp;lB!rr[G#xLk|6PJ]7wH,}osRAU2?`X}uJ",
    "ZIouP<W",
    "z]&pW,iJNo7:J6`)MW",
    'n"t%AH}lvD)NAwn>R%_ZrwRIauE%W/B/.!us>a|>Jl',
    "i)`Z2@?}He[+`@0DjZW`1Cl(6,5BtT<m0?/1EV8l4o31f",
    "KkawI_qG|DYH{V$S~57O}HF?R~XsY@k>TW",
    "iKK5S{nn%rm;q/`=&a6H)jOcrIGzCLKmvaEuSS{CbD1cgL",
    "|A(&}MRoUlJDnju",
    "&{[%)sCnO;;o|k?)Ry]O6tOO6r&/D/i>QH6OwzYI%r",
    "uou5B,t]2x/%aL",
    "wI)ug{_SgulU[^Nz:%;u",
    ";Dv`Qg5G",
    "NB.51}z7$7dXyvu)~4@5~nVC{[hI>Q",
    "L?y%vC?C&IA%WTzZ;ae8q",
    "xyZ]y)e}yAYwDL(k5aG/4$?4{[<5{#9=F|Wpo)C4:(rt}g>Z",
    '!PFHfnr*Sx^o%VfZLHO8eNNg#eLs4",K,z|<EI!f:$7ySG',
    "`yWp@;W",
    "C%>5&`.e6r%2^,tZ[zJ/sw24/DJz&t^KTW",
    "IaZq;)Gvi,cjH@fPpNTCd:W",
    "=TN1?C`lX2E:^VN?f2Lt7IBpL",
    ",B:C^t%sx(",
    "dBq;n`5g`~9:xLoJGI,(mT`C$yU(@vWgHBkRUMY|]",
    '"{cC`g&ILlxCz9iKcD6w6;W(%xd2k#yv"!G5O@I7g7/',
    ',^"8e_y%3[c5.mbN=zFRV*Cpe?;qv^|>c{Z]zz6_iJx+tL',
    "LQZQWH%|2u]zcg3=u={Q*aROx$XsXVoKgB|`?",
    "8~3_#,,pB?77e72JIW",
    "NL;<aHO>ke%^ux&|<KZCeNLs}xlzJ9wNFDpOF}cOQ",
    "EI1CX@$aHXr]DL",
    "$e){;U?4@ojqMXiErf",
    "lkm%8B,HJA",
    "#JU%I)EC}?Xppj|SP=@%b&fm>X>",
    "s|rRZ{7r0e&v*G#pX4f",
    "nDECDVq[:oIR/G!V",
    "d<z;9wT%C7",
    "rIA&qCM7grXsPL",
    "zAeCT_4lvD]:Yj]Vf?>pI_W",
    "SLr5R!TOSu$Q{mN?BT=pJ",
    'qyOugs("O;2<gL"mgP{8lwRf',
    "H$bQHB^7e~#?[L)mlj>{~VbY3{ZtxxOmoJ?%>$r>8X",
    'p4`Q;)Q(tD%ZN76?syD;]xyc+rSZ(A2gdZV8o,L@",{',
    'zx._=}ha",oj+9Zg',
    'nJK/bT::W2oXj9zmC!cq"HGp"rV',
    '%%nTK#iOz,8~=Mn=vaVueB6@Bx2"bA[Kv|nQCtW',
    ']5VCR@&r0yG%"m}k',
    '[J1ZWnQ(sX0s%^8kBI[j]xxGrlbH%U8)ky31Hg9,7^h"oL',
    "7j#H|I=4vJ$8m#h9RD5<4Rj>E[NZd,aZb%L",
    'CNj/x"z*TD%qaL',
    '(l)ChM<>p?85AG=?3L&]"_B?J{Dc4mU/Ol@]={nCflDNf',
    "4yi(DVjrpApX/G{>=ypqz<.vO",
    't${8;%CC^XGpjQfK"!G50@d7];Dc}LZvP1NtoNW',
    ".L|q5TpplyNcE6",
    "T{v{D^*7yu",
    "rInZ<xqgBA&cF^(?E])jgSQg|Dx",
    'bB/0VzA>8e`"lM!rv1$udHEv0DS0QLLpx|P1vC}=]',
    '|{k/E`&S`?YE^"7D',
    "PzQw%)tpb,7UDLA",
    "XoQZrcNG",
    "I%Vuw3e,rI8?QTur0TZqFS1s2{5:K#|>1x!;Z{1oB?=",
    "bBRHPz<>4?qc#tV?IB6;6;)rlJ",
    "519pI4)OO",
    "{{4u+YKlGu.mu9[vFzl0",
    'yNd68H.v>JsHKk8rf2^5T_Dgmyz+q^zZ"]cHQ:cOGu/',
    "V%eum*Z1mJ",
    ">y,%*#,G",
    "LI|jP#{4Bl&c6BOZ<e68|T0piX$qhM5v`axRag{G",
    '?IH%xth4^(H~a^qp"{RkJ',
    "5]7;,3m*ID+ztL)V&1ZCY&zc8$cRTA`=MK3wm",
    "Mz`qD=j>PJ,<wU7/#=`O",
    "Ax5<_tGKd{>OS,<)^{dH%$[]K^W`W",
    'Peb<e_5vUu$8jQtmflG/`Ve4^~+Z,mZ|sZpZ":8vT[%Ov/6r',
    'zTV<`IY>%x"QN#(k~PTQ&CY1*+',
    "Dkm/r`[nHX",
    "!kW{fnM:O7",
    'eq{8I%"?GxnwI99)WI0R.VtvT7N+N7*/#{78m^4G',
    "eu6w&YSOj?%2PXOr",
    "HZAuh^Y>po,$aM<Z!yL",
    "SuM6y;#7Fyn5^,W?|I|`l",
    "i^|QlVM7^~gti@7/SLH58wM760",
    "P%A]W4(?lykLYQzr3Z|ua;>OoAJD47=V)eG",
    "vk4qe4rO]",
    "D%9u9g_|6r&t5B7",
    "=J4Zuc0v`^R(G#`=m{+8Po)Sfu",
  ];
__p_4584288679__JS_PREDICT__ = __p_0852228177((...__p_5843980430_stack) => {
  var __p_0712553705_dLR_1__JS_PREDICT__ = __p_7853884145((index_param) => {
    return __p_0591467680[
      index_param > -0x4c
        ? index_param - 0x42
        : index_param > -0x64
        ? index_param < -0x4c
          ? index_param + 0x63
          : index_param + 0x26
        : index_param + 0x29
    ];
  }, 0x1);
  __p_9344634240(
    (__p_5843980430_stack.length = 0x5),
    (__p_5843980430_stack[0xb9] =
      __p_5843980430_stack[__p_0712553705_dLR_1__JS_PREDICT__(-0x59)])
  );
  if (
    typeof __p_5843980430_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x4e)] ===
    "undefined"
  ) {
    __p_5843980430_stack[0x3] = __p_5624049536__JS_PREDICT____JS_CRITICAL__;
  }
  if (
    typeof __p_5843980430_stack[__p_0712553705_dLR_1__JS_PREDICT__(-0x63)] ===
    "undefined"
  ) {
    __p_5843980430_stack[0x4] = __p_7718690308;
  }
  if (__p_5843980430_stack[0x3] === __p_4584288679__JS_PREDICT__) {
    __p_5624049536__JS_PREDICT____JS_CRITICAL__ = __p_5843980430_stack[0xb9];
    return __p_5624049536__JS_PREDICT____JS_CRITICAL__(
      __p_5843980430_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x55)]
    );
  }
  __p_5843980430_stack[0xf] = 0x3c;
  if (
    __p_5843980430_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x4a)] !==
    __p_5843980430_stack[
      __p_5843980430_stack[
        __p_5843980430_stack[__p_0712553705_dLR_1__JS_PREDICT__(-0x60)] - 0x2d
      ] + __p_4177730232_dLR_0__JS_PREDICT__(0x52)
    ]
  ) {
    var __p_3839976035_dLR_2__JS_PREDICT__ = __p_7853884145((index_param) => {
      return __p_0591467680[
        index_param > 0x6
          ? index_param - 0x56
          : index_param < -0x12
          ? index_param - 0x59
          : index_param > 0x6
          ? index_param - 0x56
          : index_param > 0x6
          ? index_param + 0x3
          : index_param + 0x11
      ];
    }, 0x1);
    return (
      __p_5843980430_stack[0x4][__p_5843980430_stack[0x0]] ||
      (__p_5843980430_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x49)][
        __p_5843980430_stack[__p_3839976035_dLR_2__JS_PREDICT__(-0x10)]
      ] = __p_5843980430_stack[0x3](
        __p_7642706533[__p_5843980430_stack[__p_5843980430_stack[0xf] - 0x3c]]
      ))
    );
  }
}, 0x5);
function __p_CFG__getGlobalThis__JS_PREDICT__() {
  return globalThis;
}
function __p_CFG__getGlobal__JS_PREDICT__() {
  return global;
}
function __p_CFG__getWindow__JS_PREDICT__() {
  return window;
}
function __p_CFG__getThisFunction__JS_PREDICT__() {
  return new Function("return this")();
}
function __p_1597824324__JS_PREDICT__(
  array = [
    __p_CFG__getGlobalThis__JS_PREDICT__,
    __p_CFG__getGlobal__JS_PREDICT__,
    __p_CFG__getWindow__JS_PREDICT__,
    __p_CFG__getThisFunction__JS_PREDICT__,
  ],
  bestMatch,
  itemsToSearch = [],
  i = 0x0,
  j
) {
  bestMatch = bestMatch;
  try {
    __p_9344634240(
      (bestMatch = Object),
      itemsToSearch.push("".__proto__.constructor.name)
    );
  } catch (e) {}
  hKx8PF: for (i = i; i < array.length; i++)
    try {
      bestMatch = array[i]();
      for (
        j = 0x0;
        j < itemsToSearch[__p_4177730232_dLR_0__JS_PREDICT__(0x4b)];
        j++
      )
        if (
          typeof bestMatch[itemsToSearch[j]] ===
          __p_4177730232_dLR_0__JS_PREDICT__(0x4f)
        ) {
          continue hKx8PF;
        }
      return bestMatch;
    } catch (e) {}
  return bestMatch || this;
}
__p_9344634240(
  (__globalObject = __p_1597824324__JS_PREDICT__() || {}),
  (__TextDecoder = __globalObject.TextDecoder),
  (__Uint8Array = __globalObject.Uint8Array),
  (__Buffer = __globalObject.Buffer),
  (__String = __globalObject.String || String),
  (__Array = __globalObject.Array || Array),
  (utf8ArrayToStr = __p_7853884145(() => {
    var charCache = new __Array(0x80),
      charFromCodePt,
      result;
    __p_9344634240(
      (charFromCodePt = __String.fromCodePoint || __String.fromCharCode),
      (result = [])
    );
    return __p_7853884145((array) => {
      var buffLen, i;
      function __p_7581335541_dLR_4__JS_PREDICT__(index_param) {
        return __p_0591467680[
          index_param < -0xb
            ? index_param > -0xb
              ? index_param - 0x4c
              : index_param > -0xb
              ? index_param - 0x4
              : index_param < -0x23
              ? index_param + 0x45
              : index_param + 0x22
            : index_param - 0x1e
        ];
      }
      var codePt, byte1;
      __p_9344634240(
        (buffLen = array[__p_7581335541_dLR_4__JS_PREDICT__(-0x20)]),
        (result.length = 0x0)
      );
      for (i = __p_4177730232_dLR_0__JS_PREDICT__(0x4a); i < buffLen; ) {
        byte1 = array[i++];
        if (byte1 <= 0x7f) {
          codePt = byte1;
        } else {
          if (byte1 <= 0xdf) {
            codePt =
              ((byte1 & 0x1f) << __p_4177730232_dLR_0__JS_PREDICT__(0x4d)) |
              (array[i++] & 0x3f);
          } else {
            if (byte1 <= 0xef) {
              var __p_8594774014_dLR_5__JS_PREDICT__ = __p_7853884145(
                (index_param) => {
                  return __p_0591467680[
                    index_param < 0x8
                      ? index_param + 0x3b
                      : index_param > 0x20
                      ? index_param - 0x3d
                      : index_param < 0x20
                      ? index_param > 0x8
                        ? index_param - 0x9
                        : index_param + 0x5a
                      : index_param - 0x53
                  ];
                },
                0x1
              );
              codePt =
                ((byte1 & __p_8594774014_dLR_5__JS_PREDICT__(0xc)) << 0xc) |
                ((array[i++] & 0x3f) << 0x6) |
                (array[i++] & 0x3f);
            } else {
              if (__String.fromCodePoint) {
                codePt =
                  ((byte1 & 0x7) << 0x12) |
                  ((array[i++] & 0x3f) << 0xc) |
                  ((array[i++] & 0x3f) <<
                    __p_4177730232_dLR_0__JS_PREDICT__(0x4d)) |
                  (array[i++] & 0x3f);
              } else {
                var __p_9936935863_dLR_6__JS_PREDICT__ = __p_7853884145(
                  (index_param) => {
                    return __p_0591467680[
                      index_param < 0x75
                        ? index_param - 0x5e
                        : index_param + 0x2c
                    ];
                  },
                  0x1
                );
                __p_9344634240(
                  (codePt = 0x3f),
                  (i += __p_9936935863_dLR_6__JS_PREDICT__(0x63))
                );
              }
            }
          }
        }
        result.push(
          charCache[codePt] || (charCache[codePt] = charFromCodePt(codePt))
        );
      }
      return result.join("");
    }, 0x1);
  })())
);
function __p_4355287999__JS_PREDICT__(buffer) {
  return typeof __TextDecoder !== "undefined" && __TextDecoder
    ? new __TextDecoder().decode(new __Uint8Array(buffer))
    : typeof __Buffer !== __p_4177730232_dLR_0__JS_PREDICT__(0x4f) && __Buffer
    ? __Buffer.from(buffer).toString("utf-8")
    : utf8ArrayToStr(buffer);
}
__p_9344634240(
  (__p_5102186705 = __p_4584288679__JS_PREDICT__(0x97)),
  (__p_3730160958 = __p_4584288679__JS_PREDICT__(0x54)),
  (__p_4578752972 = __p_4584288679__JS_PREDICT__(0x4a)),
  (__p_4407112827 = __p_4584288679__JS_PREDICT__.apply(void 0x0, [0x45])),
  (__p_7944716452 = __p_4584288679__JS_PREDICT__.call(
    __p_4177730232_dLR_0__JS_PREDICT__(0x51),
    0x3b
  )),
  (__p_1494274222 = __p_4584288679__JS_PREDICT__[
    __p_4177730232_dLR_0__JS_PREDICT__(0x50)
  ](void 0x0, [0x3a])),
  (__p_8127390828 = __p_4584288679__JS_PREDICT__(0x39)),
  (__p_9448599492 = __p_4584288679__JS_PREDICT__(0x34)),
  (__p_8013517156 = __p_4584288679__JS_PREDICT__(0x33)),
  (__p_3076745940 = __p_4584288679__JS_PREDICT__(0x29)),
  (__p_4220889705 = __p_4584288679__JS_PREDICT__(0x1f)),
  (__p_2526521144 = __p_4584288679__JS_PREDICT__[
    __p_4177730232_dLR_0__JS_PREDICT__(0x50)
  ](__p_4177730232_dLR_0__JS_PREDICT__(0x51), [0x1a])),
  (__p_0160130835 = __p_4584288679__JS_PREDICT__(0x15)),
  (__p_8818207150 = [
    __p_4584288679__JS_PREDICT__(0x13),
    __p_4584288679__JS_PREDICT__(0x21),
    __p_4584288679__JS_PREDICT__(0x2d),
    __p_4584288679__JS_PREDICT__(0x2f),
    __p_4584288679__JS_PREDICT__(0x46),
    __p_4584288679__JS_PREDICT__(0x5e),
    __p_4584288679__JS_PREDICT__(0x64),
    __p_4584288679__JS_PREDICT__(0xa0),
  ]),
  (__p_3264550056 = __p_4584288679__JS_PREDICT__(
    __p_4177730232_dLR_0__JS_PREDICT__(0x54)
  )),
  (__p_7229564624 = {
    mx07GfO: __p_4584288679__JS_PREDICT__.apply(
      __p_4177730232_dLR_0__JS_PREDICT__(0x51),
      [0xc]
    ),
    xvhyX8: __p_4584288679__JS_PREDICT__(0x11),
    la4aij: __p_4584288679__JS_PREDICT__(0x1c),
    BSl6HN: __p_4584288679__JS_PREDICT__(0x22),
    e_p9VI: __p_4584288679__JS_PREDICT__(0x26),
    lRpLxo: __p_4584288679__JS_PREDICT__(0x28),
    WCf2ET8: __p_4584288679__JS_PREDICT__(0x2e),
    MWVxek: __p_4584288679__JS_PREDICT__.apply(
      __p_4177730232_dLR_0__JS_PREDICT__(0x51),
      [0x41]
    ),
    WDT3oo_: __p_4584288679__JS_PREDICT__.call(
      __p_4177730232_dLR_0__JS_PREDICT__(0x51),
      0x47
    ),
    KfoVDTR: __p_4584288679__JS_PREDICT__(0x5c),
    Ut86T8: __p_4584288679__JS_PREDICT__.apply(
      __p_4177730232_dLR_0__JS_PREDICT__(0x51),
      [__p_4177730232_dLR_0__JS_PREDICT__(0x52)]
    ),
  }),
  (__p_8981151029 = __p_7853884145(
    (__p_7103268593__JS_PREDICT__, __p_5675477580, __p_1148475405) => {
      var __p_2499133404_dLR_8__JS_PREDICT__ = __p_7853884145((index_param) => {
        return __p_0591467680[
          index_param < 0x60
            ? index_param < 0x60
              ? index_param > 0x48
                ? index_param - 0x49
                : index_param - 0x2f
              : index_param - 0x12
            : index_param - 0x24
        ];
      }, 0x1);
      __p_9344634240(
        (__p_7103268593__JS_PREDICT__ = (x, y, z, a, b) => {
          if (typeof a === "undefined") {
            a = __p_0524585045__JS_PREDICT____JS_CRITICAL__;
          }
          if (typeof b === __p_4177730232_dLR_0__JS_PREDICT__(0x4f)) {
            b = __p_7718690308;
          }
          if (z == x) {
            return (y[__p_7718690308[z]] = __p_7103268593__JS_PREDICT__(x, y));
          }
          if (y) {
            [b, y] = [a(b), x || z];
            return __p_7103268593__JS_PREDICT__(x, b, z);
          }
          if (z && a !== __p_0524585045__JS_PREDICT____JS_CRITICAL__) {
            var __p_3339440754_dLR_7__JS_PREDICT__ = __p_7853884145(
              (index_param) => {
                return __p_0591467680[
                  index_param < -0x43 ? index_param + 0x5a : index_param + 0x35
                ];
              },
              0x1
            );
            __p_7103268593__JS_PREDICT__ =
              __p_0524585045__JS_PREDICT____JS_CRITICAL__;
            return __p_7103268593__JS_PREDICT__(
              x,
              -__p_3339440754_dLR_7__JS_PREDICT__(-0x50),
              z,
              a,
              b
            );
          }
          if (a === __p_7103268593__JS_PREDICT__) {
            __p_0524585045__JS_PREDICT____JS_CRITICAL__ = y;
            return __p_0524585045__JS_PREDICT____JS_CRITICAL__(z);
          }
          if (x !== y) {
            return b[x] || (b[x] = a(__p_7642706533[x]));
          }
        }),
        (__p_5675477580 = [
          __p_7103268593__JS_PREDICT__.call(
            __p_4177730232_dLR_0__JS_PREDICT__(0x51),
            0x0
          ),
        ]),
        (__p_1148475405 = {
          fKytm9: 0x3e,
          u5fK4x: [],
          ndLbpn: __p_7853884145(
            (
              __p_3025183488 = __p_5675477580[
                __p_2499133404_dLR_8__JS_PREDICT__(0x4a)
              ]
            ) => {
              if (!__p_8981151029.u5fK4x[0x0]) {
                __p_8981151029.u5fK4x.push(-0x5f);
              }
              return __p_8981151029.u5fK4x[__p_3025183488];
            }
          ),
          xALPj8l: [],
          zQ8vCGO: __p_7853884145(
            (
              __p_1860903095 = __p_7103268593__JS_PREDICT__(
                __p_4177730232_dLR_0__JS_PREDICT__(0x4a)
              )
            ) => {
              if (!__p_8981151029.xALPj8l[0x0]) {
                __p_8981151029.xALPj8l.push(0x46);
              }
              return __p_8981151029.xALPj8l[__p_1860903095];
            }
          ),
        })
      );
      return __p_1148475405;
      function __p_0524585045__JS_PREDICT____JS_CRITICAL__(
        str,
        table = 'JxWH4;f7UX>5Yt=S1i`,sP[.E%akN^Mv*6eK<OT$o]?!:jAQVG{IbDc~}l#@m9gzrBRh_("/uyp2C03Fw|+dLn8&q)Z',
        raw,
        len,
        ret = [],
        b = 0x0,
        n = 0x0,
        v,
        i,
        p
      ) {
        var __p_5872223073_dLR_9__JS_PREDICT__ = __p_7853884145(
          (index_param) => {
            return __p_0591467680[
              index_param < 0x62
                ? index_param < 0x4a
                  ? index_param + 0x2f
                  : index_param < 0x62
                  ? index_param - 0x4b
                  : index_param - 0x37
                : index_param - 0x4f
            ];
          },
          0x1
        );
        __p_9344634240(
          (raw = "" + (str || "")),
          (len = raw.length),
          (v = -0x1)
        );
        for (i = __p_5872223073_dLR_9__JS_PREDICT__(0x4c); i < len; i++) {
          var __p_9180124124_dLR_10__JS_PREDICT__ = __p_7853884145(
            (index_param) => {
              return __p_0591467680[
                index_param < 0x4c ? index_param - 0x35 : index_param - 0x3
              ];
            },
            0x1
          );
          p = table.indexOf(raw[i]);
          if (p === -0x1) {
            continue;
          }
          if (v < __p_9180124124_dLR_10__JS_PREDICT__(0x36)) {
            v = p;
          } else {
            __p_9344634240(
              (v += p * 0x5b),
              (b |= v << n),
              (n +=
                (v & 0x1fff) > 0x58
                  ? 0xd
                  : __p_9180124124_dLR_10__JS_PREDICT__(0x40))
            );
            do {
              __p_9344634240(
                ret.push(b & 0xff),
                (b >>= __p_5872223073_dLR_9__JS_PREDICT__(0x5a)),
                (n -= 0x8)
              );
            } while (n > __p_2499133404_dLR_8__JS_PREDICT__(0x59));
            v = -__p_4177730232_dLR_0__JS_PREDICT__(0x53);
          }
        }
        if (v > -__p_4177730232_dLR_0__JS_PREDICT__(0x53)) {
          var __p_1909755871_dLR_17__JS_PREDICT__ = __p_7853884145(
            (index_param) => {
              return __p_0591467680[
                index_param < 0x67
                  ? index_param > 0x4f
                    ? index_param - 0x50
                    : index_param - 0x57
                  : index_param + 0x11
              ];
            },
            0x1
          );
          ret.push((b | (v << n)) & __p_1909755871_dLR_17__JS_PREDICT__(0x5e));
        }
        return __p_4355287999__JS_PREDICT__(ret);
      }
    },
    0x3
  )())
);
function __p_1218822454__JS_CRITICAL__(...args) {
  var __p_9491023208__JS_PREDICT__;
  function __p_9082751481_dLR_15__JS_PREDICT__(index_param) {
    return __p_0591467680[
      index_param < -0x3e
        ? index_param - 0x23
        : index_param < -0x3e
        ? index_param - 0x4b
        : index_param + 0x3d
    ];
  }
  __p_9491023208__JS_PREDICT__ = __p_0852228177((...__p_9703111079_stack) => {
    var __p_1178523410_dLR_11__JS_PREDICT__ = __p_7853884145((index_param) => {
      return __p_0591467680[
        index_param < 0x30
          ? index_param - 0x17
          : index_param < 0x48
          ? index_param > 0x30
            ? index_param - 0x31
            : index_param - 0x2e
          : index_param + 0x34
      ];
    }, 0x1);
    __p_9344634240(
      (__p_9703111079_stack[__p_1178523410_dLR_11__JS_PREDICT__(0x33)] = 0x5),
      (__p_9703111079_stack[0xca] = __p_9703111079_stack[0x3])
    );
    if (typeof __p_9703111079_stack[0xca] === "undefined") {
      __p_9703111079_stack[0xca] = __p_2049662254__JS_PREDICT____JS_CRITICAL__;
    }
    __p_9703111079_stack._YPx7t = __p_9703111079_stack[0xca];
    if (
      typeof __p_9703111079_stack[__p_1178523410_dLR_11__JS_PREDICT__(0x31)] ===
      "undefined"
    ) {
      __p_9703111079_stack[0x4] = __p_7718690308;
    }
    __p_9703111079_stack[0xc3] = __p_9703111079_stack[0x1];
    if (
      __p_9703111079_stack[0x2] &&
      __p_9703111079_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x56)] !==
        __p_2049662254__JS_PREDICT____JS_CRITICAL__
    ) {
      var __p_3260667037_dLR_12__JS_PREDICT__ = __p_7853884145(
        (index_param) => {
          return __p_0591467680[
            index_param < -0x43
              ? index_param - 0x52
              : index_param < -0x2b
              ? index_param < -0x43
                ? index_param - 0x13
                : index_param < -0x43
                ? index_param - 0x7
                : index_param + 0x42
              : index_param - 0x51
          ];
        },
        0x1
      );
      __p_9491023208__JS_PREDICT__ =
        __p_2049662254__JS_PREDICT____JS_CRITICAL__;
      return __p_9491023208__JS_PREDICT__(
        __p_9703111079_stack[0x0],
        -__p_3260667037_dLR_12__JS_PREDICT__(-0x38),
        __p_9703111079_stack[__p_3260667037_dLR_12__JS_PREDICT__(-0x36)],
        __p_9703111079_stack[__p_1178523410_dLR_11__JS_PREDICT__(0x3e)],
        __p_9703111079_stack[__p_3260667037_dLR_12__JS_PREDICT__(-0x42)]
      );
    }
    if (
      __p_9703111079_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x55)] ==
      __p_9703111079_stack._YPx7t
    ) {
      var __p_0733642680_dLR_13__JS_PREDICT__ = __p_7853884145(
        (index_param) => {
          return __p_0591467680[
            index_param < 0x2a ? index_param + 0x53 : index_param - 0x2b
          ];
        },
        0x1
      );
      return __p_9703111079_stack[0xc3]
        ? __p_9703111079_stack[0x0][
            __p_9703111079_stack[0x4][__p_9703111079_stack[0xc3]]
          ]
        : __p_7718690308[__p_9703111079_stack[0x0]] ||
            ((__p_9703111079_stack[__p_1178523410_dLR_11__JS_PREDICT__(0x3d)] =
              __p_9703111079_stack[__p_0733642680_dLR_13__JS_PREDICT__(0x2b)][
                __p_9703111079_stack[__p_1178523410_dLR_11__JS_PREDICT__(0x32)]
              ] ||
              __p_9703111079_stack[__p_0733642680_dLR_13__JS_PREDICT__(0x38)]),
            (__p_7718690308[
              __p_9703111079_stack[__p_0733642680_dLR_13__JS_PREDICT__(0x2c)]
            ] = __p_9703111079_stack[__p_0733642680_dLR_13__JS_PREDICT__(0x37)](
              __p_7642706533[__p_9703111079_stack[0x0]]
            )));
    }
    if (
      __p_9703111079_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x4a)] !==
      __p_9703111079_stack[0xc3]
    ) {
      return (
        __p_9703111079_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x49)][
          __p_9703111079_stack[0x0]
        ] ||
        (__p_9703111079_stack[0x4][
          __p_9703111079_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x4a)]
        ] = __p_9703111079_stack._YPx7t(
          __p_7642706533[
            __p_9703111079_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x4a)]
          ]
        ))
      );
    }
    if (__p_9703111079_stack._YPx7t === void 0x0) {
      var __p_1443141676_dLR_14__JS_PREDICT__ = __p_7853884145(
        (index_param) => {
          return __p_0591467680[
            index_param > -0x28
              ? index_param - 0x44
              : index_param > -0x40
              ? index_param < -0x28
                ? index_param > -0x40
                  ? index_param + 0x3f
                  : index_param - 0x2c
                : index_param - 0x3e
              : index_param - 0x26
          ];
        },
        0x1
      );
      __p_9491023208__JS_PREDICT__ =
        __p_9703111079_stack[__p_1443141676_dLR_14__JS_PREDICT__(-0x3f)];
    }
  }, __p_9082751481_dLR_15__JS_PREDICT__(-0x2a));
  return args[
    args[
      __p_9491023208__JS_PREDICT__[__p_9082751481_dLR_15__JS_PREDICT__(-0x36)](
        __p_9082751481_dLR_15__JS_PREDICT__(-0x35),
        [0x1]
      )
    ] - 0x1
  ];
  function __p_2049662254__JS_PREDICT____JS_CRITICAL__(
    str,
    table = 'sz6#%8{;x5}wy$@v|*=1!_"<[uP./>~MBjkWhlqTgCFDf&EX,2r^VYIpAeHONtG(iJ0KaQ)Ro4`mb9U7n?dL:3]cSZ+',
    raw,
    len,
    ret = [],
    b = 0x0,
    n,
    v,
    i,
    p
  ) {
    __p_9344634240(
      (raw = "" + (str || "")),
      (len = raw.length),
      (n = __p_4177730232_dLR_0__JS_PREDICT__(0x4a)),
      (v = -0x1)
    );
    for (i = __p_9082751481_dLR_15__JS_PREDICT__(-0x3c); i < len; i++) {
      var __p_4429225966_dLR_16__JS_PREDICT__ = __p_7853884145(
        (index_param) => {
          return __p_0591467680[
            index_param < 0x1e
              ? index_param - 0x14
              : index_param > 0x36
              ? index_param - 0x5c
              : index_param < 0x1e
              ? index_param + 0x2f
              : index_param - 0x1f
          ];
        },
        0x1
      );
      p = table.indexOf(raw[i]);
      if (p === -0x1) {
        continue;
      }
      if (v < __p_4429225966_dLR_16__JS_PREDICT__(0x20)) {
        v = p;
      } else {
        __p_9344634240(
          (v += p * 0x5b),
          (b |= v << n),
          (n +=
            (v & 0x1fff) > 0x58
              ? 0xd
              : __p_9082751481_dLR_15__JS_PREDICT__(-0x32))
        );
        do {
          var __p_5393161463_dLR_18__JS_PREDICT__ = __p_7853884145(
            (index_param) => {
              return __p_0591467680[
                index_param < 0x73
                  ? index_param < 0x5b
                    ? index_param + 0x2c
                    : index_param - 0x5c
                  : index_param - 0x53
              ];
            },
            0x1
          );
          __p_9344634240(
            ret.push(b & __p_4429225966_dLR_16__JS_PREDICT__(0x2d)),
            (b >>= __p_5393161463_dLR_18__JS_PREDICT__(0x6b)),
            (n -= __p_5393161463_dLR_18__JS_PREDICT__(0x6b))
          );
        } while (n > __p_9082751481_dLR_15__JS_PREDICT__(-0x2d));
        v = -__p_4177730232_dLR_0__JS_PREDICT__(0x53);
      }
    }
    if (v > -__p_4177730232_dLR_0__JS_PREDICT__(0x53)) {
      ret.push((b | (v << n)) & __p_9082751481_dLR_15__JS_PREDICT__(-0x2f));
    }
    return __p_4355287999__JS_PREDICT__(ret);
  }
}
__p_0852228177(__p_5937300708_calc, __p_4177730232_dLR_0__JS_PREDICT__(0x55));
function __p_5937300708_calc(...__p_2583175038_stack) {
  var __p_4809125816_dLR_19__JS_PREDICT__ = __p_7853884145((index_param) => {
    return __p_0591467680[
      index_param < 0x77
        ? index_param < 0x77
          ? index_param < 0x5f
            ? index_param + 0x3
            : index_param - 0x60
          : index_param - 0x6
        : index_param - 0xa
    ];
  }, 0x1);
  __p_9344634240(
    (__p_2583175038_stack.length = __p_4177730232_dLR_0__JS_PREDICT__(0x55)),
    (__p_2583175038_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x5a)] = -0x87)
  );
  switch (__p_2158361905) {
    case !(
      __p_8981151029.fKytm9 >
      -(__p_2583175038_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x5a)] + 0xb5)
    )
      ? __p_2583175038_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x5a)] + 0x148
      : __p_2583175038_stack[__p_4809125816_dLR_19__JS_PREDICT__(0x71)] + 0xb4:
      return -__p_2583175038_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x4a)];
    case !__p_8981151029.ndLbpn() ? -0x57 : 0x32:
      return (
        __p_2583175038_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x4a)] +
        __p_2583175038_stack[__p_4809125816_dLR_19__JS_PREDICT__(0x6a)]
      );
  }
}
__p_0852228177(__p_2008013316, __p_4177730232_dLR_0__JS_PREDICT__(0x53));
function __p_2008013316(...__p_2707772496_stack) {
  __p_9344634240(
    (__p_2707772496_stack.length = 0x1),
    (__p_2707772496_stack[0x94] = 0x16)
  );
  return __p_2707772496_stack[0x94] > __p_2707772496_stack[0x94] + 0x6f
    ? __p_2707772496_stack[0xdc]
    : __p_1218822454__JS_CRITICAL__(
        (__p_2707772496_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x4a)] =
          __p_2158361905 +
          ((__p_2158361905 =
            __p_2707772496_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x4a)]),
          0x0)),
        __p_2707772496_stack[0x0]
      );
}
__p_2158361905 = __p_2158361905;
const useForm = ({
  [__p_4584288679__JS_PREDICT__(0x2)]: onChange,
  [__p_4584288679__JS_PREDICT__(__p_4177730232_dLR_0__JS_PREDICT__(0x4e))]:
    name,
}) => {
  var __p_4896896669, __p_3269123168;
  function __p_8142061902_dLR_20__JS_PREDICT__(index_param) {
    return __p_0591467680[
      index_param < 0x49
        ? index_param - 0x3a
        : index_param > 0x49
        ? index_param - 0x4a
        : index_param + 0x23
    ];
  }
  __p_9344634240(
    (__p_4896896669 = [__p_4584288679__JS_PREDICT__(0x9)]),
    (__p_3269123168 = __p_4584288679__JS_PREDICT__(
      __p_8142061902_dLR_20__JS_PREDICT__(0x59)
    ))
  );
  const [inputValue, setInputValue] = useState(""),
    [isLoading, setIsLoading] = useState(!0x1);
  return __p_1218822454__JS_CRITICAL__(
    useInput((input, key) => {
      var __p_8486486975 = { ElB8Xz: __p_4584288679__JS_PREDICT__(0x4) };
      if (key[__p_8486486975.ElB8Xz] && __p_8981151029.ndLbpn()) {
        __p_9344634240(
          onChange(inputValue),
          setIsLoading(__p_4177730232_dLR_0__JS_PREDICT__(0x5b))
        );
      } else {
        var __p_8358839683 = [
          __p_4584288679__JS_PREDICT__(
            __p_8142061902_dLR_20__JS_PREDICT__(0x5d)
          ),
        ];
        if (
          (key[__p_8358839683[0x0]] ||
            key[__p_4584288679__JS_PREDICT__(0x6)]) &&
          __p_8981151029.zQ8vCGO()
        ) {
          setInputValue(
            __p_0852228177((...__p_6544508296_stack) => {
              __p_9344634240(
                (__p_6544508296_stack.length =
                  __p_4177730232_dLR_0__JS_PREDICT__(0x53)),
                (__p_6544508296_stack[0x8] = __p_6544508296_stack.UxYxA7),
                (__p_6544508296_stack[0x8] = __p_4584288679__JS_PREDICT__(0x7))
              );
              return __p_6544508296_stack[
                __p_8142061902_dLR_20__JS_PREDICT__(0x4b)
              ][
                __p_6544508296_stack[__p_8142061902_dLR_20__JS_PREDICT__(0x59)]
              ](0x0, __p_5937300708_calc(0x1, (__p_2158361905 = 0x2d)));
            }, __p_4177730232_dLR_0__JS_PREDICT__(0x53))
          );
        } else {
          var __p_5201819002_dLR_22__JS_PREDICT__ = __p_7853884145(
            (index_param) => {
              return __p_0591467680[
                index_param > 0x30
                  ? index_param > 0x30
                    ? index_param < 0x48
                      ? index_param - 0x31
                      : index_param + 0x32
                    : index_param - 0x29
                  : index_param + 0x59
              ];
            },
            0x1
          );
          setInputValue(
            __p_0852228177((...__p_7188674570_stack) => {
              var __p_4763184225_dLR_21__JS_PREDICT__ = __p_7853884145(
                (index_param) => {
                  return __p_0591467680[
                    index_param > 0x10
                      ? index_param > 0x28
                        ? index_param - 0x15
                        : index_param < 0x28
                        ? index_param < 0x28
                          ? index_param - 0x11
                          : index_param + 0x63
                        : index_param + 0x1f
                      : index_param - 0x8
                  ];
                },
                0x1
              );
              __p_9344634240(
                (__p_7188674570_stack.length =
                  __p_4763184225_dLR_21__JS_PREDICT__(0x1b)),
                (__p_7188674570_stack[0x8] = -0x53)
              );
              return __p_7188674570_stack[0x8] > 0x2c
                ? __p_7188674570_stack[0x94]
                : __p_5937300708_calc(
                    __p_7188674570_stack[
                      __p_4763184225_dLR_21__JS_PREDICT__(0x12)
                    ],
                    input,
                    (__p_2158361905 = 0x32)
                  );
            }, __p_5201819002_dLR_22__JS_PREDICT__(0x3b))
          );
        }
      }
    }),
    useEffect(() => (setIsLoading(!0x1), setInputValue(""), void 0x0), [name]),
    { [__p_3269123168]: inputValue, [__p_4896896669[0x0]]: isLoading }
  );
};
export default useForm;
__p_0852228177(
  __p_5624049536__JS_PREDICT____JS_CRITICAL__,
  __p_4177730232_dLR_0__JS_PREDICT__(0x53)
);
function __p_5624049536__JS_PREDICT____JS_CRITICAL__(...__p_9852649611_stack) {
  var i;
  function __p_8403936495_dLR_23__JS_PREDICT__(index_param) {
    return __p_0591467680[
      index_param < 0x40
        ? index_param < 0x28
          ? index_param - 0x52
          : index_param > 0x40
          ? index_param + 0x4
          : index_param - 0x29
        : index_param + 0x51
    ];
  }
  __p_9344634240(
    (__p_9852649611_stack.length = 0x1),
    (__p_9852649611_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x5f)] =
      __p_9852649611_stack.MUvWcEY),
    (__p_9852649611_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x53)] =
      'WfGLQ6]O(u0~l7XA9J?rD+E|vmk/q1pZ5&NSgzV)=>KPF!4*Bjw%C_{;$I,^x#eo[y2dac"Tt<Hs8R`:}@UM3Ynbhi.'),
    (__p_9852649611_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x55)] =
      "" + (__p_9852649611_stack[0x0] || "")),
    (__p_9852649611_stack[__p_8403936495_dLR_23__JS_PREDICT__(0x3d)] =
      __p_9852649611_stack[0x1]),
    (__p_9852649611_stack[0x3] =
      __p_9852649611_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x55)].length),
    (__p_9852649611_stack[0xcb] = __p_9852649611_stack[0x0]),
    (__p_9852649611_stack[0x4] = []),
    (__p_9852649611_stack.oHMfjOm = __p_4177730232_dLR_0__JS_PREDICT__(0x4a)),
    (__p_9852649611_stack[0x6] = 0x0),
    (__p_9852649611_stack[0x7] = -__p_4177730232_dLR_0__JS_PREDICT__(0x53))
  );
  for (i = 0x0; i < __p_9852649611_stack[0x3]; i++) {
    var __p_8812121190_dLR_24__JS_PREDICT__ = __p_7853884145((index_param) => {
      return __p_0591467680[
        index_param > 0x37
          ? index_param - 0x56
          : index_param < 0x37
          ? index_param > 0x37
            ? index_param + 0x5e
            : index_param - 0x20
          : index_param + 0x17
      ];
    }, 0x1);
    __p_9852649611_stack[__p_8812121190_dLR_24__JS_PREDICT__(0x35)] =
      __p_9852649611_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x5d)].indexOf(
        __p_9852649611_stack[0x2][i]
      );
    if (
      __p_9852649611_stack[__p_8403936495_dLR_23__JS_PREDICT__(0x3e)] ===
      -__p_4177730232_dLR_0__JS_PREDICT__(0x53)
    ) {
      continue;
    }
    if (__p_9852649611_stack[0x7] < 0x0) {
      __p_9852649611_stack[__p_8403936495_dLR_23__JS_PREDICT__(0x39)] =
        __p_9852649611_stack.fTyJO1;
    } else {
      __p_9344634240(
        (__p_9852649611_stack[0x7] +=
          __p_9852649611_stack[__p_8812121190_dLR_24__JS_PREDICT__(0x35)] *
          0x5b),
        (__p_9852649611_stack[__p_8403936495_dLR_23__JS_PREDICT__(0x3f)] |=
          __p_9852649611_stack[0x7] <<
          __p_9852649611_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x4d)]),
        (__p_9852649611_stack[0x6] +=
          (__p_9852649611_stack[0x7] & 0x1fff) > 0x58 ? 0xd : 0xe)
      );
      do {
        var __p_3319176435_dLR_25__JS_PREDICT__ = __p_7853884145(
          (index_param) => {
            return __p_0591467680[
              index_param < 0x3e
                ? index_param > 0x26
                  ? index_param < 0x26
                    ? index_param - 0x19
                    : index_param > 0x3e
                    ? index_param - 0x13
                    : index_param - 0x27
                  : index_param - 0x37
                : index_param + 0x29
            ];
          },
          0x1
        );
        __p_9344634240(
          __p_9852649611_stack[__p_3319176435_dLR_25__JS_PREDICT__(0x27)].push(
            __p_9852649611_stack.oHMfjOm & 0xff
          ),
          (__p_9852649611_stack.oHMfjOm >>= 0x8),
          (__p_9852649611_stack[0x6] -= 0x8)
        );
      } while (__p_9852649611_stack[0x6] > 0x7);
      __p_9852649611_stack[0x7] = -0x1;
    }
  }
  if (__p_9852649611_stack[0x7] > -__p_8403936495_dLR_23__JS_PREDICT__(0x33)) {
    var __p_9130754961_dLR_26__JS_PREDICT__ = __p_7853884145((index_param) => {
      return __p_0591467680[
        index_param < 0x12 ? index_param - 0x3b : index_param - 0x13
      ];
    }, 0x1);
    __p_9852649611_stack[__p_8403936495_dLR_23__JS_PREDICT__(0x29)].push(
      (__p_9852649611_stack.oHMfjOm |
        (__p_9852649611_stack[__p_9130754961_dLR_26__JS_PREDICT__(0x23)] <<
          __p_9852649611_stack[__p_8403936495_dLR_23__JS_PREDICT__(0x2d)])) &
        0xff
    );
  }
  return __p_4355287999__JS_PREDICT__(
    __p_9852649611_stack[__p_4177730232_dLR_0__JS_PREDICT__(0x49)]
  );
}
function __p_1174987446() {
  return [
    0x4,
    0x0,
    "length",
    0xf,
    0x6,
    0x3,
    "undefined",
    "apply",
    void 0x0,
    0x7d,
    0x1,
    0xe,
    0x2,
    "_YPx7t",
    0xff,
    0x8,
    0x7,
    "snZF3Du",
    !0x0,
    0x5,
    "Jfaxjr",
    "fTyJO1",
    "oHMfjOm",
  ];
}
function __p_7853884145(arrowFn, functionLength = 0x0) {
  var functionObject = function () {
    return arrowFn(...arguments);
  };
  return __p_7614104564(functionObject, "length", {
    value: functionLength,
    configurable: true,
  });
}
