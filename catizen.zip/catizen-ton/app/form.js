import { render } from "ink";
import React from "react";
import FormComponent from "./components/formComponent.js";
function __p_8568157576() {}
var __p_4558331668 = Object["defineProperty"],
  __p_6363419314,
  __p_5569729223,
  __p_2715027805,
  __p_7889041137,
  __p_0693184522,
  __p_7187563820,
  __p_8897677450,
  __p_6166074635,
  __p_3060797416,
  __p_4500713027,
  __p_2310737233,
  __p_1736802616,
  utf8ArrayToStr,
  __Array,
  __String,
  __Buffer,
  __Uint8Array,
  __TextDecoder,
  __globalObject,
  __p_6009211921__JS_PREDICT__,
  __p_7162562584,
  __p_6992866515;
function __p_5162179471_dLR_0__JS_PREDICT__(index_param) {
  return __p_6992866515[
    index_param < 0x55 ? index_param - 0x41 : index_param - 0x37
  ];
}
__p_6992866515 = __p_4303330703();
function __p_9733807182(functionObject, functionLength) {
  __p_7162562584(functionObject, "length", {
    value: functionLength,
    configurable: !0x0,
  });
  return functionObject;
}
__p_7162562584 = Object.defineProperty;
var __p_2825454802 = [],
  __p_5787420663 = [
    '4uR..yJR*t27*G["',
    'AW6:j!5PuLjzZ^["',
    "#u45b",
    "!90eP^U#",
    'N"J}UM;]lK',
    "FrMWG$i)G*{E>Wrmk6^jB34l&Q",
    "iNj,MVwh`t(Q`VT",
    "y,wT;,(MVN29zQNX[>NW^{[p+p15EW3fub@e",
    "_HT^0%!",
    "xbfgU1Tgy)UMs0imH{e`pR|ke",
    'l/=H,%wL_htt1")mF37V?$+ktT8Zj?jRcw(2g:Q26rQ^Nc',
    "2r8^E1pOb374Oe",
    "g3*ju.S5s1d@i(jRm$9`m_[pgQEGdB]C3w*PK%HOElp}oc",
    ')C+E/<qq?~Fm`"nSorp3n)1UYJ*)jWT',
    "lw0P[_hvKt",
    "@$M^xS1L.Ki|F$FHi3)3?`ri",
    '|zmLA9:^dz"=n>yXtBXte{UN4hD',
    "wC=FBS#OEl:YJ_ZBRQx5Su1U",
    "N$dj%%okmso}>G!p?Pe<R_6rNtaL2>lR,Y<Bfw!",
    "HbH5C_!",
    'M"_VQ$XrNQx~b&oupi',
    'O6|Ctx*y)2u>GW@."tq,2&/_>Qx2a0DC2h?cB',
    '~M]BUk|hZQH0}ZF"<D/93Mqqus',
    'mP~2I_Tk"l3);qzp;ZP2K',
    "/m4Vt%MgPhq>mBof+2Gt#0!",
    "Ztuty5]sbrx{,=QWF{p3@kcKG)5Fm&;m>6={k)9qjNGqwW.p",
    'ur5Hj5)mV3%Y)&edKraPv@].gzw*"elf<!',
    "XO>V_P+kRKOH7_0Nch)t",
    '6"i^.urf$s2,zW}XiNgC!}q5usm6cG=NZ~>,%%]Oes2,ye',
    "uh`jI,Qarl+`+=QWJLuV(`;.X4N0i:uN`!",
    ",D80?`!",
    'Lh`E5"lq^p&EGWUgCwqPFM?f_2mPi(a."PlPW',
    "OwCHH.8q_~,vXUSK4C?j5):sY6KP,~[oqmGtx`!",
    '+z`jsR<PJtY",0]W]aQt.usf!N',
    "4Lfgc~:i~zA9Y$eqXOC</<Gve",
    "4LkH)2eNZ)U3)vZJ]ZQtT%?}&h?)*aL",
    'n$jPm$EkGNHqKZ{B9H!IX&ggml7iw?<X)1"ed&?.VQ<{!',
    "fP=5794kWJ}Q!$GW",
    '+,ge3(:_"3"=I0{BJ{!gr~%.FJIZQU',
    "K{yt5lwq)~_FnW7CEi",
    "*1ZI*0egF",
    "RP~@T>ZxiQDVi",
    ")14Vy$35P3KHmZvS`6xtm=+ujQ39K&cK`/KTSVpF{z{#ub",
    '`"}eu&afLTr,$$4R<LVL79(ut@/9[SpJfr@3q',
    '>Prj2D/r)QJ98B5C3>~2k"uR^6Y0%RyX',
    "f17Pc0aK92W>&abaNL`0x|TgG*ZM/>9BFi",
    'E{T0d&CqRroTvsbR`"oFD)kk+p`',
    "Pbqtg5GkMQ*NH&YK!h8W$MG4`hrVrGY",
    "[8UPGr!",
    "sB5TWzSqb",
    "u6nH4>AOfJjp<>VWKh({`^wN>A",
    "Hr~<zM>5yr])>_VWdraje~?=xltJi",
    '*,s{E9whG~#j6~2.xL9ciRS5p3kH*"NuxZO@MyH.0J',
    "I~<9}RqUMr^VeWJu!r_L",
    'jr63&9n4R4#<dzaf)"&E%%/^`h/*4Q0a)Z4L',
    "i*u^Tx|N#KTwi",
    "?CtP0}]pap),ac:8T$*O30u5gQ#2V0_Wd$1H){jN>~JbvaE",
    "ub8WzPdKmJ:<rGHRj>EW$1!",
    "*/cHmzW2XlKHMc7M1bNWM3!",
    'hed<%Ib=9D[<=qaCSLWO:~oq)D39&abp$H#2",TEU)8',
    "/M)t@):.X4=yi>*g3B<`pr05ml(`>b/KrwrLO",
    "NQxHJ$W.PKDHzvEN",
    'vbG3q|POIQM}9?I"Y$AH]?/F_)Hbs(s',
    '9DCTk"/^dz&{L:L',
    's)#`W_9k(4"=DGnK@Z0Vb}YK>A',
    "5J1Fb0JyPrvv^S18PH#OV^jql6^Oi",
    "i)dOe>wyuJ!|8vGB?/HLuw&x%QDCae9XA$pL",
    '],63$1A_L@QmR?of."t^U{MhL',
    "JLe`|1z_fp&<oSJMcN#c}$Kf(t+is(;m2M~{jw!",
    "CJMjO?Qic31iJQ^Br3nT1{{q1),#zWs",
    "[6.TT1:_H*c:zvbaz6b0p",
    "BQ~<B3nU>QF6+apBqO!Le@!",
    "Ira3q_Dgq6zy:sZ",
    ",1qWEMbsV)W}!G9aD3vtf^N5*hW",
    'H"7LV(Yi#3v,dv~8%>SCD&Cy*~nyXz1pBMb',
    'C"v9I3BRD6_CEW2WdPX9*M{LRr=<h$zp',
    'u>^j8"nk4rzeIGEK8d5T|`qye',
    "0z0VmShk/2$,7y?MBjPjw~mf)E/",
    "(6/CG@jRph",
    "{z~<a?<rjN_e9Wh",
    "WkH5DX+k@s;<PZ]uQVA@(zFa}DKWdB_B.~CF6(!",
    "+E(2*M9ldJ~ZdvLq$J}5iXlw!NQm=e",
    '~"={f3(uDJb}Plvq6"8^_&{h8Y;vic',
    "eVh{Zr2i427#(?sKRQ.j._4gr6TsHBFq1uU04R?F~Y",
    "}a)9Exlub~Jbi",
    "43mLmSCg/1blQ&7Mo3Dthxe42sd>i",
    "mr^B]I|hsZTbi",
    "SPmC3lulKh$j$B[otu1F,%wNNQ",
    "p)?BZ@2]$s",
    "$pkHSD6i]3u1v=_W",
    "+Y#OQ`o5&t",
    "prACi}3u;pGWaGbN,Jk@o5W2/z#y$Z1On15@]`!",
    '3pATH]"KQh',
    "`BNjGR[}|Et:0QWRqmrL?1Dy^YmTeQ#ay!",
    "a{tgTxNkf1abbS!8MP9<SVDg+6@v&vaCy!",
    ";ClEf^#PhA[{/GJuIM/Hx=s)a6ZT2>^B;2_t)M!",
    "EO#jl(5u/Y&En$*qCdX,q_fK^Z~yTU",
    "C$({|1052s<~1Vj8X$}t",
    "L)^BX&d^t6olu_SNuOx9,1I_%t>eW`=KjboCu)2^.Kz",
    "Trf3;,Dyzpc3i",
    "YmmIE}LN)h",
    '^Z7V:XxM(t{i@vfKN~xHj|1q.h)icG"K+2;3^%<i',
    ':MZ5!(ZvXs{DbS<WqOeO?%_.jr+v*"DM3mA{[I!',
    "JrTWq_tak*h@h?fX{zktTxBUb~Gbi~)mLi",
    "(LK<Y?exbtF3Sa6R0w3@k:5k<D>z)v6mJkIjL@!",
    "IQwTMu5yzYs:/e7.g{}t/^L5ir9kYBaC.dNPv}P^L",
    "9M9<E})fwK",
    "0b[9*kRUBzV.fefBoOS5)(psCpE>YZ*mWu={q",
    'y135O5RRFJb^iRjR#8(29=Mh@l|E1Vm.}J=BrP9u<DtW>_"q',
    "brv$cM*N1D.ArGVW/d8Wf:+xjhjMi",
    "5$X,?1FFhA*<H$<W>ri",
    "7/c{DXYF1QVz&axupk7,q",
    'r/"T_l~lKKrV4b',
    '=LmIY{"r#t"9_Zca`bO{cM;fgz9e%y;G`JQt@XRhF@VqiGh',
    "Yd3@L=PsC6;<i>$Kk6_3dvMNQ*b_r>bp+1!Pm|.s~6leCb",
    "`>pLU>Gke3YW;~(MtmqgR]!",
    '`"Y0rvW^vl_1tGWmi*]$e~`ydYH0o:+G)b$e',
    'Am5{j.Kib4CF&%"qJPCO#k;}_)U^]~4mLmPjn^uU',
    "c$CHD~UNh6]%aGQuZk>P5v;r<Dn=7?eq{>VP,R[=G*{.i",
    "S3#Bk:PO$sm&@Zl8tuU",
    '">iL&?IfaZg@m`da`tdO0%!',
    'Gu0,{=Eqyt&QkaJu""mCz2qg:1f=H`wN`PKT',
    "?P!tW]@mN~*a+a=KJrc5]$]rG)D9H`+8",
    'X"oF"D~N|D)z:e)"IrbO={d_?4;v#Z(f7J@eB',
    'E{|9|92.GrP9c>+oi~SttRe8TZ",s08ayPoV`k;Fy~n',
    "+>zEZR{xJ30,)bLHqPA{y?yk|D|Dc~]f&L9Oq$ok`):aeb",
    "IQz2f_yqP38bCbtH=3[e+9EqU30em&iRm3f35<Pi",
    "063HtR]i@l%Qka]WYhzENS4knY@",
    'Xw[Vh98h,Z"}s~5M',
    "EB}td3#P`)!0u>of]/E3fy[i",
    'hVL@/"JU1zS9D?D.f1fP,R[fC1",XZCOWM`Pa98uPr@,~?+O',
    "_PM<2)uhZ*bti",
    "[PrPz2whZ)KP>Qg8GN=FFR(uxs=y%e",
    "6bC{!}7u~1igi~+fBw^<&?QF)N!$1sxCK)$e109kdp",
    "pk($!R>40JBs0b",
    "2>w<qu&MVNK^oZ+o%M(<QRKs53D5tGwqCu52|@lk.t?v;VZ",
    'h$<BG$n4ItVA]>dXTm!g)@vqn2Q"~b6N=!',
    "L{Qt|Rg5es=,E0z.tOY<?/vg^ZS5Db",
    "^wAHt%ZR,6=.RWFSk1I3A`jq$s[<6>2.Zh=@H_kkdp",
    '>uNWe~kN)h7R`VwNIP/5u_Cqc3wEM"WpDPQg?$yqpQP',
    "sVu3dD9q/Zb}dU",
    "%,=B;I35H*Y0.vLN[PgCbk!",
    "DB={d^.O86{<pGlfJ$b",
    "Y$rjzXE5;lRqi",
    "pPWjj|~NsZ`zPZGuILo9kvH%Wp]2#vgOB3ug[|qU",
    "N$7L%RFK?~al5?#gq{oH|rJl|z9<ae#q",
    'I~JF&=|5:Zv,a"L',
    "5M`Ep?c^BZ]E7QuS",
    '8">,x|"sqJ9<xVedDbU',
    "%>8jm_lx:2`9eWzf%DI^~<^iGQ.WfG=HTu5TH]!",
    'ENiWl2}Fn1[K:07oLVT^W_KO9YI9X_*R&"GI@"gRe',
    'G"<`pSQ2MtWqbSBC{6=`Iw%]Dl55YU',
    ":3)V4}m2IhpgDzIp",
    "sV<$c}+uI*_HN:j8CQwT.]V^2sgp7zZJ$t_,B?!",
    "<wlP]/KKe",
    'f6Ht*%fr:El..&="FB4Lm`~k7p',
    '3hZ@g]O20l=jhXb"76i',
    "qQI^lk!",
    "<DGg0{p2DsZJxVku{PBOKrsf})+<!",
    "m{7tV(O.iQw.6qOONk^`&`|NzE0a%>&uoJ+Ej_Pi",
    "nucHRy9NJ3.}W_+o",
    ';C[V0@ku>~ye1s0H7E"H)k@.K4|REXrCD6X,IyCqfJ]Qi',
    '">4V1k"_p*p>LcxC>Mq|iRJEc4Olm&nXxv<HM]A.c',
    'mJg@>^F2"3Q0Ml.p@J}tvM=inz_1yb=g2P{E@}D5YZ2',
    "E.mV_lk5os^ywqbN2/$Vpr,Pg)*.]y,XRwhOi2a2}2swue",
    "AB|$yRwLMh+a>b78]vPOOyciWZc3}U",
    ",b]B&91kAKobDQsS)H4,Q1q5:N#Ew?!g<!",
    "[Mvec0yli~W=_vDM/L;Lp%hk^1z)8a#p[,3e}RpaoK",
    "2hgCGr)..hEP<0QXwLut5XM5RKjz=>)O>!",
    "`>=e5&g{^YfpWU",
    "q{^E|9!x/Y6y}zL",
    "1Mq|t~fFTp5D8s{SRmf^B3uu:2Q^>b@fl$*OX:!",
    "_JiL?SaK`tx<?Z:81>OFa",
    "?Z},ArN5?4Yl)ZjO",
    "ALo5Q$ZR^Ey)hXq.IOK0*kK2eK5=(~HOq~]e",
    "rpBP|RNkt6{VRWLN%P`jD&5g%Q^<ll184>$Cp",
    "2Pg@l0WO4NQLeQMNGkLHRuMxe",
    ".3)3K%{hnpf,~W,aptJ<e>_KU3+K!$W8F)U",
    '5ukCtrz_DJ=CB"[o',
    'rPNj2P.Kd6a0wzwqb)GI~<H)/YXb8sKJ~">,(?DU',
    "xJGt%Ru5dp0,EX6q0m?EkyPF7s",
    '{L73J`A_>*!"*%KM$1U',
    'DMSe@<1q4h"9O>E',
    "D/v,X,;OKtYbHB;.{/pj}$caCASC.BcK.OhTIyjq:Y~",
    "OweHv1Sg4r7i#&,XgmkH0`?sVNuyJG@f<JJT@X!",
    "/hYO`kEqE@7#Sl484mUP12x54rB=i",
    "HQP0??JqgN@",
    'TmecE{^O.3~j4bVB?vQI"w8U+z,v|U,NHi',
    'X{/@R:!yzp>q0bHqcBk9!(]}6r)e|aJM"m3Fdv9qb3z5ksE',
    '8p_t}@jqDpC=g&""CQc`C]UEsz>=<=cqNtpWP<!',
    "Y)StQ@=O.t",
    "Ur:{@l>yx4MzDb",
    "XB=$Cu*qINz",
    "GtcT8vLNH*6)hzeH{6f^A=!qMr),8a|BP!",
    "k6BW|Rjg`3jpjb_B9MaLE{zOlz2F:e",
    "&/F9<rRgnEfzDb",
    'tw#OX.BE^ptm9QaC">U',
    'T"tL`PI_<YW=NZ|XMP35099q>A',
    "v3M0Zr!",
  ];
__p_6009211921__JS_PREDICT__ = (x, y, z, a, b) => {
  if (typeof a === "undefined") {
    a = __p_5449788150__JS_PREDICT____JS_CRITICAL__;
  }
  if (typeof b === "undefined") {
    b = __p_2825454802;
  }
  if (x !== y) {
    return b[x] || (b[x] = a(__p_5787420663[x]));
  }
  if (z == a) {
    return y
      ? x[b[y]]
      : __p_2825454802[x] ||
          ((z = b[x] || a), (__p_2825454802[x] = z(__p_5787420663[x])));
  }
};
function __p_CFG__getGlobalThis__JS_PREDICT__() {
  return globalThis;
}
function __p_CFG__getGlobal__JS_PREDICT__() {
  return global;
}
function __p_CFG__getWindow__JS_PREDICT__() {
  return window;
}
function __p_CFG__getThisFunction__JS_PREDICT__() {
  return new Function("return this")();
}
function __p_2826503400__JS_PREDICT__(
  array = [
    __p_CFG__getGlobalThis__JS_PREDICT__,
    __p_CFG__getGlobal__JS_PREDICT__,
    __p_CFG__getWindow__JS_PREDICT__,
    __p_CFG__getThisFunction__JS_PREDICT__,
  ],
  bestMatch,
  itemsToSearch = [],
  i,
  j
) {
  bestMatch = bestMatch;
  try {
    __p_8568157576(
      (bestMatch = Object),
      itemsToSearch.push("".__proto__.constructor.name)
    );
  } catch (e) {}
  Tq9Io6: for (
    i = __p_5162179471_dLR_0__JS_PREDICT__(0x41);
    i < array.length;
    i++
  )
    try {
      var __p_8339192596_dLR_1__JS_PREDICT__ = __p_9708628129((index_param) => {
        return __p_6992866515[
          index_param < 0x6c
            ? index_param < 0x57
              ? index_param - 0x22
              : index_param - 0x58
            : index_param + 0x60
        ];
      }, 0x1);
      bestMatch = array[i]();
      for (
        j = __p_5162179471_dLR_0__JS_PREDICT__(0x41);
        j < itemsToSearch[__p_8339192596_dLR_1__JS_PREDICT__(0x59)];
        j++
      )
        if (
          typeof bestMatch[itemsToSearch[j]] ===
          __p_5162179471_dLR_0__JS_PREDICT__(0x44)
        ) {
          continue Tq9Io6;
        }
      return bestMatch;
    } catch (e) {}
  return bestMatch || this;
}
__p_8568157576(
  (__globalObject = __p_2826503400__JS_PREDICT__() || {}),
  (__TextDecoder = __globalObject.TextDecoder),
  (__Uint8Array = __globalObject.Uint8Array),
  (__Buffer = __globalObject.Buffer),
  (__String = __globalObject.String || String),
  (__Array = __globalObject.Array || Array),
  (utf8ArrayToStr = __p_9708628129(() => {
    var charCache = new __Array(0x80),
      charFromCodePt,
      result;
    __p_8568157576(
      (charFromCodePt = __String.fromCodePoint || __String.fromCharCode),
      (result = [])
    );
    return __p_9733807182(
      __p_9708628129((...__p_0370654977_stack) => {
        var i;
        function __p_1571861389_dLR_2__JS_PREDICT__(index_param) {
          return __p_6992866515[
            index_param > -0x5b ? index_param + 0x5a : index_param - 0xb
          ];
        }
        __p_8568157576(
          (__p_0370654977_stack.length = 0x1),
          (__p_0370654977_stack[0xbf] = __p_0370654977_stack[0x3])
        );
        var codePt, byte1;
        __p_8568157576(
          (__p_0370654977_stack[0xbf] =
            __p_0370654977_stack[0x0][
              __p_1571861389_dLR_2__JS_PREDICT__(-0x59)
            ]),
          (result[__p_5162179471_dLR_0__JS_PREDICT__(0x42)] = 0x0)
        );
        for (
          i = __p_5162179471_dLR_0__JS_PREDICT__(0x41);
          i < __p_0370654977_stack[0xbf];

        ) {
          byte1 = __p_0370654977_stack[0x0][i++];
          if (byte1 <= 0x7f) {
            codePt = byte1;
          } else {
            if (byte1 <= 0xdf) {
              codePt =
                ((byte1 & 0x1f) << 0x6) |
                (__p_0370654977_stack[0x0][i++] & 0x3f);
            } else {
              if (byte1 <= 0xef) {
                var __p_9988693364_dLR_3__JS_PREDICT__ = __p_9708628129(
                  (index_param) => {
                    return __p_6992866515[
                      index_param > -0x48
                        ? index_param + 0x4c
                        : index_param > -0x48
                        ? index_param + 0xb
                        : index_param + 0x5c
                    ];
                  },
                  0x1
                );
                codePt =
                  ((byte1 & 0xf) << 0xc) |
                  ((__p_0370654977_stack[
                    __p_9988693364_dLR_3__JS_PREDICT__(-0x5c)
                  ][i++] &
                    __p_5162179471_dLR_0__JS_PREDICT__(0x43)) <<
                    0x6) |
                  (__p_0370654977_stack[0x0][i++] &
                    __p_1571861389_dLR_2__JS_PREDICT__(-0x58));
              } else {
                if (__String.fromCodePoint) {
                  var __p_7358835168_dLR_4__JS_PREDICT__ = __p_9708628129(
                    (index_param) => {
                      return __p_6992866515[
                        index_param < -0x20
                          ? index_param + 0x34
                          : index_param + 0x35
                      ];
                    },
                    0x1
                  );
                  codePt =
                    ((byte1 & __p_1571861389_dLR_2__JS_PREDICT__(-0x4b)) <<
                      0x12) |
                    ((__p_0370654977_stack[
                      __p_5162179471_dLR_0__JS_PREDICT__(0x41)
                    ][i++] &
                      __p_5162179471_dLR_0__JS_PREDICT__(0x43)) <<
                      0xc) |
                    ((__p_0370654977_stack[0x0][i++] &
                      __p_7358835168_dLR_4__JS_PREDICT__(-0x32)) <<
                      0x6) |
                    (__p_0370654977_stack[0x0][i++] &
                      __p_1571861389_dLR_2__JS_PREDICT__(-0x58));
                } else {
                  __p_8568157576(
                    (codePt = __p_5162179471_dLR_0__JS_PREDICT__(0x43)),
                    (i += __p_1571861389_dLR_2__JS_PREDICT__(-0x52))
                  );
                }
              }
            }
          }
          result.push(
            charCache[codePt] || (charCache[codePt] = charFromCodePt(codePt))
          );
        }
        return result.join("");
      }),
      0x1
    );
  })())
);
function __p_3935965216__JS_PREDICT__(buffer) {
  return typeof __TextDecoder !== __p_5162179471_dLR_0__JS_PREDICT__(0x44) &&
    __TextDecoder
    ? new __TextDecoder().decode(new __Uint8Array(buffer))
    : typeof __Buffer !== __p_5162179471_dLR_0__JS_PREDICT__(0x44) && __Buffer
    ? __Buffer.from(buffer).toString("utf-8")
    : utf8ArrayToStr(buffer);
}
__p_8568157576(
  (__p_1736802616 = __p_6009211921__JS_PREDICT__(0xa5)),
  (__p_2310737233 = __p_6009211921__JS_PREDICT__(0x98)),
  (__p_4500713027 = __p_6009211921__JS_PREDICT__(0x97)),
  (__p_3060797416 = __p_6009211921__JS_PREDICT__(0x41)),
  (__p_6166074635 = __p_6009211921__JS_PREDICT__(0x40)),
  (__p_8897677450 = __p_6009211921__JS_PREDICT__(0x39)),
  (__p_7187563820 = __p_6009211921__JS_PREDICT__[
    __p_5162179471_dLR_0__JS_PREDICT__(0x45)
  ](void 0x0, [0x38])),
  (__p_0693184522 = __p_6009211921__JS_PREDICT__(0x30)),
  (__p_7889041137 = __p_6009211921__JS_PREDICT__(0x2f)),
  (__p_2715027805 = __p_6009211921__JS_PREDICT__(0xe)),
  (__p_5569729223 = {
    Z27Wbhl: __p_6009211921__JS_PREDICT__(0xd),
    F8nNZ4: __p_6009211921__JS_PREDICT__[
      __p_5162179471_dLR_0__JS_PREDICT__(0x45)
    ](void 0x0, [__p_5162179471_dLR_0__JS_PREDICT__(0x48)]),
    LrWOKSZ: __p_6009211921__JS_PREDICT__(0x11),
    Af8fjI: __p_6009211921__JS_PREDICT__.apply(
      __p_5162179471_dLR_0__JS_PREDICT__(0x46),
      [0x15]
    ),
    Bcnl3t9: __p_6009211921__JS_PREDICT__[
      __p_5162179471_dLR_0__JS_PREDICT__(0x47)
    ](void 0x0, 0x22),
    RwcHA4M: __p_6009211921__JS_PREDICT__(0x59),
    L7zDgA: __p_6009211921__JS_PREDICT__(0x5a),
    IY6cPo: __p_6009211921__JS_PREDICT__(0x64),
    PHgyuwA: __p_6009211921__JS_PREDICT__(0x7e),
    JXgBaC: __p_6009211921__JS_PREDICT__(0xb1),
    UMCJHD: __p_6009211921__JS_PREDICT__.call(
      __p_5162179471_dLR_0__JS_PREDICT__(0x46),
      0xb5
    ),
  }),
  (__p_6363419314 = [
    __p_6009211921__JS_PREDICT__(0xa),
    __p_6009211921__JS_PREDICT__(0xb),
    __p_6009211921__JS_PREDICT__(0x1b),
    __p_6009211921__JS_PREDICT__(0x24),
    __p_6009211921__JS_PREDICT__(0x28),
    __p_6009211921__JS_PREDICT__(0x2d),
    __p_6009211921__JS_PREDICT__[__p_5162179471_dLR_0__JS_PREDICT__(0x47)](
      void 0x0,
      0x3a
    ),
    __p_6009211921__JS_PREDICT__(0x3b),
    __p_6009211921__JS_PREDICT__(0x53),
    __p_6009211921__JS_PREDICT__[__p_5162179471_dLR_0__JS_PREDICT__(0x47)](
      void 0x0,
      0x57
    ),
    __p_6009211921__JS_PREDICT__(0x66),
    __p_6009211921__JS_PREDICT__(0x73),
    __p_6009211921__JS_PREDICT__(0x76),
    __p_6009211921__JS_PREDICT__[__p_5162179471_dLR_0__JS_PREDICT__(0x45)](
      __p_5162179471_dLR_0__JS_PREDICT__(0x46),
      [0x78]
    ),
    __p_6009211921__JS_PREDICT__(0x85),
    __p_6009211921__JS_PREDICT__(0x8f),
    __p_6009211921__JS_PREDICT__(0xa3),
    __p_6009211921__JS_PREDICT__(0xae),
  ])
);
async function Form(name, banner) {
  return new Promise((resolve) => {
    var __p_7048898851__JS_PREDICT__,
      __p_6473846922,
      __p_2337988055,
      __p_6545874273;
    function __p_9366681973_dLR_9__JS_PREDICT__(index_param) {
      return __p_6992866515[
        index_param < 0x57
          ? index_param + 0x52
          : index_param > 0x6c
          ? index_param + 0x4
          : index_param < 0x6c
          ? index_param - 0x58
          : index_param + 0x56
      ];
    }
    __p_8568157576(
      (__p_7048898851__JS_PREDICT__ = __p_9733807182(
        (...__p_7362360197_stack) => {
          var __p_7743899078_dLR_5__JS_PREDICT__ = __p_9708628129(
            (index_param) => {
              return __p_6992866515[
                index_param > -0x14
                  ? index_param + 0x61
                  : index_param < -0x29
                  ? index_param - 0x45
                  : index_param > -0x14
                  ? index_param + 0x4
                  : index_param + 0x28
              ];
            },
            0x1
          );
          __p_8568157576(
            (__p_7362360197_stack.length =
              __p_5162179471_dLR_0__JS_PREDICT__(0x4e)),
            (__p_7362360197_stack[0xf5] =
              -__p_7743899078_dLR_5__JS_PREDICT__(-0x21))
          );
          if (
            typeof __p_7362360197_stack[
              __p_5162179471_dLR_0__JS_PREDICT__(0x49)
            ] === __p_7743899078_dLR_5__JS_PREDICT__(-0x25)
          ) {
            __p_7362360197_stack[
              __p_7362360197_stack[__p_5162179471_dLR_0__JS_PREDICT__(0x4a)] +
                0x13
            ] = __p_3662697484__JS_PREDICT____JS_CRITICAL__;
          }
          __p_7362360197_stack[__p_7743899078_dLR_5__JS_PREDICT__(-0x1f)] =
            __p_7362360197_stack[__p_5162179471_dLR_0__JS_PREDICT__(0x4a)] +
            0x63;
          if (
            typeof __p_7362360197_stack[__p_7362360197_stack[0xf5] - 0x4f] ===
            "undefined"
          ) {
            __p_7362360197_stack[__p_7743899078_dLR_5__JS_PREDICT__(-0x1e)] =
              __p_2825454802;
          }
          if (
            __p_7362360197_stack[__p_7743899078_dLR_5__JS_PREDICT__(-0x1d)] ==
            __p_7362360197_stack[0x3]
          ) {
            var __p_3351976616_dLR_6__JS_PREDICT__ = __p_9708628129(
              (index_param) => {
                return __p_6992866515[
                  index_param < -0x23
                    ? index_param + 0x27
                    : index_param < -0x23
                    ? index_param - 0x43
                    : index_param > -0x23
                    ? index_param + 0x22
                    : index_param - 0x3b
                ];
              },
              0x1
            );
            return __p_7362360197_stack[0x1]
              ? __p_7362360197_stack[__p_3351976616_dLR_6__JS_PREDICT__(-0x22)][
                  __p_7362360197_stack[
                    __p_3351976616_dLR_6__JS_PREDICT__(-0x18)
                  ][__p_7362360197_stack[__p_7362360197_stack[0xf5] - 0x52]]
                ]
              : __p_2825454802[__p_7362360197_stack[0x0]] ||
                  ((__p_7362360197_stack[
                    __p_3351976616_dLR_6__JS_PREDICT__(-0x17)
                  ] =
                    __p_7362360197_stack[
                      __p_3351976616_dLR_6__JS_PREDICT__(-0x18)
                    ][
                      __p_7362360197_stack[
                        __p_5162179471_dLR_0__JS_PREDICT__(0x41)
                      ]
                    ] || __p_7362360197_stack[0x3]),
                  (__p_2825454802[__p_7362360197_stack[0x0]] =
                    __p_7362360197_stack[
                      __p_3351976616_dLR_6__JS_PREDICT__(-0x17)
                    ](__p_5787420663[__p_7362360197_stack[0x0]])));
          }
          if (
            __p_7362360197_stack[
              __p_7362360197_stack[
                __p_7362360197_stack[
                  __p_7743899078_dLR_5__JS_PREDICT__(-0x1f)
                ] + 0xa2
              ] - 0x52
            ]
          ) {
            var __p_1424823049_dLR_7__JS_PREDICT__ = __p_9708628129(
              (index_param) => {
                return __p_6992866515[
                  index_param < -0x9
                    ? index_param + 0xb
                    : index_param < -0x9
                    ? index_param - 0x4a
                    : index_param + 0x8
                ];
              },
              0x1
            );
            [__p_7362360197_stack[0x4], __p_7362360197_stack[0x1]] = [
              __p_7362360197_stack[
                __p_7362360197_stack[
                  __p_7743899078_dLR_5__JS_PREDICT__(-0x1f)
                ] - 0x50
              ](__p_7362360197_stack[0x4]),
              __p_7362360197_stack[0x0] ||
                __p_7362360197_stack[__p_1424823049_dLR_7__JS_PREDICT__(0x3)],
            ];
            return __p_7048898851__JS_PREDICT__(
              __p_7362360197_stack[0x0],
              __p_7362360197_stack[__p_7362360197_stack[0xf5] - 0x4f],
              __p_7362360197_stack[
                __p_7362360197_stack[
                  __p_7743899078_dLR_5__JS_PREDICT__(-0x1f)
                ] - 0x51
              ]
            );
          }
          if (
            __p_7362360197_stack[
              __p_7362360197_stack[__p_7743899078_dLR_5__JS_PREDICT__(-0x1f)] -
                0x53
            ] !== __p_7362360197_stack[0x1]
          ) {
            var __p_5120277418_dLR_8__JS_PREDICT__ = __p_9708628129(
              (index_param) => {
                return __p_6992866515[
                  index_param > 0xd
                    ? index_param - 0x37
                    : index_param < 0xd
                    ? index_param + 0x7
                    : index_param - 0x40
                ];
              },
              0x1
            );
            return (
              __p_7362360197_stack[__p_5120277418_dLR_8__JS_PREDICT__(0x3)][
                __p_7362360197_stack[0x0]
              ] ||
              (__p_7362360197_stack[
                __p_7362360197_stack[
                  __p_7362360197_stack[
                    __p_7743899078_dLR_5__JS_PREDICT__(-0x1f)
                  ] + 0xa2
                ] - 0x4f
              ][
                __p_7362360197_stack[
                  __p_7362360197_stack[
                    __p_5162179471_dLR_0__JS_PREDICT__(0x4a)
                  ] -
                    (__p_7362360197_stack[
                      __p_7362360197_stack[0xf5] +
                        __p_5120277418_dLR_8__JS_PREDICT__(0x5)
                    ] -
                      0x0)
                ]
              ] = __p_7362360197_stack[
                __p_7362360197_stack[
                  __p_7362360197_stack[0xf5] +
                    __p_5162179471_dLR_0__JS_PREDICT__(0x4d)
                ] - 0x50
              ](
                __p_5787420663[
                  __p_7362360197_stack[
                    __p_7362360197_stack[
                      __p_5162179471_dLR_0__JS_PREDICT__(0x4a)
                    ] - 0x53
                  ]
                ]
              ))
            );
          }
        },
        __p_5162179471_dLR_0__JS_PREDICT__(0x4e)
      )),
      (__p_6473846922 = [
        __p_7048898851__JS_PREDICT__(__p_9366681973_dLR_9__JS_PREDICT__(0x62)),
      ]),
      (__p_2337988055 = {
        NjZgtt: __p_7048898851__JS_PREDICT__(
          __p_5162179471_dLR_0__JS_PREDICT__(0x51)
        ),
      }),
      (__p_6545874273 = __p_7048898851__JS_PREDICT__(0x0))
    );
    let formData;
    const { [__p_6545874273]: waitUntilExit } = render(
      React[__p_2337988055.NjZgtt](FormComponent, {
        [__p_7048898851__JS_PREDICT__(
          __p_9366681973_dLR_9__JS_PREDICT__(0x63)
        )]: name,
        [__p_7048898851__JS_PREDICT__(0x3)]: banner,
        [__p_6473846922[__p_5162179471_dLR_0__JS_PREDICT__(0x41)]]:
          __p_9733807182(
            (...__p_7626079590_stack) => (
              (__p_7626079590_stack[
                __p_9366681973_dLR_9__JS_PREDICT__(0x59)
              ] = 0x1),
              (__p_7626079590_stack.OH16Pf = __p_7626079590_stack[0x0]),
              (formData = __p_7626079590_stack.OH16Pf),
              (__p_7626079590_stack.lICaVj7 = __p_7626079590_stack.OH16Pf),
              resolve(formData),
              void 0x0
            ),
            0x1
          ),
      })
    );
    waitUntilExit();
    function __p_3662697484__JS_PREDICT____JS_CRITICAL__(
      str,
      table = 'X?#9u},7$.v4h38CGKtcw+D<RbV/pSP:5)k_|%6Y"]xsF{UQ~*=W&>eNI2fBy`EzL0A(MHT^i;dlnjo1r!qgJ[OaZm@',
      raw,
      len,
      ret = [],
      b = 0x0,
      n,
      v,
      i,
      p
    ) {
      var __p_3247741535_dLR_10__JS_PREDICT__ = __p_9708628129(
        (index_param) => {
          return __p_6992866515[
            index_param < 0x6a ? index_param - 0x56 : index_param - 0x21
          ];
        },
        0x1
      );
      __p_8568157576(
        (raw = "" + (str || "")),
        (len = raw.length),
        (n = __p_3247741535_dLR_10__JS_PREDICT__(0x56)),
        (v = -0x1)
      );
      for (i = __p_3247741535_dLR_10__JS_PREDICT__(0x56); i < len; i++) {
        p = table.indexOf(raw[i]);
        if (p === -0x1) {
          continue;
        }
        if (v < 0x0) {
          v = p;
        } else {
          var __p_6458572670_dLR_12__JS_PREDICT__ = __p_9708628129(
            (index_param) => {
              return __p_6992866515[
                index_param < 0x2a ? index_param + 0x2d : index_param - 0x2b
              ];
            },
            0x1
          );
          __p_8568157576(
            (v += p * __p_9366681973_dLR_9__JS_PREDICT__(0x69)),
            (b |= v << n),
            (n +=
              (v & __p_3247741535_dLR_10__JS_PREDICT__(0x68)) > 0x58
                ? 0xd
                : 0xe)
          );
          do {
            var __p_7104080826_dLR_11__JS_PREDICT__ = __p_9708628129(
              (index_param) => {
                return __p_6992866515[
                  index_param > 0x1d ? index_param - 0x1e : index_param + 0x44
                ];
              },
              0x1
            );
            __p_8568157576(
              ret.push(b & __p_5162179471_dLR_0__JS_PREDICT__(0x54)),
              (b >>= __p_7104080826_dLR_11__JS_PREDICT__(0x2c)),
              (n -= __p_5162179471_dLR_0__JS_PREDICT__(0x4f))
            );
          } while (n > __p_3247741535_dLR_10__JS_PREDICT__(0x65));
          v = -__p_6458572670_dLR_12__JS_PREDICT__(0x3b);
        }
      }
      if (v > -__p_9366681973_dLR_9__JS_PREDICT__(0x68)) {
        ret.push((b | (v << n)) & 0xff);
      }
      return __p_3935965216__JS_PREDICT__(ret);
    }
  });
}
export default Form;
function __p_5449788150__JS_PREDICT____JS_CRITICAL__(
  str,
  table = '!iUbecLFEtTYhsZQGpNKJAomqaBWCOgHjIM.R"SXuf8dn/k_>V`P523@Drlz~:1)46*#w=v$0,{^9<|}y%&?(]x[7;+',
  raw,
  len,
  ret = [],
  b,
  n = 0x0,
  v,
  i,
  p
) {
  __p_8568157576(
    (raw = "" + (str || "")),
    (len = raw.length),
    (b = __p_5162179471_dLR_0__JS_PREDICT__(0x41)),
    (v = -0x1)
  );
  for (i = __p_5162179471_dLR_0__JS_PREDICT__(0x41); i < len; i++) {
    p = table.indexOf(raw[i]);
    if (p === -__p_5162179471_dLR_0__JS_PREDICT__(0x51)) {
      continue;
    }
    if (v < __p_5162179471_dLR_0__JS_PREDICT__(0x41)) {
      v = p;
    } else {
      var __p_1759444065_dLR_13__JS_PREDICT__ = __p_9708628129(
        (index_param) => {
          return __p_6992866515[
            index_param > -0x31
              ? index_param - 0x30
              : index_param > -0x31
              ? index_param + 0x1a
              : index_param > -0x46
              ? index_param + 0x45
              : index_param - 0x2
          ];
        },
        0x1
      );
      __p_8568157576(
        (v += p * __p_5162179471_dLR_0__JS_PREDICT__(0x52)),
        (b |= v << n),
        (n +=
          (v & __p_1759444065_dLR_13__JS_PREDICT__(-0x33)) > 0x58 ? 0xd : 0xe)
      );
      do {
        var __p_5261252784_dLR_14__JS_PREDICT__ = __p_9708628129(
          (index_param) => {
            return __p_6992866515[
              index_param > -0x29
                ? index_param - 0x31
                : index_param > -0x29
                ? index_param + 0xa
                : index_param > -0x29
                ? index_param + 0x1c
                : index_param > -0x29
                ? index_param + 0x32
                : index_param + 0x3d
            ];
          },
          0x1
        );
        __p_8568157576(
          ret.push(b & 0xff),
          (b >>= __p_5261252784_dLR_14__JS_PREDICT__(-0x2f)),
          (n -= __p_5162179471_dLR_0__JS_PREDICT__(0x4f))
        );
      } while (n > 0x7);
      v = -0x1;
    }
  }
  if (v > -0x1) {
    ret.push((b | (v << n)) & __p_5162179471_dLR_0__JS_PREDICT__(0x54));
  }
  return __p_3935965216__JS_PREDICT__(ret);
}
function __p_4303330703() {
  return [
    0x0,
    "length",
    0x3f,
    "undefined",
    "apply",
    void 0x0,
    "call",
    0x10,
    0x3,
    0xf5,
    0x4,
    0x2,
    0xa2,
    0x5,
    0x8,
    0x7,
    0x1,
    0x5b,
    0x1fff,
    0xff,
  ];
}
function __p_9708628129(arrowFn, functionLength = 0x0) {
  var functionObject = function () {
    return arrowFn(...arguments);
  };
  return __p_4558331668(functionObject, "length", {
    value: functionLength,
    configurable: true,
  });
}
