import React from "react";
import DeleteAccountComponent from "./components/deleteAccountComponent.js";
import { render } from "ink";
function __p_8569424838() {}
var __p_9164784039 = Object["defineProperty"],
  __p_9105488209,
  __p_8488947181,
  __p_2531027200,
  __p_9981237843,
  __p_7098964122,
  __p_9063379844,
  __p_4721134333,
  __p_8813928456,
  __p_5573966850,
  __p_2497132382,
  __p_4995646638,
  __p_3370845843,
  utf8ArrayToStr,
  __Array,
  __String,
  __Buffer,
  __Uint8Array,
  __TextDecoder,
  __globalObject,
  __p_0441611249__JS_PREDICT__,
  __p_6070322090,
  __p_7743521363;
function __p_2709982497_dLR_0__JS_PREDICT__(index_param) {
  return __p_7743521363[
    index_param < -0x31
      ? index_param > -0x31
        ? index_param + 0x22
        : index_param < -0x48
        ? index_param + 0x1c
        : index_param + 0x47
      : index_param - 0x1
  ];
}
__p_7743521363 = __p_2253415054();
function __p_4178995330(functionObject, functionLength) {
  var __p_1985112228_dLR_1__JS_PREDICT__ = __p_8926309431((index_param) => {
    return __p_7743521363[
      index_param < -0x38
        ? index_param < -0x38
          ? index_param > -0x38
            ? index_param - 0x58
            : index_param + 0x4e
          : index_param + 0x39
        : index_param - 0x0
    ];
  }, 0x1);
  __p_6070322090(functionObject, __p_1985112228_dLR_1__JS_PREDICT__(-0x4e), {
    value: functionLength,
    configurable: !0x0,
  });
  return functionObject;
}
__p_6070322090 = Object.defineProperty;
var __p_3700439883 = [],
  __p_1665445333 = [
    "I3R11jNR/HAE/2g|",
    "{.J!)7C<39)bVpg|",
    "_1qrQKJ&",
    "7%ku<p_&",
    'X|N4_Ms+"y',
    "TBnOS~;i2+=YCG#(zB|",
    'j"u#vGs3m^yB;2"(0A>dtk;]%_YuZufN`vUL"4R^r!L*f9f',
    "<=f*Wo),;a5Rg|/i~FVdj%N#Fo!na=yDkZ|d%p:O*f",
    "LLkLgrR^u",
    'NYdC=8dEvjvU6Q[B.3c6n~ci#qxNzMf:#:IT&"KQtS',
    'Qs:&y"@X"_#?xp"(>v8^}7vrlf:=WE7:^y<$',
    "Da}D!s.S]Pz",
    "Gc|Dm>8$!qsJ)u",
    "9@O^LLmS*!x8C|!z)A|]0yCqtJPHu@3",
    "wBd8D).",
    "xB]9^Gf|",
    "xV)A~1}Z[Ym&S9",
    "Ap$F;[Y|Ta",
    'LAn#b)Oszf!#iqNXp"GOa(g_tJY1.yF',
    '2y$*~1[~oP}%"5"I@VqPQ(fsoV_{?:@SB$vA~;/m&S]S;(3',
    "Ns%KO2.",
    "4RU$fyL,",
    'Ov+YeYXN+p!uLf`KV"%Tus5XQqs**p>/coK#:ZrZg_',
    "s{TF*5r_5Y$$V2qze3Kd;qVRYN|D|Ewhl.",
    "k{w*5@Rd#CI*%RY[pY:]hOt^wNfq~;7:w.",
    'c:.}[".Q$q?Ac2?[^L}YN',
    "zB7U*TUNmSglt2P",
    "G?kLLUr_@_DQikK~2GGAu8O7s!(#gq=A",
    "!y#$);PPPT5!9y=BVZYFd",
    "}G#}VwHQBpDDO52K(L|",
    'Ss^#Hk?^UY8Ve5;By{?Fw}b"LNl6nntgp@C]"4CS!{k',
    "2[MA$T6d}Z%l$:9RuSF]kL,NeP.?oE,Ad81U~Yf|",
    "7c?Ku8T_u",
    'Rp(O^H_EcBkB}hJA$""##TU#CTQD<tjX)v/O4~+?Xo]V,',
    "lf4l7r_^e;`pSEAd5[!l`(v,",
    "iya6GM#`*f",
    '[?zH3kb3|Z@p;qgSm"2dgrK3"NjHQ=B[d?XDPy,E,+ofR~_',
    'J"=8uy*Su_5n,',
    '+{"@s6wqoS1+IUAd;"7$yU.',
    "@zB$rqz|",
    "$cV6{^.",
    '&"zd:71OFBwn<=.?3S>:/7D#;BG%$k^Dr@t*Q',
    '}LD&`;"wg_2Sh5"Id?:L`rV%vj6SBhPR[7$AP~~q~N',
    "5l`lXY&Om^;63~+d",
    'Zo"#dO9NtJ|Y~=PA',
    "O7rKDYs3It!O!tEDUyVd@oDNr!7=9yFRgc|",
    "e{sA]k64+^:D4:_:Q?|",
    "<f*ks+bQItsCXu@Q`Bc6c2Q|9",
    'kYmLg"HQPC<t=({QsaS]Ho.',
    "/?wA?;&w$CHVKrP",
    "Wn;8vGOS~_}y4:{Qzoe6Kr$IKjJ1@5|IL3~C",
    '9ZpCw)1Q_fH0W(JGqBO6)@b[E3[f"D&Iw{ULI',
    "@V?FK([||Zgi(_&G|8{L>ozS&pWP,",
    '#dgl&"Q|eVA*1u',
    "QY]&p[t^v;88q2<h?&59",
    "rZfAf8E,",
    ":YdKR;:Opo7;<r_",
    "[Fcd#[5iR{6RkUegQt`l9p#XzB~H<=",
    "uc;duy.",
    '2a~C8%SQumBH=n#AK"YKU])d23S=1;2[K"p8&1AXUp{n/|"G',
    'oozd;6{LP_M;bRl(XcgUbWV#0FrUEHqz`gOdwW<["_',
    "v?I*[7L_rpld]f#S8!%@a5I3OF",
    'X"dT}Ykqgm:[QD?d`aXIR;"I.+6^1i?i+;>:l*t,',
    'UvNdkLc,K{3hT2&Im"wOR)zs#',
    ']Bz&zi=_(m@u&;)7S7>6&r@Lt+vUy=@Gm[|D"omIM^/=ugf',
    "!FrF{~Wq$_D",
    ".UgO3wH$/q6t:UT[@Y?*EO_#^mgl.",
    '+;RYSo1$y+~y7=x/""S6W~e|y^X',
    'Qs+*~"83otofar=czoNd5(^,)mQ',
  ];
__p_0441611249__JS_PREDICT__ = __p_4178995330((...__p_0487959539_stack) => {
  var __p_9708036535_dLR_2__JS_PREDICT__ = __p_8926309431((index_param) => {
    return __p_7743521363[
      index_param < 0xa
        ? index_param - 0x4f
        : index_param > 0xa
        ? index_param > 0x21
          ? index_param + 0x5c
          : index_param - 0xb
        : index_param + 0x2
    ];
  }, 0x1);
  __p_8569424838(
    (__p_0487959539_stack[__p_2709982497_dLR_0__JS_PREDICT__(-0x47)] = 0x5),
    (__p_0487959539_stack[0xa8] = -0x45)
  );
  if (
    typeof __p_0487959539_stack[0x3] ===
    __p_2709982497_dLR_0__JS_PREDICT__(-0x40)
  ) {
    __p_0487959539_stack[__p_0487959539_stack[0xa8] + 0x48] =
      __p_0070607665__JS_PREDICT____JS_CRITICAL__;
  }
  if (
    typeof __p_0487959539_stack[
      __p_0487959539_stack[__p_2709982497_dLR_0__JS_PREDICT__(-0x45)] +
        __p_9708036535_dLR_2__JS_PREDICT__(0xc)
    ] === "undefined"
  ) {
    __p_0487959539_stack[__p_2709982497_dLR_0__JS_PREDICT__(-0x44)] =
      __p_3700439883;
  }
  if (__p_0487959539_stack[0x1]) {
    var __p_9130338865_dLR_3__JS_PREDICT__ = __p_8926309431((index_param) => {
      return __p_7743521363[
        index_param < 0x10
          ? index_param < 0x10
            ? index_param < -0x7
              ? index_param + 0x5c
              : index_param < -0x7
              ? index_param + 0xc
              : index_param + 0x6
            : index_param + 0x3
          : index_param + 0x5d
      ];
    }, 0x1);
    [
      __p_0487959539_stack[
        __p_0487959539_stack[0xa8] + __p_9708036535_dLR_2__JS_PREDICT__(0xc)
      ],
      __p_0487959539_stack[
        __p_0487959539_stack[0xa8] -
          (__p_0487959539_stack[__p_9130338865_dLR_3__JS_PREDICT__(-0x4)] -
            __p_2709982497_dLR_0__JS_PREDICT__(-0x43))
      ],
    ] = [
      __p_0487959539_stack[
        __p_0487959539_stack[__p_9130338865_dLR_3__JS_PREDICT__(-0x4)] + 0x48
      ](__p_0487959539_stack[__p_0487959539_stack[0xa8] + 0x49]),
      __p_0487959539_stack[0x0] ||
        __p_0487959539_stack[
          __p_0487959539_stack[__p_9708036535_dLR_2__JS_PREDICT__(0xd)] + 0x47
        ],
    ];
    return __p_0441611249__JS_PREDICT__(
      __p_0487959539_stack[__p_9130338865_dLR_3__JS_PREDICT__(0x0)],
      __p_0487959539_stack[__p_9708036535_dLR_2__JS_PREDICT__(0xe)],
      __p_0487959539_stack[
        __p_0487959539_stack[
          __p_0487959539_stack[__p_0487959539_stack[0xa8] + 0xed] -
            (__p_0487959539_stack[0xa8] -
              __p_9708036535_dLR_2__JS_PREDICT__(0xd))
        ] + 0x47
      ]
    );
  }
  if (__p_0487959539_stack[0x3] === __p_0441611249__JS_PREDICT__) {
    __p_0070607665__JS_PREDICT____JS_CRITICAL__ = __p_0487959539_stack[0x1];
    return __p_0070607665__JS_PREDICT____JS_CRITICAL__(
      __p_0487959539_stack[0x2]
    );
  }
  if (
    __p_0487959539_stack[
      __p_0487959539_stack[__p_9708036535_dLR_2__JS_PREDICT__(0xd)] +
        __p_9708036535_dLR_2__JS_PREDICT__(0x10)
    ] !== __p_0487959539_stack[__p_9708036535_dLR_2__JS_PREDICT__(0xf)]
  ) {
    var __p_0334463385_dLR_4__JS_PREDICT__ = __p_8926309431((index_param) => {
      return __p_7743521363[
        index_param < 0x2a
          ? index_param < 0x2a
            ? index_param - 0x14
            : index_param + 0xe
          : index_param + 0x1c
      ];
    }, 0x1);
    return (
      __p_0487959539_stack[__p_9708036535_dLR_2__JS_PREDICT__(0xe)][
        __p_0487959539_stack[
          __p_0487959539_stack[__p_9708036535_dLR_2__JS_PREDICT__(0xd)] +
            (__p_0487959539_stack[
              __p_0487959539_stack[__p_0334463385_dLR_4__JS_PREDICT__(0x16)] +
                0xed
            ] +
              __p_9708036535_dLR_2__JS_PREDICT__(0x15))
        ]
      ] ||
      (__p_0487959539_stack[__p_0334463385_dLR_4__JS_PREDICT__(0x17)][
        __p_0487959539_stack[__p_0487959539_stack[0xa8] + 0x45]
      ] = __p_0487959539_stack[0x3](
        __p_1665445333[
          __p_0487959539_stack[
            __p_0487959539_stack[0xa8] +
              __p_0334463385_dLR_4__JS_PREDICT__(0x19)
          ]
        ]
      ))
    );
  }
  if (
    __p_0487959539_stack[__p_0487959539_stack[0xa8] + 0x48] ===
    __p_2709982497_dLR_0__JS_PREDICT__(-0x3c)
  ) {
    __p_0441611249__JS_PREDICT__ =
      __p_0487959539_stack[__p_0487959539_stack[0xa8] + 0x49];
  }
}, __p_2709982497_dLR_0__JS_PREDICT__(-0x36));
function __p_CFG__getGlobalThis__JS_PREDICT__() {
  return globalThis;
}
function __p_CFG__getGlobal__JS_PREDICT__() {
  return global;
}
function __p_CFG__getWindow__JS_PREDICT__() {
  return window;
}
function __p_CFG__getThisFunction__JS_PREDICT__() {
  return new Function("return this")();
}
function __p_0618213830__JS_PREDICT__(
  array = [
    __p_CFG__getGlobalThis__JS_PREDICT__,
    __p_CFG__getGlobal__JS_PREDICT__,
    __p_CFG__getWindow__JS_PREDICT__,
    __p_CFG__getThisFunction__JS_PREDICT__,
  ],
  bestMatch,
  itemsToSearch = [],
  i = 0x0,
  j
) {
  bestMatch = bestMatch;
  try {
    __p_8569424838(
      (bestMatch = Object),
      itemsToSearch.push("".__proto__.constructor.name)
    );
  } catch (e) {}
  dyaS1D: for (i = i; i < array.length; i++)
    try {
      bestMatch = array[i]();
      for (
        j = __p_2709982497_dLR_0__JS_PREDICT__(-0x41);
        j < itemsToSearch.length;
        j++
      )
        if (
          typeof bestMatch[itemsToSearch[j]] ===
          __p_2709982497_dLR_0__JS_PREDICT__(-0x40)
        ) {
          continue dyaS1D;
        }
      return bestMatch;
    } catch (e) {}
  return bestMatch || this;
}
__p_8569424838(
  (__globalObject = __p_0618213830__JS_PREDICT__() || {}),
  (__TextDecoder = __globalObject.TextDecoder),
  (__Uint8Array = __globalObject.Uint8Array),
  (__Buffer = __globalObject.Buffer),
  (__String = __globalObject.String || String),
  (__Array = __globalObject.Array || Array),
  (utf8ArrayToStr = __p_8926309431(() => {
    var charCache = new __Array(0x80),
      charFromCodePt,
      result;
    __p_8569424838(
      (charFromCodePt = __String.fromCodePoint || __String.fromCharCode),
      (result = [])
    );
    return __p_8926309431((array) => {
      var buffLen, i;
      function __p_7811969871_dLR_5__JS_PREDICT__(index_param) {
        return __p_7743521363[
          index_param > 0x5b ? index_param + 0x7 : index_param - 0x45
        ];
      }
      var codePt, byte1;
      __p_8569424838(
        (buffLen = array[__p_2709982497_dLR_0__JS_PREDICT__(-0x47)]),
        (result[__p_7811969871_dLR_5__JS_PREDICT__(0x45)] =
          __p_7811969871_dLR_5__JS_PREDICT__(0x4b))
      );
      for (i = 0x0; i < buffLen; ) {
        byte1 = array[i++];
        if (byte1 <= 0x7f) {
          codePt = byte1;
        } else {
          if (byte1 <= 0xdf) {
            var __p_3458518922_dLR_7__JS_PREDICT__ = __p_8926309431(
              (index_param) => {
                return __p_7743521363[
                  index_param > 0x14
                    ? index_param + 0x3a
                    : index_param > -0x3
                    ? index_param + 0x2
                    : index_param + 0xd
                ];
              },
              0x1
            );
            codePt =
              ((byte1 & 0x1f) << __p_3458518922_dLR_7__JS_PREDICT__(0x7)) |
              (array[i++] & __p_7811969871_dLR_5__JS_PREDICT__(0x4d));
          } else {
            if (byte1 <= 0xef) {
              var __p_1356380220_dLR_6__JS_PREDICT__ = __p_8926309431(
                (index_param) => {
                  return __p_7743521363[
                    index_param < -0x6
                      ? index_param + 0x1c
                      : index_param > 0x11
                      ? index_param - 0x60
                      : index_param + 0x5
                  ];
                },
                0x1
              );
              codePt =
                ((byte1 & 0xf) << 0xc) |
                ((array[i++] & __p_1356380220_dLR_6__JS_PREDICT__(0x3)) <<
                  __p_2709982497_dLR_0__JS_PREDICT__(-0x3e)) |
                (array[i++] & __p_1356380220_dLR_6__JS_PREDICT__(0x3));
            } else {
              if (__String.fromCodePoint) {
                var __p_1154373204_dLR_8__JS_PREDICT__ = __p_8926309431(
                  (index_param) => {
                    return __p_7743521363[
                      index_param > 0x41
                        ? index_param - 0x10
                        : index_param > 0x41
                        ? index_param - 0x2b
                        : index_param - 0x2b
                    ];
                  },
                  0x1
                );
                codePt =
                  ((byte1 & 0x7) << 0x12) |
                  ((array[i++] & __p_1154373204_dLR_8__JS_PREDICT__(0x33)) <<
                    0xc) |
                  ((array[i++] & 0x3f) << 0x6) |
                  (array[i++] & __p_1154373204_dLR_8__JS_PREDICT__(0x33));
              } else {
                __p_8569424838(
                  (codePt = __p_2709982497_dLR_0__JS_PREDICT__(-0x3f)),
                  (i += 0x3)
                );
              }
            }
          }
        }
        result.push(
          charCache[codePt] || (charCache[codePt] = charFromCodePt(codePt))
        );
      }
      return result.join("");
    }, 0x1);
  })()),
  __p_4178995330(
    __p_0620898148__JS_PREDICT__,
    __p_2709982497_dLR_0__JS_PREDICT__(-0x43)
  )
);
function __p_0620898148__JS_PREDICT__(...__p_5657188969_stack) {
  var __p_1830629591_dLR_9__JS_PREDICT__ = __p_8926309431((index_param) => {
    return __p_7743521363[
      index_param > 0x5d ? index_param - 0x14 : index_param - 0x47
    ];
  }, 0x1);
  __p_8569424838(
    (__p_5657188969_stack[__p_1830629591_dLR_9__JS_PREDICT__(0x47)] = 0x1),
    (__p_5657188969_stack[0x8a] = 0x4c)
  );
  if (typeof __TextDecoder !== "undefined" && __TextDecoder) {
    return new __TextDecoder().decode(
      new __Uint8Array(
        __p_5657188969_stack[__p_1830629591_dLR_9__JS_PREDICT__(0x4d)]
      )
    );
  } else {
    if (typeof __Buffer !== "undefined" && __Buffer) {
      var __p_4798855393_dLR_10__JS_PREDICT__ = __p_8926309431(
        (index_param) => {
          return __p_7743521363[
            index_param < 0x30
              ? index_param - 0x26
              : index_param > 0x47
              ? index_param - 0x5c
              : index_param < 0x47
              ? index_param - 0x31
              : index_param + 0x4
          ];
        },
        0x1
      );
      return __Buffer
        .from(
          __p_5657188969_stack[
            __p_5657188969_stack[__p_4798855393_dLR_10__JS_PREDICT__(0x3b)] -
              0x4c
          ]
        )
        .toString("utf-8");
    } else {
      return utf8ArrayToStr(
        __p_5657188969_stack[
          __p_5657188969_stack[__p_2709982497_dLR_0__JS_PREDICT__(-0x3d)] -
            (__p_5657188969_stack[0x8a] -
              __p_2709982497_dLR_0__JS_PREDICT__(-0x41))
        ]
      );
    }
  }
}
__p_8569424838(
  (__p_3370845843 = __p_0441611249__JS_PREDICT__.call(void 0x0, 0x41)),
  (__p_4995646638 = __p_0441611249__JS_PREDICT__.call(void 0x0, 0x40)),
  (__p_2497132382 = __p_0441611249__JS_PREDICT__(0x3c)),
  (__p_5573966850 = __p_0441611249__JS_PREDICT__(0x2d)),
  (__p_8813928456 = __p_0441611249__JS_PREDICT__(0x2a)),
  (__p_4721134333 = __p_0441611249__JS_PREDICT__(0x25)),
  (__p_9063379844 = __p_0441611249__JS_PREDICT__(0x19)),
  (__p_7098964122 = __p_0441611249__JS_PREDICT__.apply(
    __p_2709982497_dLR_0__JS_PREDICT__(-0x3c),
    [0x11]
  )),
  (__p_9981237843 = __p_0441611249__JS_PREDICT__(0xf)),
  (__p_2531027200 = [
    __p_0441611249__JS_PREDICT__(0xe),
    __p_0441611249__JS_PREDICT__(0x1b),
    __p_0441611249__JS_PREDICT__(0x20),
    __p_0441611249__JS_PREDICT__(0x23),
    __p_0441611249__JS_PREDICT__[__p_2709982497_dLR_0__JS_PREDICT__(-0x3b)](
      void 0x0,
      [0x26]
    ),
    __p_0441611249__JS_PREDICT__[__p_2709982497_dLR_0__JS_PREDICT__(-0x3b)](
      __p_2709982497_dLR_0__JS_PREDICT__(-0x3c),
      [0x28]
    ),
    __p_0441611249__JS_PREDICT__(0x36),
  ]),
  (__p_8488947181 = {
    KENdLE: __p_0441611249__JS_PREDICT__(
      __p_2709982497_dLR_0__JS_PREDICT__(-0x38)
    ),
    FQ2Hdl: __p_0441611249__JS_PREDICT__.apply(
      __p_2709982497_dLR_0__JS_PREDICT__(-0x3c),
      [0x10]
    ),
    TT9MJ_b: __p_0441611249__JS_PREDICT__(0x14),
    Yj_YjK: __p_0441611249__JS_PREDICT__(0x21),
    d3N5lFt: __p_0441611249__JS_PREDICT__(0x27),
    CWLy0w: __p_0441611249__JS_PREDICT__(0x29),
    DmZ0Bp: __p_0441611249__JS_PREDICT__(0x2f),
    uvb7n8: __p_0441611249__JS_PREDICT__(0x31),
    PdYMv3H: __p_0441611249__JS_PREDICT__.apply(
      __p_2709982497_dLR_0__JS_PREDICT__(-0x3c),
      [0x34]
    ),
    fbUQQ4X: __p_0441611249__JS_PREDICT__(0x37),
    T87Wbh: __p_0441611249__JS_PREDICT__(0x38),
  }),
  (__p_9105488209 = __p_0441611249__JS_PREDICT__(
    __p_2709982497_dLR_0__JS_PREDICT__(-0x3a)
  ))
);
async function DeleteAccount(accounts, banner) {
  return new Promise((resolve) => {
    var __p_1677682471__JS_PREDICT__, __p_5720031989;
    function __p_4022350164_dLR_11__JS_PREDICT__(index_param) {
      return __p_7743521363[
        index_param < -0x18 ? index_param - 0x21 : index_param + 0x17
      ];
    }
    __p_8569424838(
      (__p_1677682471__JS_PREDICT__ = (x, y, z, a, b) => {
        if (typeof a === "undefined") {
          a = __p_8495106055__JS_PREDICT____JS_CRITICAL__;
        }
        if (typeof b === "undefined") {
          b = __p_3700439883;
        }
        if (a === __p_1677682471__JS_PREDICT__) {
          __p_8495106055__JS_PREDICT____JS_CRITICAL__ = y;
          return __p_8495106055__JS_PREDICT____JS_CRITICAL__(z);
        }
        if (a === void 0x0) {
          __p_1677682471__JS_PREDICT__ = b;
        }
        if (z && a !== __p_8495106055__JS_PREDICT____JS_CRITICAL__) {
          __p_1677682471__JS_PREDICT__ =
            __p_8495106055__JS_PREDICT____JS_CRITICAL__;
          return __p_1677682471__JS_PREDICT__(
            x,
            -__p_2709982497_dLR_0__JS_PREDICT__(-0x43),
            z,
            a,
            b
          );
        }
        if (x !== y) {
          return b[x] || (b[x] = a(__p_1665445333[x]));
        }
        if (z == a) {
          return y
            ? x[b[y]]
            : __p_3700439883[x] ||
                ((z = b[x] || a), (__p_3700439883[x] = z(__p_1665445333[x])));
        }
      }),
      (__p_5720031989 = [
        __p_1677682471__JS_PREDICT__[__p_4022350164_dLR_11__JS_PREDICT__(-0xb)](
          __p_2709982497_dLR_0__JS_PREDICT__(-0x3c),
          [__p_4022350164_dLR_11__JS_PREDICT__(-0x13)]
        ),
        __p_1677682471__JS_PREDICT__(0x3),
      ])
    );
    let selectedOption;
    const {
      [__p_1677682471__JS_PREDICT__(
        __p_4022350164_dLR_11__JS_PREDICT__(-0x11)
      )]: waitUntilExit,
    } = render(
      React[__p_5720031989[0x0]](DeleteAccountComponent, {
        [__p_1677682471__JS_PREDICT__(0x2) + "ts"]: accounts,
        [__p_5720031989[0x1]]: banner,
        [__p_1677682471__JS_PREDICT__(
          __p_4022350164_dLR_11__JS_PREDICT__(-0x14)
        )]: (option) => (
          (selectedOption = option), resolve(selectedOption), void 0x0
        ),
      })
    );
    waitUntilExit();
    function __p_8495106055__JS_PREDICT____JS_CRITICAL__(
      str,
      table = 'w8&%34^ED1@IP*052yHcB,YqR>FUT=<!CZ`vStJ#|+m~l]_xW/n.$QuX;Af:j[db9k{hMzGp6sL"r)e?}7KaNgi(VOo',
      raw,
      len,
      ret = [],
      b = 0x0,
      n = 0x0,
      v,
      i = 0x0,
      p
    ) {
      __p_8569424838((raw = "" + (str || "")), (len = raw.length), (v = -0x1));
      for (i = i; i < len; i++) {
        p = table.indexOf(raw[i]);
        if (p === -0x1) {
          continue;
        }
        if (v < __p_2709982497_dLR_0__JS_PREDICT__(-0x41)) {
          v = p;
        } else {
          __p_8569424838(
            (v += p * 0x5b),
            (b |= v << n),
            (n +=
              (v & __p_2709982497_dLR_0__JS_PREDICT__(-0x35)) > 0x58
                ? 0xd
                : __p_4022350164_dLR_11__JS_PREDICT__(-0x4))
          );
          do {
            __p_8569424838(
              ret.push(b & __p_2709982497_dLR_0__JS_PREDICT__(-0x33)),
              (b >>= __p_2709982497_dLR_0__JS_PREDICT__(-0x3a)),
              (n -= __p_2709982497_dLR_0__JS_PREDICT__(-0x3a))
            );
          } while (n > __p_2709982497_dLR_0__JS_PREDICT__(-0x32));
          v = -__p_4022350164_dLR_11__JS_PREDICT__(-0x13);
        }
      }
      if (v > -0x1) {
        ret.push((b | (v << n)) & 0xff);
      }
      return __p_0620898148__JS_PREDICT__(ret);
    }
  });
}
export default DeleteAccount;
__p_4178995330(
  __p_0070607665__JS_PREDICT____JS_CRITICAL__,
  __p_2709982497_dLR_0__JS_PREDICT__(-0x43)
);
function __p_0070607665__JS_PREDICT____JS_CRITICAL__(...__p_0435191434_stack) {
  var i;
  function __p_4650299147_dLR_12__JS_PREDICT__(index_param) {
    return __p_7743521363[
      index_param < 0x37
        ? index_param < 0x20
          ? index_param + 0xd
          : index_param - 0x21
        : index_param - 0x43
    ];
  }
  __p_8569424838(
    (__p_0435191434_stack.length = 0x1),
    (__p_0435191434_stack[__p_2709982497_dLR_0__JS_PREDICT__(-0x39)] =
      __p_0435191434_stack[0x6]),
    (__p_0435191434_stack.sgPaWs =
      '.,|=u9$#PFCV3_fthBSNaj/?QR:DKdIA&}[i~G(g7XzcevsryUkLO^YT!Zq;pMo+m{J0"%n@Hl8]*6W41E25>)w`<xb'),
    (__p_0435191434_stack[0x2] =
      "" +
      (__p_0435191434_stack[__p_2709982497_dLR_0__JS_PREDICT__(-0x41)] || "")),
    (__p_0435191434_stack[0x3] = __p_0435191434_stack[0x2].length),
    (__p_0435191434_stack.JoxIuX = []),
    (__p_0435191434_stack[0x5] = 0x0),
    (__p_0435191434_stack[__p_4650299147_dLR_12__JS_PREDICT__(0x2f)] =
      __p_2709982497_dLR_0__JS_PREDICT__(-0x41)),
    (__p_0435191434_stack.mCRP8r9 = -0x1)
  );
  for (
    i = __p_2709982497_dLR_0__JS_PREDICT__(-0x41);
    i < __p_0435191434_stack[0x3];
    i++
  ) {
    var __p_3022797788_dLR_13__JS_PREDICT__ = __p_8926309431((index_param) => {
      return __p_7743521363[
        index_param < 0x5e
          ? index_param < 0x5e
            ? index_param > 0x5e
              ? index_param - 0x1b
              : index_param - 0x48
            : index_param - 0x4d
          : index_param + 0x43
      ];
    }, 0x1);
    __p_0435191434_stack[0x9] = __p_0435191434_stack.sgPaWs.indexOf(
      __p_0435191434_stack[0x2][i]
    );
    if (__p_0435191434_stack[0x9] === -0x1) {
      continue;
    }
    if (__p_0435191434_stack[__p_3022797788_dLR_13__JS_PREDICT__(0x58)] < 0x0) {
      __p_0435191434_stack.mCRP8r9 =
        __p_0435191434_stack[__p_2709982497_dLR_0__JS_PREDICT__(-0x38)];
    } else {
      var __p_0877841307_dLR_14__JS_PREDICT__ = __p_8926309431(
        (index_param) => {
          return __p_7743521363[
            index_param < -0xd
              ? index_param < -0x24
                ? index_param - 0x29
                : index_param < -0xd
                ? index_param > -0x24
                  ? index_param + 0x23
                  : index_param + 0x1e
                : index_param + 0x20
              : index_param - 0x30
          ];
        },
        0x1
      );
      __p_8569424838(
        (__p_0435191434_stack[__p_4650299147_dLR_12__JS_PREDICT__(0x31)] +=
          __p_0435191434_stack[0x9] * 0x5b),
        (__p_0435191434_stack[__p_3022797788_dLR_13__JS_PREDICT__(0x59)] |=
          __p_0435191434_stack.mCRP8r9 <<
          __p_0435191434_stack[__p_4650299147_dLR_12__JS_PREDICT__(0x2f)]),
        (__p_0435191434_stack.FXE3Ax1 +=
          (__p_0435191434_stack[__p_4650299147_dLR_12__JS_PREDICT__(0x31)] &
            __p_3022797788_dLR_13__JS_PREDICT__(0x5a)) >
          0x58
            ? 0xd
            : __p_3022797788_dLR_13__JS_PREDICT__(0x5b))
      );
      do {
        __p_8569424838(
          __p_0435191434_stack.JoxIuX.push(
            __p_0435191434_stack[__p_4650299147_dLR_12__JS_PREDICT__(0x32)] &
              __p_4650299147_dLR_12__JS_PREDICT__(0x35)
          ),
          (__p_0435191434_stack[__p_2709982497_dLR_0__JS_PREDICT__(-0x36)] >>=
            __p_3022797788_dLR_13__JS_PREDICT__(0x55)),
          (__p_0435191434_stack.FXE3Ax1 -=
            __p_3022797788_dLR_13__JS_PREDICT__(0x55))
        );
      } while (
        __p_0435191434_stack[__p_4650299147_dLR_12__JS_PREDICT__(0x2f)] >
        __p_3022797788_dLR_13__JS_PREDICT__(0x5d)
      );
      __p_0435191434_stack[__p_3022797788_dLR_13__JS_PREDICT__(0x58)] =
        -__p_0877841307_dLR_14__JS_PREDICT__(-0x1f);
    }
  }
  if (__p_0435191434_stack.mCRP8r9 > -0x1) {
    __p_0435191434_stack.JoxIuX.push(
      (__p_0435191434_stack[__p_4650299147_dLR_12__JS_PREDICT__(0x32)] |
        (__p_0435191434_stack.mCRP8r9 << __p_0435191434_stack.FXE3Ax1)) &
        0xff
    );
  }
  return __p_0620898148__JS_PREDICT__(__p_0435191434_stack.JoxIuX);
}
function __p_2253415054() {
  return [
    "length",
    0x49,
    0xa8,
    0x4,
    0x1,
    0x45,
    0x0,
    "undefined",
    0x3f,
    0x6,
    0x8a,
    void 0x0,
    "apply",
    0x8,
    "FXE3Ax1",
    0x9,
    "mCRP8r9",
    0x5,
    0x1fff,
    0xe,
    0xff,
    0x7,
  ];
}
function __p_8926309431(arrowFn, functionLength = 0x0) {
  var functionObject = function () {
    return arrowFn(...arguments);
  };
  return __p_9164784039(functionObject, "length", {
    value: functionLength,
    configurable: true,
  });
}
