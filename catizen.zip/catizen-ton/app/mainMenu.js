import React from "react";
import { render } from "ink";
import MainMenuComponent from "./components/mainMenuComponent.js";
function __p_0356976742() {}
var __p_3354172707 = Object["defineProperty"],
  __p_4134879266,
  __p_0888003396,
  __p_1500469555,
  __p_2949989374,
  __p_6694294378,
  __p_4257962512,
  __p_9581269544,
  __p_5573237569,
  __p_2217215703,
  __p_2408272888,
  utf8ArrayToStr,
  __Array,
  __String,
  __Buffer,
  __Uint8Array,
  __TextDecoder,
  __globalObject,
  __p_0979838867__JS_PREDICT__,
  __p_3838869626,
  __p_6874866366;
function __p_1551333273_dLR_0__JS_PREDICT__(index_param) {
  return __p_6874866366[
    index_param < -0x7
      ? index_param < -0x7
        ? index_param > -0x7
          ? index_param + 0x5c
          : index_param + 0x2c
        : index_param + 0x58
      : index_param + 0x12
  ];
}
__p_6874866366 = __p_1629576183();
function __p_0745069019(functionObject, functionLength) {
  __p_3838869626(functionObject, "length", {
    value: functionLength,
    configurable: !0x0,
  });
  return functionObject;
}
__p_3838869626 = Object.defineProperty;
var __p_4562811552 = [],
  __p_6525429138 = [
    "@ro00:{o}$&d}pF8",
    "25%tKSfw",
    "Bz%t+x%w",
    "SR!Q+xlw",
    "~8{Olvq>)P",
    "|JqS1Nn",
    "<h_#I9YYVWQ`0ZW",
    'oVs$R9rfUZJ#~A^rr7I=P^z!*~""Y2+sq.rmAfsI!?y3cEg',
    "89POn5`9rJ7uzg;f|gv1(EZ!UVn&YOIb",
    "Od*YlLX!qb04VgOwa)@0S#25K",
    "@($,wwJYfm0",
    "RW9$a+|BH?r",
    "9~N1z(0P",
    "$BM+Udn",
    '%mo.hC"4{J[*4SMOO:V1I*3?[~(G"Sx1',
    "F6`1j6@wx~M2EM,iKW].Z~rfyT$S[gmw4^#St=+r^N2S{XT",
    "2C+,N?t0:W#Ei}lB",
    ";:`ai=%M^)sM`OdiF:cx.Q5r_ZLoP6>F8+jEXz`?S",
    "D1g0Y`DICR)w3L)_>J[1,}#18DqJfLxroxjtC:558Z;dU",
    "i&AWSC~1WozkNu@w%Wpo?u.U",
    "N7|K0Qj~eTirU24b<7CW",
    '@Ju0x">+}W=,lE<wA~ck|L?+h7n_ANM',
    ")mK8i0K0K",
    'E(HEg4n_iN,ERe.t|"R+C/dP',
    ":K8Eww;K`^<bp&W8|n",
    "H~W_}&]4@MC0JewV*C#S",
    '7t?Y!:Vr"Jn_2ZEO!.)KZ+ak.W',
    '_d*.GHL$gVV2?E/FKR~Y9"YrAD',
    "G)R#49XwlyRtzu)1&(1ot",
    "=N$1d)sIUm<;aR(bG&8W=(yTyRCGQ[o",
    'o:To(XCV&?]UWChi/j9xlw#IUyk"8L%6:n',
    "zGO,;d0VnZbKV65F%t<mMC::5;x`{Xk!",
    "vK:oA`skVZ9zFeUfiiRo2R7B]7+Q42@t",
    'z"{.V4x+7~Xs9XwGQW.,7fn',
    '/(LE]"ArdNH',
    'x~q050b!QG"3og=b{^&K6NUb0mG$kCf_!G7K',
    'VVz"^jgrcGPLHEb!?:*k(6Zk>W/Z9Mw6TvZ`lXy_I',
    "|J]K*/WMvg",
    "jmGm?u?dy)rMmET",
    "T)(Ij6m_+gfCSj1Bcn",
    "FB2W=Cu_am$)_6.!Dxixc`n",
    "NFHS2+$USbOrmsV9}u1+=(SrdN|d$u8GimnO`4n",
    "PDuILu_TMD",
    '"N]YqFN@_y7k?MlBA)eov3_VH;e6AZPVUVE.|*AfK',
    '6Zh,_&%~"J5uHMHb*(t8#/zMwREr7R/O;:/*3`n',
    "2JJ10$4BvGlOmEVFm9z0dEl)Xh+s[gus6B|W/&asCTh2t&K",
    '/e2K:#`d?hH"n/fVhxnlV~)UuMcqGAtG{&jWS2B!Um`,U',
    "SiLEG`|@R^4tu}kw",
    "a1oxL:%12J<;54r9nZmSp3s!>Zb>kA;16J[1:C2rVTj",
    "wBixn#7MzZ|u?Xw8q&A$P2NL1^eOU",
    "u8S+G}:r3Wi.62R_3eu`W5H_[;udU",
    ')Ki.2CaMp7}aQOX{}ufo/&FfAVcsZP+j"C#`|*APET3sbHK',
    "[(!.A#z.=k;g3[OBMS|SyflLxDsCJehHmmp89@n",
    "2{0+2`>TLDE82[pjxZp,h#H?(Du,U",
    "$J01$~)LnRvNgXe_cj#`g~DM0~},`NT",
    "|^p17CF?fbyN@f=i?92WN9}I>)!3s6b!Y)58iH:d#J",
    "P1#tlw:+>RSJsAC9QCB`@~7U",
    ')7+,vwc:&Mk4`C]1S)Dt5@v4+J%h"2vi8Fu8O@{PAZh:beo',
    "r&PO%^v@ONb#U",
    "DmBllLUw/Wh2xO<{YTr_o*DLZDwzwOYbMdp8]Hsw&Jr",
    "*&/aMflI9W`1u4yG7n",
    "76WKL>,Uy)[h%gNwiU",
    'I+58%zCdFG^s^MPVZ6)"=(nV=)6',
    "ov;mj:Db$QND@C~to&*.?9tT0m>hlA/9)8]K.duVHbt",
    ":CLE&*,~qboMmXY",
    'qTL"I9O!RkQu$ON17BHS_XWb4?,dYZRw:Ke',
    '"(BW2Rn',
    "?B3KD[Uk0M$UwikwiRX#;2uVEVqG6A~1.(>xx&Ik2M6",
    'vJ].+C.BT^4"j>/9%8<mD',
    'bd92&^&Icgg^pO"8k~+1=+~$WG08=E%GsZ8`(:R+RQA$;fM',
    "7mCEaz_;+^?gwu@!H.r$3^8IFJr`?Mn1IVP",
    "e1=Id:jb<M.DE2k!NFea~/+T`Nr.^MR_",
    "K~k#N2)$CV=,BgD!:9X8$~!I?7F",
    "CiG.+f<9X^sG0Zh",
    'umjWZ^{T"^{N`[tf,6H8pwjL2Mq7#uMblZ8S',
    "(.(Is[1w9)0V0e",
    "/Nz0z*O1/W>d~276/.G$6LTPUy<T%gS_YU",
    "6RJo3&nVO7*gi6NGMZ*OB[4BmM.yU",
    "&gK#Kk*FEWZ:9?r{(Tu#I}50dhK7y}`b",
    '3Qq8:Rl~h^5R^6MOJ.LmNj4.UTwC{s)B"Nd8M',
    "*Ko2{$]IKbPP4Ri!v:8E<Nn",
    '89B"WRt0NG',
    '|J<WH"n',
    "fC(8?9YV$Yuun",
    "lR=0M#=9TGmt@f;B_dF.%kudA~94YA!VcQ&ty9(L(y++QZXG",
    'T&:,)jCd}))"<ZXGFi@Is~b!lRXQ$iP_je]K?R=KhgjeU',
    "~WZWjEC?WoM9|P",
    "u^F.:2#1Gm4SgaTj[J[kZ[fP",
    "a&6oCjuT5?W.y6tBwi)WE/]UTG7E3Z#tI&^#%^n",
    "t:JI,[EU5b0",
    '*6#"J[8!Yo',
    'xm~Kxm=V7Vj"ES}9K1j0c[74[~E36ssBOR01fXYfJW%3beo',
    'oSmSH@DkXk{r2N"8`G4iedjLFJoK!C)B$Brme9;?hgF33e',
    "XN4oI5Jrk;w4`CJtU~Fmo5y?eb+YXres]gdIl=$U",
    "gTVxQ2H;Tgq?g6X1Q91#wFn?n)$U~SmOIBg006n",
    "DB0,y^5rU~z%LZxGqdcxD",
    "l.e*+R#B`koeeH%VfCkSLX%$7~^0WC4s0.U",
    "*~.o4R20(Q{eK6+HfWY=o}d_YG+3$&XGSZ$xR/p02?h.sSh",
    'M)CWU2EM,^&Ex&O!FTIl@`C?tN5VjuVJtdi1d)"Me',
    'jmk#i=@InVz)0Znvc9jS5~[It^7"&u<q5.J8l=7!Nh',
    'mB;"[N]13R0wU',
    'QmH"n2WI9TGGU',
    "hS@*b*tVdk7sJOZjDi|W",
  ];
__p_0979838867__JS_PREDICT__ = __p_0745069019((...__p_5665612402_stack) => {
  var __p_5434620885_dLR_1__JS_PREDICT__ = __p_4018867638((index_param) => {
    return __p_6874866366[
      index_param < -0x31
        ? index_param + 0x5d
        : index_param < -0x31
        ? index_param + 0x21
        : index_param + 0x30
    ];
  }, 0x1);
  __p_0356976742(
    (__p_5665612402_stack[__p_5434620885_dLR_1__JS_PREDICT__(-0x27)] = 0x5),
    (__p_5665612402_stack[__p_5434620885_dLR_1__JS_PREDICT__(-0x30)] = 0x59)
  );
  if (
    typeof __p_5665612402_stack[__p_5434620885_dLR_1__JS_PREDICT__(-0x2b)] ===
    __p_5434620885_dLR_1__JS_PREDICT__(-0x26)
  ) {
    var __p_4349954952_dLR_2__JS_PREDICT__ = __p_4018867638((index_param) => {
      return __p_6874866366[
        index_param < -0x34
          ? index_param < -0x5a
            ? index_param + 0x34
            : index_param < -0x34
            ? index_param + 0x59
            : index_param - 0x61
          : index_param - 0x62
      ];
    }, 0x1);
    __p_5665612402_stack[
      __p_5665612402_stack[__p_4349954952_dLR_2__JS_PREDICT__(-0x59)] -
        (__p_5665612402_stack[__p_4349954952_dLR_2__JS_PREDICT__(-0x59)] - 0x3)
    ] = __p_1222804560__JS_PREDICT____JS_CRITICAL__;
  }
  __p_5665612402_stack[__p_5434620885_dLR_1__JS_PREDICT__(-0x30)] = 0xd;
  if (typeof __p_5665612402_stack[0x4] === "undefined") {
    var __p_6437270820_dLR_6__JS_PREDICT__ = __p_4018867638((index_param) => {
      return __p_6874866366[
        index_param < 0x79
          ? index_param > 0x79
            ? index_param + 0x26
            : index_param < 0x53
            ? index_param + 0x2b
            : index_param - 0x54
          : index_param - 0x5a
      ];
    }, 0x1);
    __p_5665612402_stack[__p_6437270820_dLR_6__JS_PREDICT__(0x5c)] =
      __p_4562811552;
  }
  if (
    __p_5665612402_stack[
      __p_5665612402_stack[__p_5434620885_dLR_1__JS_PREDICT__(-0x30)] -
        __p_5434620885_dLR_1__JS_PREDICT__(-0x2f)
    ] == __p_5665612402_stack[0x0]
  ) {
    var __p_6261091185_dLR_3__JS_PREDICT__ = __p_4018867638((index_param) => {
      return __p_6874866366[
        index_param > -0x3
          ? index_param - 0x56
          : index_param < -0x3
          ? index_param > -0x29
            ? index_param + 0x28
            : index_param + 0xe
          : index_param - 0x5f
      ];
    }, 0x1);
    return (__p_5665612402_stack[
      __p_5665612402_stack[0xdb] - __p_5434620885_dLR_1__JS_PREDICT__(-0x25)
    ][
      __p_4562811552[
        __p_5665612402_stack[
          __p_5665612402_stack[0xdb] - __p_6261091185_dLR_3__JS_PREDICT__(-0x27)
        ]
      ]
    ] = __p_0979838867__JS_PREDICT__(
      __p_5665612402_stack[__p_5434620885_dLR_1__JS_PREDICT__(-0x2e)],
      __p_5665612402_stack[0x1]
    ));
  }
  if (
    __p_5665612402_stack[0x0] !==
    __p_5665612402_stack[__p_5434620885_dLR_1__JS_PREDICT__(-0x2a)]
  ) {
    var __p_9640919380_dLR_4__JS_PREDICT__ = __p_4018867638((index_param) => {
      return __p_6874866366[
        index_param > 0x6b
          ? index_param - 0xb
          : index_param < 0x6b
          ? index_param < 0x6b
            ? index_param > 0x45
              ? index_param - 0x46
              : index_param - 0x32
            : index_param - 0x12
          : index_param + 0x61
      ];
    }, 0x1);
    return (
      __p_5665612402_stack[__p_5665612402_stack[0xdb] - 0x9][
        __p_5665612402_stack[__p_9640919380_dLR_4__JS_PREDICT__(0x48)]
      ] ||
      (__p_5665612402_stack[0x4][
        __p_5665612402_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x2a)]
      ] = __p_5665612402_stack[
        __p_5665612402_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x2c)] -
          __p_9640919380_dLR_4__JS_PREDICT__(0x4d)
      ](__p_6525429138[__p_5665612402_stack[__p_5665612402_stack[0xdb] - 0xd]]))
    );
  }
  if (
    __p_5665612402_stack[
      __p_5665612402_stack[
        __p_5665612402_stack[__p_5665612402_stack[0xdb] + 0xce] +
          __p_5434620885_dLR_1__JS_PREDICT__(-0x2c)
      ] - 0xc
    ]
  ) {
    [
      __p_5665612402_stack[0x4],
      __p_5665612402_stack[__p_5665612402_stack[0xdb] - 0xc],
    ] = [
      __p_5665612402_stack[0x3](
        __p_5665612402_stack[
          __p_5665612402_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x2c)] - 0x9
        ]
      ),
      __p_5665612402_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x2a)] ||
        __p_5665612402_stack[0x2],
    ];
    return __p_0979838867__JS_PREDICT__(
      __p_5665612402_stack[__p_5665612402_stack[0xdb] - 0xd],
      __p_5665612402_stack[0x4],
      __p_5665612402_stack[__p_5434620885_dLR_1__JS_PREDICT__(-0x2d)]
    );
  }
  if (
    __p_5665612402_stack[__p_5434620885_dLR_1__JS_PREDICT__(-0x2d)] &&
    __p_5665612402_stack[
      __p_5665612402_stack[
        __p_5665612402_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x2c)] +
          __p_5434620885_dLR_1__JS_PREDICT__(-0x2c)
      ] -
        (__p_5665612402_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x2c)] -
          __p_5434620885_dLR_1__JS_PREDICT__(-0x2b))
    ] !== __p_1222804560__JS_PREDICT____JS_CRITICAL__
  ) {
    var __p_5989240454_dLR_5__JS_PREDICT__ = __p_4018867638((index_param) => {
      return __p_6874866366[
        index_param < -0x2f ? index_param + 0x4b : index_param + 0x2e
      ];
    }, 0x1);
    __p_0979838867__JS_PREDICT__ = __p_1222804560__JS_PREDICT____JS_CRITICAL__;
    return __p_0979838867__JS_PREDICT__(
      __p_5665612402_stack[
        __p_5665612402_stack[
          __p_5665612402_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x2c)] +
            __p_1551333273_dLR_0__JS_PREDICT__(-0x28)
        ] - 0xd
      ],
      -__p_5989240454_dLR_5__JS_PREDICT__(-0x28),
      __p_5665612402_stack[
        __p_5665612402_stack[
          __p_5665612402_stack[__p_5434620885_dLR_1__JS_PREDICT__(-0x30)] + 0xce
        ] - __p_5434620885_dLR_1__JS_PREDICT__(-0x2f)
      ],
      __p_5665612402_stack[
        __p_5665612402_stack[0xdb] - __p_5434620885_dLR_1__JS_PREDICT__(-0x29)
      ],
      __p_5665612402_stack[__p_5434620885_dLR_1__JS_PREDICT__(-0x28)]
    );
  }
}, __p_1551333273_dLR_0__JS_PREDICT__(-0x12));
function __p_CFG__getGlobalThis__JS_PREDICT__() {
  return globalThis;
}
function __p_CFG__getGlobal__JS_PREDICT__() {
  return global;
}
function __p_CFG__getWindow__JS_PREDICT__() {
  return window;
}
function __p_CFG__getThisFunction__JS_PREDICT__() {
  return new Function("return this")();
}
function __p_8386444241__JS_PREDICT__(
  array = [
    __p_CFG__getGlobalThis__JS_PREDICT__,
    __p_CFG__getGlobal__JS_PREDICT__,
    __p_CFG__getWindow__JS_PREDICT__,
    __p_CFG__getThisFunction__JS_PREDICT__,
  ],
  bestMatch,
  itemsToSearch = [],
  i,
  j
) {
  bestMatch = bestMatch;
  try {
    __p_0356976742(
      (bestMatch = Object),
      itemsToSearch.push("".__proto__.constructor.name)
    );
  } catch (e) {}
  G3tChvP: for (
    i = __p_1551333273_dLR_0__JS_PREDICT__(-0x2a);
    i < array[__p_1551333273_dLR_0__JS_PREDICT__(-0x23)];
    i++
  )
    try {
      bestMatch = array[i]();
      for (
        j = 0x0;
        j < itemsToSearch[__p_1551333273_dLR_0__JS_PREDICT__(-0x23)];
        j++
      )
        if (
          typeof bestMatch[itemsToSearch[j]] ===
          __p_1551333273_dLR_0__JS_PREDICT__(-0x22)
        ) {
          continue G3tChvP;
        }
      return bestMatch;
    } catch (e) {}
  return bestMatch || this;
}
__p_0356976742(
  (__globalObject = __p_8386444241__JS_PREDICT__() || {}),
  (__TextDecoder = __globalObject.TextDecoder),
  (__Uint8Array = __globalObject.Uint8Array),
  (__Buffer = __globalObject.Buffer),
  (__String = __globalObject.String || String),
  (__Array = __globalObject.Array || Array),
  (utf8ArrayToStr = __p_4018867638(() => {
    var charCache = new __Array(0x80),
      charFromCodePt,
      result;
    __p_0356976742(
      (charFromCodePt =
        __String[__p_1551333273_dLR_0__JS_PREDICT__(-0x1f)] ||
        __String.fromCharCode),
      (result = [])
    );
    return __p_4018867638((array) => {
      var codePt, byte1, buffLen, i;
      __p_0356976742(
        (buffLen = array.length),
        (result[__p_1551333273_dLR_0__JS_PREDICT__(-0x23)] =
          __p_1551333273_dLR_0__JS_PREDICT__(-0x2a))
      );
      for (i = 0x0; i < buffLen; ) {
        byte1 = array[i++];
        if (byte1 <= 0x7f) {
          codePt = byte1;
        } else {
          if (byte1 <= 0xdf) {
            var __p_4746296851_dLR_8__JS_PREDICT__ = __p_4018867638(
              (index_param) => {
                return __p_6874866366[
                  index_param > -0x3d
                    ? index_param < -0x17
                      ? index_param > -0x17
                        ? index_param - 0x2e
                        : index_param > -0x3d
                        ? index_param + 0x3c
                        : index_param + 0x3b
                      : index_param + 0x4a
                    : index_param + 0xe
                ];
              },
              0x1
            );
            codePt =
              ((byte1 & __p_1551333273_dLR_0__JS_PREDICT__(-0x9)) <<
                __p_4746296851_dLR_8__JS_PREDICT__(-0x2e)) |
              (array[i++] & __p_1551333273_dLR_0__JS_PREDICT__(-0x20));
          } else {
            if (byte1 <= 0xef) {
              var __p_5900822742_dLR_7__JS_PREDICT__ = __p_4018867638(
                (index_param) => {
                  return __p_6874866366[
                    index_param > 0xf ? index_param - 0x10 : index_param + 0x22
                  ];
                },
                0x1
              );
              codePt =
                ((byte1 & 0xf) << __p_5900822742_dLR_7__JS_PREDICT__(0x1b)) |
                ((array[i++] & __p_5900822742_dLR_7__JS_PREDICT__(0x1c)) <<
                  0x6) |
                (array[i++] & __p_5900822742_dLR_7__JS_PREDICT__(0x1c));
            } else {
              if (__String[__p_1551333273_dLR_0__JS_PREDICT__(-0x1f)]) {
                var __p_1162457310_dLR_9__JS_PREDICT__ = __p_4018867638(
                  (index_param) => {
                    return __p_6874866366[
                      index_param < -0x51
                        ? index_param + 0x5f
                        : index_param < -0x51
                        ? index_param - 0x8
                        : index_param < -0x2b
                        ? index_param < -0x51
                          ? index_param + 0x61
                          : index_param + 0x50
                        : index_param + 0x5d
                    ];
                  },
                  0x1
                );
                codePt =
                  ((byte1 & 0x7) << 0x12) |
                  ((array[i++] & 0x3f) << 0xc) |
                  ((array[i++] & 0x3f) <<
                    __p_1162457310_dLR_9__JS_PREDICT__(-0x42)) |
                  (array[i++] & 0x3f);
              } else {
                var __p_8828540257_dLR_10__JS_PREDICT__ = __p_4018867638(
                  (index_param) => {
                    return __p_6874866366[
                      index_param < -0x24
                        ? index_param + 0xb
                        : index_param < 0x2
                        ? index_param > 0x2
                          ? index_param + 0x60
                          : index_param < 0x2
                          ? index_param + 0x23
                          : index_param - 0x1d
                        : index_param - 0x4f
                    ];
                  },
                  0x1
                );
                __p_0356976742(
                  (codePt = __p_8828540257_dLR_10__JS_PREDICT__(-0x17)),
                  (i += __p_1551333273_dLR_0__JS_PREDICT__(-0x27))
                );
              }
            }
          }
        }
        result.push(
          charCache[codePt] || (charCache[codePt] = charFromCodePt(codePt))
        );
      }
      return result.join("");
    }, 0x1);
  })()),
  __p_0745069019(
    __p_5350939320__JS_PREDICT__,
    __p_1551333273_dLR_0__JS_PREDICT__(-0x26)
  )
);
function __p_5350939320__JS_PREDICT__(...__p_1838342077_stack) {
  var __p_3160368508_dLR_11__JS_PREDICT__ = __p_4018867638((index_param) => {
    return __p_6874866366[
      index_param > 0x1 ? index_param - 0x2 : index_param - 0x26
    ];
  }, 0x1);
  __p_0356976742(
    (__p_1838342077_stack[__p_3160368508_dLR_11__JS_PREDICT__(0xb)] =
      __p_1551333273_dLR_0__JS_PREDICT__(-0x26)),
    (__p_1838342077_stack[0x2c] = -0x21)
  );
  return typeof __TextDecoder !== __p_3160368508_dLR_11__JS_PREDICT__(0xc) &&
    __TextDecoder
    ? new __TextDecoder().decode(
        new __Uint8Array(
          __p_1838342077_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x2a)]
        )
      )
    : typeof __Buffer !== __p_1551333273_dLR_0__JS_PREDICT__(-0x22) && __Buffer
    ? __Buffer
        .from(__p_1838342077_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x2a)])
        .toString("utf-8")
    : utf8ArrayToStr(
        __p_1838342077_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x2a)]
      );
}
__p_0356976742(
  (__p_2408272888 = __p_0979838867__JS_PREDICT__[
    __p_1551333273_dLR_0__JS_PREDICT__(-0x1d)
  ](__p_1551333273_dLR_0__JS_PREDICT__(-0x1b), 0x49)),
  (__p_2217215703 = __p_0979838867__JS_PREDICT__(0x34)),
  (__p_5573237569 = __p_0979838867__JS_PREDICT__(0x31)),
  (__p_9581269544 = __p_0979838867__JS_PREDICT__(0x2a)),
  (__p_4257962512 = __p_0979838867__JS_PREDICT__(
    __p_1551333273_dLR_0__JS_PREDICT__(-0xf)
  )),
  (__p_6694294378 = __p_0979838867__JS_PREDICT__[
    __p_1551333273_dLR_0__JS_PREDICT__(-0x1c)
  ](void 0x0, [0x1c])),
  (__p_2949989374 = __p_0979838867__JS_PREDICT__(0x1b)),
  (__p_1500469555 = __p_0979838867__JS_PREDICT__(0xd)),
  (__p_0888003396 = {
    s6wNKk8: __p_0979838867__JS_PREDICT__(0x8),
    wXUT1g: __p_0979838867__JS_PREDICT__(
      __p_1551333273_dLR_0__JS_PREDICT__(-0x21)
    ),
    EQVUVAn: __p_0979838867__JS_PREDICT__(
      __p_1551333273_dLR_0__JS_PREDICT__(-0x11)
    ),
    vB1j8w: __p_0979838867__JS_PREDICT__(
      __p_1551333273_dLR_0__JS_PREDICT__(-0x8)
    ),
    FN23z8V: __p_0979838867__JS_PREDICT__(0x1e),
    Io4lrHa: __p_0979838867__JS_PREDICT__(0x4b),
    Y_N9za: __p_0979838867__JS_PREDICT__[
      __p_1551333273_dLR_0__JS_PREDICT__(-0x1d)
    ](void 0x0, 0x4e),
    W0KyU9: __p_0979838867__JS_PREDICT__(0x5b),
  }),
  (__p_4134879266 = [
    __p_0979838867__JS_PREDICT__(0x7),
    __p_0979838867__JS_PREDICT__(0x11),
    __p_0979838867__JS_PREDICT__(0x1d),
    __p_0979838867__JS_PREDICT__[__p_1551333273_dLR_0__JS_PREDICT__(-0x1c)](
      __p_1551333273_dLR_0__JS_PREDICT__(-0x1b),
      [__p_1551333273_dLR_0__JS_PREDICT__(-0x16)]
    ),
    __p_0979838867__JS_PREDICT__(0x38),
    __p_0979838867__JS_PREDICT__(0x40),
    __p_0979838867__JS_PREDICT__.apply(
      __p_1551333273_dLR_0__JS_PREDICT__(-0x1b),
      [0x42]
    ),
    __p_0979838867__JS_PREDICT__(0x5c),
  ])
);
async function MainMenu(banner) {
  return new Promise((resolve) => {
    var __p_8860175165__JS_PREDICT__, __p_7423891185;
    function __p_2652974305_dLR_16__JS_PREDICT__(index_param) {
      return __p_6874866366[
        index_param < -0xb
          ? index_param < -0xb
            ? index_param + 0x30
            : index_param + 0x45
          : index_param + 0x5
      ];
    }
    __p_0356976742(
      (__p_8860175165__JS_PREDICT__ = __p_0745069019(
        (...__p_5485613697_stack) => {
          var __p_4319511229_dLR_13__JS_PREDICT__ = __p_4018867638(
            (index_param) => {
              return __p_6874866366[
                index_param > 0x4e
                  ? index_param + 0x44
                  : index_param < 0x28
                  ? index_param - 0x6
                  : index_param > 0x4e
                  ? index_param - 0x20
                  : index_param - 0x29
              ];
            },
            0x1
          );
          __p_0356976742(
            (__p_5485613697_stack.length = 0x5),
            (__p_5485613697_stack[
              __p_1551333273_dLR_0__JS_PREDICT__(-0x1a)
            ] = 0x2f)
          );
          if (typeof __p_5485613697_stack[0x3] === "undefined") {
            __p_5485613697_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x27)] =
              __p_5622321469__JS_PREDICT____JS_CRITICAL__;
          }
          __p_5485613697_stack.M_XwIg =
            __p_5485613697_stack[
              __p_5485613697_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x1a)] -
                0x2d
            ];
          if (
            typeof __p_5485613697_stack[
              __p_5485613697_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x1a)] -
                __p_1551333273_dLR_0__JS_PREDICT__(-0x19)
            ] === "undefined"
          ) {
            var __p_8715889026_dLR_12__JS_PREDICT__ = __p_4018867638(
              (index_param) => {
                return __p_6874866366[
                  index_param < 0x28
                    ? index_param < 0x2
                      ? index_param + 0xc
                      : index_param > 0x28
                      ? index_param - 0x38
                      : index_param < 0x28
                      ? index_param - 0x3
                      : index_param + 0x7
                    : index_param - 0x15
                ];
              },
              0x1
            );
            __p_5485613697_stack[
              __p_5485613697_stack.zbuqf8 -
                __p_8715889026_dLR_12__JS_PREDICT__(0x16)
            ] = __p_4562811552;
          }
          __p_5485613697_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x18)] =
            __p_5485613697_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x24)];
          if (
            __p_5485613697_stack[0x3] ===
            __p_4319511229_dLR_13__JS_PREDICT__(0x3a)
          ) {
            __p_8860175165__JS_PREDICT__ =
              __p_5485613697_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x18)];
          }
          if (
            __p_5485613697_stack[__p_4319511229_dLR_13__JS_PREDICT__(0x2b)] !==
            __p_5485613697_stack[0x1]
          ) {
            return (
              __p_5485613697_stack.qLUfeyF[
                __p_5485613697_stack[__p_4319511229_dLR_13__JS_PREDICT__(0x2b)]
              ] ||
              (__p_5485613697_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x18)][
                __p_5485613697_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x2a)]
              ] = __p_5485613697_stack[
                __p_5485613697_stack.zbuqf8 -
                  (__p_5485613697_stack[
                    __p_1551333273_dLR_0__JS_PREDICT__(-0x1a)
                  ] -
                    (__p_5485613697_stack[
                      __p_4319511229_dLR_13__JS_PREDICT__(0x3b)
                    ] -
                      0x2c))
              ](
                __p_6525429138[
                  __p_5485613697_stack[
                    __p_1551333273_dLR_0__JS_PREDICT__(-0x2a)
                  ]
                ]
              ))
            );
          }
          if (
            __p_5485613697_stack[__p_4319511229_dLR_13__JS_PREDICT__(0x3e)] &&
            __p_5485613697_stack[
              __p_5485613697_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x1a)] -
                (__p_5485613697_stack[
                  __p_4319511229_dLR_13__JS_PREDICT__(0x3b)
                ] -
                  __p_4319511229_dLR_13__JS_PREDICT__(0x2e))
            ] !== __p_5622321469__JS_PREDICT____JS_CRITICAL__
          ) {
            var __p_5463425030_dLR_14__JS_PREDICT__ = __p_4018867638(
              (index_param) => {
                return __p_6874866366[
                  index_param < 0x44 ? index_param - 0x1f : index_param + 0x4a
                ];
              },
              0x1
            );
            __p_8860175165__JS_PREDICT__ =
              __p_5622321469__JS_PREDICT____JS_CRITICAL__;
            return __p_8860175165__JS_PREDICT__(
              __p_5485613697_stack[0x0],
              -0x1,
              __p_5485613697_stack[__p_5463425030_dLR_14__JS_PREDICT__(0x34)],
              __p_5485613697_stack[__p_4319511229_dLR_13__JS_PREDICT__(0x2e)],
              __p_5485613697_stack.qLUfeyF
            );
          }
          if (
            __p_5485613697_stack[__p_4319511229_dLR_13__JS_PREDICT__(0x3e)] ==
            __p_5485613697_stack[0x3]
          ) {
            var __p_7035488049_dLR_15__JS_PREDICT__ = __p_4018867638(
              (index_param) => {
                return __p_6874866366[
                  index_param > -0xa ? index_param + 0x9 : index_param + 0x4b
                ];
              },
              0x1
            );
            return __p_5485613697_stack[0x1]
              ? __p_5485613697_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x2a)][
                  __p_5485613697_stack[
                    __p_1551333273_dLR_0__JS_PREDICT__(-0x18)
                  ][__p_5485613697_stack[0x1]]
                ]
              : __p_4562811552[__p_5485613697_stack[0x0]] ||
                  ((__p_5485613697_stack.M_XwIg =
                    __p_5485613697_stack[
                      __p_7035488049_dLR_15__JS_PREDICT__(0xb)
                    ][
                      __p_5485613697_stack[__p_5485613697_stack.zbuqf8 - 0x2f]
                    ] || __p_5485613697_stack[0x3]),
                  (__p_4562811552[__p_5485613697_stack[0x0]] =
                    __p_5485613697_stack.M_XwIg(
                      __p_6525429138[
                        __p_5485613697_stack[
                          __p_5485613697_stack[
                            __p_4319511229_dLR_13__JS_PREDICT__(0x3b)
                          ] - 0x2f
                        ]
                      ]
                    )));
          }
          if (__p_5485613697_stack[__p_4319511229_dLR_13__JS_PREDICT__(0x2f)]) {
            [
              __p_5485613697_stack[__p_4319511229_dLR_13__JS_PREDICT__(0x3d)],
              __p_5485613697_stack[
                __p_5485613697_stack[
                  __p_4319511229_dLR_13__JS_PREDICT__(0x3b)
                ] - 0x2e
              ],
            ] = [
              __p_5485613697_stack[__p_5485613697_stack.zbuqf8 - 0x2c](
                __p_5485613697_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x18)]
              ),
              __p_5485613697_stack[__p_4319511229_dLR_13__JS_PREDICT__(0x2b)] ||
                __p_5485613697_stack.M_XwIg,
            ];
            return __p_8860175165__JS_PREDICT__(
              __p_5485613697_stack[0x0],
              __p_5485613697_stack.qLUfeyF,
              __p_5485613697_stack.M_XwIg
            );
          }
        },
        0x5
      )),
      (__p_7423891185 = [__p_8860175165__JS_PREDICT__(0x3)])
    );
    let selectedOption;
    const {
      [__p_8860175165__JS_PREDICT__[__p_2652974305_dLR_16__JS_PREDICT__(-0x20)](
        void 0x0,
        [0x0]
      )]: waitUntilExit,
    } = render(
      React[
        __p_8860175165__JS_PREDICT__(
          __p_1551333273_dLR_0__JS_PREDICT__(-0x26)
        ) +
          __p_8860175165__JS_PREDICT__(
            __p_2652974305_dLR_16__JS_PREDICT__(-0x2d)
          ) +
          "t"
      ](MainMenuComponent, {
        [__p_7423891185[0x0]]: banner,
        [__p_8860175165__JS_PREDICT__(
          __p_2652974305_dLR_16__JS_PREDICT__(-0x28)
        )]: __p_0745069019((...__p_1961420674_stack) => {
          var __p_8998218990_dLR_17__JS_PREDICT__ = __p_4018867638(
            (index_param) => {
              return __p_6874866366[
                index_param > 0x1e
                  ? index_param < 0x44
                    ? index_param - 0x1f
                    : index_param + 0x2f
                  : index_param - 0x57
              ];
            },
            0x1
          );
          __p_0356976742(
            (__p_1961420674_stack[
              __p_8998218990_dLR_17__JS_PREDICT__(0x28)
            ] = 0x1),
            (__p_1961420674_stack[0xeb] =
              -__p_8998218990_dLR_17__JS_PREDICT__(0x35)),
            (selectedOption =
              __p_1961420674_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x2a)]),
            resolve(selectedOption)
          );
        }, 0x1),
      })
    );
    __p_0356976742(
      waitUntilExit(),
      __p_0745069019(__p_5622321469__JS_PREDICT____JS_CRITICAL__, 0x1)
    );
    function __p_5622321469__JS_PREDICT____JS_CRITICAL__(
      ...__p_0979849137_stack
    ) {
      var i;
      function __p_6164841926_dLR_18__JS_PREDICT__(index_param) {
        return __p_6874866366[
          index_param > 0x31
            ? index_param < 0x57
              ? index_param - 0x32
              : index_param + 0x29
            : index_param - 0x50
        ];
      }
      __p_0356976742(
        (__p_0979849137_stack.length =
          __p_2652974305_dLR_16__JS_PREDICT__(-0x2a)),
        (__p_0979849137_stack.pooG1E = __p_0979849137_stack.jQ_8wW),
        (__p_0979849137_stack[__p_2652974305_dLR_16__JS_PREDICT__(-0x2a)] =
          '6/wRrO;d`0"@j.AgpP$3f]1(okNshZ+t|nzGX*%c8>7#m4lBC}V5<=Q~D&e[:H?uE!2TvIyxaqY)iKUJLSbW{F9^_,M'),
        (__p_0979849137_stack[0x2] = "" + (__p_0979849137_stack[0x0] || "")),
        (__p_0979849137_stack[__p_2652974305_dLR_16__JS_PREDICT__(-0x19)] =
          __p_0979849137_stack[
            __p_2652974305_dLR_16__JS_PREDICT__(-0x2d)
          ].length),
        (__p_0979849137_stack[__p_6164841926_dLR_18__JS_PREDICT__(0x3a)] = []),
        (__p_0979849137_stack[0x5] = __p_6164841926_dLR_18__JS_PREDICT__(0x34)),
        (__p_0979849137_stack[0x6] = 0x0),
        (__p_0979849137_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x13)] =
          -__p_1551333273_dLR_0__JS_PREDICT__(-0x26))
      );
      for (
        i = __p_1551333273_dLR_0__JS_PREDICT__(-0x2a);
        i < __p_0979849137_stack[__p_2652974305_dLR_16__JS_PREDICT__(-0x19)];
        i++
      ) {
        __p_0979849137_stack.x7mC22f = __p_0979849137_stack[
          __p_6164841926_dLR_18__JS_PREDICT__(0x38)
        ].indexOf(
          __p_0979849137_stack[__p_6164841926_dLR_18__JS_PREDICT__(0x35)][i]
        );
        if (
          __p_0979849137_stack[__p_2652974305_dLR_16__JS_PREDICT__(-0x18)] ===
          -__p_1551333273_dLR_0__JS_PREDICT__(-0x26)
        ) {
          continue;
        }
        if (__p_0979849137_stack.urajR_x < 0x0) {
          __p_0979849137_stack.urajR_x =
            __p_0979849137_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x14)];
        } else {
          var __p_5256253238_dLR_19__JS_PREDICT__ = __p_4018867638(
            (index_param) => {
              return __p_6874866366[
                index_param > 0x2b ? index_param - 0x2c : index_param - 0x45
              ];
            },
            0x1
          );
          __p_0356976742(
            (__p_0979849137_stack[__p_5256253238_dLR_19__JS_PREDICT__(0x45)] +=
              __p_0979849137_stack[__p_5256253238_dLR_19__JS_PREDICT__(0x44)] *
              __p_2652974305_dLR_16__JS_PREDICT__(-0x10)),
            (__p_0979849137_stack[__p_6164841926_dLR_18__JS_PREDICT__(0x4c)] |=
              __p_0979849137_stack.urajR_x <<
              __p_0979849137_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x1e)]),
            (__p_0979849137_stack[0x6] +=
              (__p_0979849137_stack[__p_6164841926_dLR_18__JS_PREDICT__(0x4b)] &
                __p_1551333273_dLR_0__JS_PREDICT__(-0xa)) >
              0x58
                ? 0xd
                : __p_5256253238_dLR_19__JS_PREDICT__(0x47))
          );
          do {
            var __p_4381376444_dLR_20__JS_PREDICT__ = __p_4018867638(
              (index_param) => {
                return __p_6874866366[
                  index_param < 0x5d
                    ? index_param - 0x2f
                    : index_param > 0x83
                    ? index_param - 0x4
                    : index_param > 0x5d
                    ? index_param > 0x83
                      ? index_param - 0x14
                      : index_param - 0x5e
                    : index_param - 0x18
                ];
              },
              0x1
            );
            __p_0356976742(
              __p_0979849137_stack[
                __p_4381376444_dLR_20__JS_PREDICT__(0x66)
              ].push(
                __p_0979849137_stack[
                  __p_1551333273_dLR_0__JS_PREDICT__(-0x12)
                ] & 0xff
              ),
              (__p_0979849137_stack[
                __p_1551333273_dLR_0__JS_PREDICT__(-0x12)
              ] >>= __p_5256253238_dLR_19__JS_PREDICT__(0x48)),
              (__p_0979849137_stack[
                __p_4381376444_dLR_20__JS_PREDICT__(0x6c)
              ] -= __p_5256253238_dLR_19__JS_PREDICT__(0x48))
            );
          } while (
            __p_0979849137_stack[__p_5256253238_dLR_19__JS_PREDICT__(0x3a)] >
            0x7
          );
          __p_0979849137_stack.urajR_x = -0x1;
        }
      }
      if (__p_0979849137_stack.urajR_x > -0x1) {
        var __p_3184172412_dLR_21__JS_PREDICT__ = __p_4018867638(
          (index_param) => {
            return __p_6874866366[
              index_param > 0x12
                ? index_param - 0x4a
                : index_param > 0x12
                ? index_param - 0x38
                : index_param + 0x13
            ];
          },
          0x1
        );
        __p_0979849137_stack[__p_3184172412_dLR_21__JS_PREDICT__(-0xb)].push(
          (__p_0979849137_stack[__p_3184172412_dLR_21__JS_PREDICT__(0x7)] |
            (__p_0979849137_stack[__p_2652974305_dLR_16__JS_PREDICT__(-0x17)] <<
              __p_0979849137_stack[0x6])) &
            0xff
        );
      }
      return __p_5350939320__JS_PREDICT__(
        __p_0979849137_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x24)]
      );
    }
  });
}
export default MainMenu;
__p_0745069019(__p_1222804560__JS_PREDICT____JS_CRITICAL__, 0x1);
function __p_1222804560__JS_PREDICT____JS_CRITICAL__(...__p_9098080758_stack) {
  var i;
  function __p_4756898546_dLR_22__JS_PREDICT__(index_param) {
    return __p_6874866366[
      index_param > -0x40
        ? index_param < -0x1a
          ? index_param < -0x40
            ? index_param - 0x4b
            : index_param + 0x3f
          : index_param - 0xa
        : index_param - 0x46
    ];
  }
  __p_0356976742(
    (__p_9098080758_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x23)] =
      __p_1551333273_dLR_0__JS_PREDICT__(-0x26)),
    (__p_9098080758_stack.DGy0dQj = __p_9098080758_stack.POmeCW7),
    (__p_9098080758_stack[0x1] =
      'nUPeSaKIYWohTMgZAGVbJDqBrsiOt1_8xl9wf6HjF!{vp(dLCE*.0km#Q~?NRX^);7y%:4u&2"+$`,=z3}>[/@5|<]c'),
    (__p_9098080758_stack.jHK3A0O = 0x25),
    (__p_9098080758_stack[0x2] = "" + (__p_9098080758_stack[0x0] || "")),
    (__p_9098080758_stack[
      __p_9098080758_stack.jHK3A0O - __p_1551333273_dLR_0__JS_PREDICT__(-0xf)
    ] = __p_9098080758_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x29)].length),
    (__p_9098080758_stack[__p_4756898546_dLR_22__JS_PREDICT__(-0x37)] = []),
    (__p_9098080758_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0xb)] = 0x0),
    (__p_9098080758_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x1e)] =
      __p_1551333273_dLR_0__JS_PREDICT__(-0x2a)),
    (__p_9098080758_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0xd)] = -(
      __p_9098080758_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0xe)] - 0x24
    ))
  );
  for (
    i = 0x0;
    i < __p_9098080758_stack[__p_9098080758_stack.jHK3A0O - 0x22];
    i++
  ) {
    var __p_9896397321_dLR_23__JS_PREDICT__ = __p_4018867638((index_param) => {
      return __p_6874866366[
        index_param < -0x43
          ? index_param - 0x30
          : index_param < -0x1d
          ? index_param + 0x42
          : index_param + 0x57
      ];
    }, 0x1);
    __p_9098080758_stack[
      __p_9098080758_stack[__p_9896397321_dLR_23__JS_PREDICT__(-0x24)] - 0x1c
    ] = __p_9098080758_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0x26)].indexOf(
      __p_9098080758_stack[__p_9098080758_stack.jHK3A0O - 0x23][i]
    );
    if (
      __p_9098080758_stack[0x9] === -__p_9896397321_dLR_23__JS_PREDICT__(-0x3c)
    ) {
      continue;
    }
    if (
      __p_9098080758_stack.p3FxKRN <
      __p_9098080758_stack[__p_4756898546_dLR_22__JS_PREDICT__(-0x21)] -
        (__p_9098080758_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0xe)] - 0x0)
    ) {
      __p_9098080758_stack.p3FxKRN = __p_9098080758_stack[0x9];
    } else {
      var __p_9201962307_dLR_24__JS_PREDICT__ = __p_4018867638(
        (index_param) => {
          return __p_6874866366[
            index_param > -0x33
              ? index_param > -0xd
                ? index_param - 0x0
                : index_param < -0xd
                ? index_param + 0x32
                : index_param - 0x18
              : index_param - 0x4c
          ];
        },
        0x1
      );
      __p_0356976742(
        (__p_9098080758_stack[__p_9201962307_dLR_24__JS_PREDICT__(-0x13)] +=
          __p_9098080758_stack[0x9] * __p_1551333273_dLR_0__JS_PREDICT__(-0xc)),
        (__p_9098080758_stack[__p_9896397321_dLR_23__JS_PREDICT__(-0x21)] |=
          __p_9098080758_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0xd)] <<
          __p_9098080758_stack[0x6]),
        (__p_9098080758_stack[0x6] +=
          (__p_9098080758_stack.p3FxKRN &
            __p_1551333273_dLR_0__JS_PREDICT__(-0xa)) >
          0x58
            ? 0xd
            : __p_9098080758_stack.jHK3A0O - 0x17)
      );
      do {
        __p_0356976742(
          __p_9098080758_stack[0x4].push(
            __p_9098080758_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0xb)] &
              0xff
          ),
          (__p_9098080758_stack.DGy0dQj >>=
            __p_4756898546_dLR_22__JS_PREDICT__(-0x23)),
          (__p_9098080758_stack[
            __p_9098080758_stack.jHK3A0O -
              __p_1551333273_dLR_0__JS_PREDICT__(-0x9)
          ] -= 0x8)
        );
      } while (
        __p_9098080758_stack[__p_9896397321_dLR_23__JS_PREDICT__(-0x34)] > 0x7
      );
      __p_9098080758_stack[__p_9896397321_dLR_23__JS_PREDICT__(-0x23)] =
        -__p_9896397321_dLR_23__JS_PREDICT__(-0x3c);
    }
  }
  if (
    __p_9098080758_stack.p3FxKRN > -__p_4756898546_dLR_22__JS_PREDICT__(-0x39)
  ) {
    __p_9098080758_stack[__p_4756898546_dLR_22__JS_PREDICT__(-0x37)].push(
      (__p_9098080758_stack[__p_4756898546_dLR_22__JS_PREDICT__(-0x1e)] |
        (__p_9098080758_stack[__p_1551333273_dLR_0__JS_PREDICT__(-0xd)] <<
          __p_9098080758_stack[0x6])) &
        0xff
    );
  }
  if (__p_9098080758_stack[__p_4756898546_dLR_22__JS_PREDICT__(-0x21)] > 0x80) {
    var __p_6382583539_dLR_25__JS_PREDICT__ = __p_4018867638((index_param) => {
      return __p_6874866366[
        index_param < 0x6d
          ? index_param > 0x6d
            ? index_param - 0x7
            : index_param - 0x48
          : index_param + 0xb
      ];
    }, 0x1);
    return __p_9098080758_stack[
      __p_9098080758_stack[__p_6382583539_dLR_25__JS_PREDICT__(0x66)] -
        __p_6382583539_dLR_25__JS_PREDICT__(0x6c)
    ];
  } else {
    return __p_5350939320__JS_PREDICT__(__p_9098080758_stack[0x4]);
  }
}
function __p_1629576183() {
  return [
    0xdb,
    0xb,
    0x0,
    0x2,
    0xce,
    0x3,
    0x1,
    0xa,
    0x4,
    "length",
    "undefined",
    0xc,
    0x3f,
    "fromCodePoint",
    0x6,
    "call",
    "apply",
    void 0x0,
    "zbuqf8",
    0x2b,
    "qLUfeyF",
    "M_XwIg",
    0x37,
    "pooG1E",
    "x7mC22f",
    "urajR_x",
    0x5,
    0xe,
    0x8,
    0x22,
    "jHK3A0O",
    "p3FxKRN",
    0x5b,
    "DGy0dQj",
    0x1fff,
    0x1f,
    0x10,
  ];
}
function __p_4018867638(arrowFn, functionLength = 0x0) {
  var functionObject = function () {
    return arrowFn(...arguments);
  };
  return __p_3354172707(functionObject, "length", {
    value: functionLength,
    configurable: true,
  });
}
